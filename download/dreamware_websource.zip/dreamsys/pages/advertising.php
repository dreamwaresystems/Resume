<?php
include_once('../library/start.php');
$PT = new DreamwarePageTemplate();
$PT->printWrapperBegin("advertising");
$PT->printContentBegin(true);
?>
	<div id="subHeaderSpace">
	</div>
			
	<div class="general_box_left" style="margin-top:40px;">
	
		<div class="page_title">Advertising</div>
		<div class="clearbox">
			At this time, Dreamware Systems LLC does not have any available advertising slots on its company-owned sites.  If you are an existing advertiser and 
			wish to discuss your account status, please contact us anytime at support@dreamwaresys.com
		</div>
	</div>

	<div style="clear:both;float:left;margin-top:200px;height:50px;width:80%;"></div>
<?php

$PT->printContentEnd();
$PT->printWrapperEnd();
$PT->outputPage();
?>