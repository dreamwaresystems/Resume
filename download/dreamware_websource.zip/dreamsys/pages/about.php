<?php
include_once('../library/start.php');
$PT = new DreamwarePageTemplate();
$PT->printWrapperBegin("about");
$PT->printContentBegin(true);
?>
	<div class="general_box_left" style="margin-top:40px;">
	
		<div class="page_title">About The Company</div>
		<div class="fadebox">
			<div class="clear" style="margin-top:30px;"></div>
				Dreamware Systems LLC is a New York City based software company founded by programmer and entrepreneur, Mike Jones.
				Since 2007, Dreamware Systems LLC has generated a reputation for superior software solutions across industries and platforms. 
				We pride ourselves on honest communication and straight-forward solutions.

				<br /><br />
				Expertise:<br />
				<ul>
					<li>iOS &amp; Android Native Mobile Apps</li>
					<li>Web Development - Front &amp; Back End</li>
					<li>Database Design, Management and Tuning</li>
					<li>Fat-Client Windows Applications</li>
					<li>Custom Hardware Drivers</li>
					<li>Nginx, Percona Server Hosting</li>
					<li>IIS, Windows Server Management</li>
				</ul>

				<br /><br />  
				Dreamware Systems LLC provides software solutions on a case-by-case basis. If you are interested in our services, please contact us via our web contact form.
				
			<div class="clear" style="margin-top:50px;"></div>
		</div>
		
	</div>
<?php

$PT->printContentEnd();
$PT->printWrapperEnd();
$PT->outputPage();
?>