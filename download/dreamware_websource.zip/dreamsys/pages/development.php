<?php
include_once('../library/start.php');
$PT = new DreamwarePageTemplate();
$PT->printWrapperBegin("development");
$PT->printContentBegin(true);
?>
	<div class="general_box_left" style="margin-top:40px;">
	
		<div class="page_title">Custom Software Development</div>
		<div class="clearbox">
			Dreamware Systems LLC was born out of the demand for elegant third-party software solutions in today's ever-changing technology markets.  
			Below are a select few of the numerous software solutions built to third-party spec.
		</div>
		
		<div class="section_titlebox">Student Groove Card</div>
		<div class="project_box">
			<div class="project_groovecard">
				<a href="http://www.groovecard.com/" target="_blank"></a>
			</div>
			<div class="project_text">
				Student Groove Card was a company built on discount cards for college campuses.  One of the first commercial websites that drove Dreamware Systems initial 
				development and founding.  Unfortunately, groovecards did not gain wider market traction but their company website still stands as a testament to 
				Dreamware System's use of bleeding edge technology such as embedded Flash, dynamic form security checks and client-side scripting in an era long 
				before the global Web 2.0 movement.
			</div>
		</div>
		
		<div class="section_titlebox">Sammy &amp; Nat</div>
		<div class="project_box">
			<div class="project_sammy">
				<a href="http://www.sammyandnat.com/" target="_blank"></a>
			</div>
			<div class="project_text">
				A collection of onesies, rompers, take-me-home sets in a beautiful assortment of solids and bold prints that can be 
				"dressed up or down" as she puts it. Sammy &amp; Nat is a company built by Samantha Benson to market her exclusive line 
				of baby apparel and Dreamware Systems LLC was more than happy to provide her with the latest web-design and social marketing 
				features that have helped her build her company into a globally recognized brand.
			</div>
		</div>
		
		<div class="section_titlebox">World Steel Dynamics - Global Financial Reporting Engine</div>
		<div class="project_box">
			<div class="project_wsd">
				<a href="http://gsis.worldsteeldynamics.com/gsf/" target="_blank"></a>
			</div>
			<div class="project_text">
				World Steel Dynamics &copy; is the world's leading steel information service providing critical data, forecasting and innovative perspectives 
				on global steel industry developments. In 2010, World Steel Dynamics Inc. hired Dreamware Systems LLC to build out an online suite of analytical tools 
				including the "Global Steel Financial System" or GSF.  The GSF is driven off historical data, WSD analysis and real-time indicators in order to produce 
				an array of reports encompassing everything from steel production to labor costs and EDITDA for nearly every major steel manufacturer in the world.  
				While no longer operational in its current form, the original GSF remains available to non-WSD subscribers as an example of WSD's unparalleled 
				steel industry knowledge and Dreamware Systems ability to portray that knowledge via a dynamic online financial reporting engine.
			</div>
		</div>
		<!--
		<div class="section_titlebox">CooCoo - iPhone/Android Mobile App &amp; Mobile POS Payment System</div>
		<div class="project_box_green project_title">
			<div class="project_coocooweb">
				<a href="http://www.coocoo.com/" target="_blank"></a>
			</div>
			<div class="project_text">
				CooCoo is the leading developer of innovative, mobile solutions that have transformed the way we travel.  While started as a text-message 
				based company, CooCoo has expanded to meet the demands of the world of transit.  Train schedules, transit rates and all things travel are 
				well within the company's umbrella.  Mike Jones, as a member of Dreamware Systems LLC, worked on-site to develop CooCoo's web, mobile and  
				back-end systems to provide customers with real-time transit information.  Additionally, we build the first mobile Point-of-Sale system 
				for processing train tickets in real-time onboard moving trains via the Linea-Pro credit card iPhone attachment and a secure connection
				to CooCoo's in-house, PCI-compliant, fail-safe payment processing servers.
			</div>
		</div>
		-->
		
	</div>
<?php

$PT->printContentEnd();
$PT->printWrapperEnd();
$PT->outputPage();
?>