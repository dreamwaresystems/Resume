<?php
include_once('../library/start.php');
$PT = new DreamwarePageTemplate();
$PT->printWrapperBegin("products");
$PT->printContentBegin(true);
?>
	
	<div class="general_box_left" style="margin-top:40px;">
	
		<div class="page_title">Company-Owned Products & Ventures</div>
		<div class="clearbox">
			In addition to providing third-party software solutions, Dreamware Systems LLC owns and maintains numerous software
			products and ventures.
		</div>
		
		
		<div class="section_titlebox project_title">Albanytakeout - Website</div>
		<div class="project_box_green">
			<div class="project_albanytakeout">
				<a href="http://www.albanytakeout.com/" target="_blank"></a>
			</div>
			<div class="project_text">
				Albanytakeout was one of the first and to this day, one of the most trafficked website ventures undertaken by Dreamware Systems LLC. 
				Albanytakeout is a easy-to-use, queryable database of restaurant menus for the capital region of New York State.  Founded in 2006, 
				the site brandishes over 300 restaurant menus maintained largely by the restaurant owners themselves through our back-end  
				management system.
			</div>
		</div>
		
	</div>
	
<?php

$PT->printContentEnd();
$PT->printWrapperEnd();
$PT->outputPage();
?>