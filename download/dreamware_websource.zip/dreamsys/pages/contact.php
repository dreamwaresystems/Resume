<?php
include_once('../library/start.php');
global $CONFIG;

$error = "";
$success = "";
if($_POST['submit']!="")
{
	if($_POST['name']=="" || $_POST['email']=="" || $_POST['message']=="")
		$error = "Please provide a name, email and a brief message";
	if($error=="")
	{
		$subject = "Web Contact / Inquiry for Dreamware Systems";
		
		$message = "<b>Name:</b> ".$_POST['name']."<br />";
		$message .= "<b>Email:</b> ".$_POST['email']."<br />";
		$message .= "<b>Phone:</b> ".$_POST['phone']."<br />";
		$message .= "<b>Topic:</b> ".$_POST['topic']."<br />";
		$message .= "<b>Comment:</b><br /><br />".$_POST['comment']."<br />";
		
		send_email($CONFIG->admin_email, $subject, $message);
		$success = "yes";
		
		foreach($_POST as $name => $value)
			$_POST[$name] = "";
	
	}
}

$PT = new DreamwarePageTemplate();
$PT->printWrapperBegin("contact");
$PT->printContentBegin(true);
?>
	<div class="general_box_center" style="width:70%;margin-top:40px;">
	
		<div class="page_title">Contact Dreamware Systems</div>
		<div class="clearbox">
			
			<?php
				if($error!="")
					echo '<div class="error_message">'.$error.'</div>';
				else if($success!="")
					echo '<div class="success_message">Your message has been sent. We will respond shortly. Thank you.</div>';
			
			?>
			<table class="contact_form_tbl">
				<form name="contact" action="<?=$CONFIG->url?>pg/contact" method="POST">
				
					<tr><td align="right">Full Name</td>
						<td><input name="name" type="text" size="32" value="<?=$_POST['name']?>" /></td>
					</tr>
					<tr><td align="right">Email Address</td>
						<td><input name="email" type="text" size="45" value="<?=$_POST['email']?>" /></td>
					</tr>
					<tr><td align="right">Phone (optional)</td>
						<td><input name="phone" type="text" size="15" value="<?=$_POST['phone']?>" /></td>
					</tr>
					<tr><td align="right">Regarding</td>
						<td>
							<select name="topic">
								<?php
									$options = array(
										'software' => 'Software Development Inquiry',
										'advertising' => 'Advertising Inquiry',
										'legal' => 'Legal Inquiry',
										'support' => 'Support Request',
										'other' => 'Other');
									
									foreach($options as $name => $value)
									{
										$selected = "";
										if($name==$_POST['topic'])
											$selected = ' selected="selected" ';
										echo '<option value="'.$name.'" '.$selected.'>'.$value.'</option>';
									}
								?>
							</select>
						</td>
					</tr>
						<tr><td align="right" valign="top">Message</td>
						<td>
							<textarea name="message" cols="45" rows="5"><?=$_POST['comment']?></textarea>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<input type="submit" name="submit" value="Submit" class="submit_button"/>
						</td>
					</tr>
				</form>
			</table>
		</div>
		
	</div>
	<div class="clear" style="margin-bottom:12px;">&nbsp;</div>
<?php

$PT->printContentEnd();
$PT->printWrapperEnd();
$PT->outputPage();
?>