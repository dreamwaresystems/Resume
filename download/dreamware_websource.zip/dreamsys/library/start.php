<?php

// begin session
session_start(); 

global $CONFIG;

// essential framework settings
if (!include_once(dirname(__FILE__) . "/settings/dbconnect.php")) {	
	echo "Error: could not load the template library.";
	exit;
}

// core library files
if (!include_once(dirname(__FILE__) . "/settings/server.php")) {	
	echo "Error: could not load overlord.  Overlord: Feed me.";
	exit;
}
if (!include_once(dirname(__FILE__) . "/functions.php")) {	
	echo "Error: could not load the function file.";
	exit;
}
if (!include_once(dirname(__FILE__) . "/encryption.php")) {	
	echo "Error: could not load the encryption code file.";
	exit;
}
if (!include_once(dirname(__FILE__) . "/security.php")) {	
	echo "Error: could not load the security library file.";
	exit;
}
if (!include_once(dirname(__FILE__) . "/views.php")) {		
	echo "Error: could not load the view library file.";
	exit;
}


// class libraries
foreach(glob($CONFIG->root."library/classes/*.php") as $filename)
{	
	if(!include_once($filename)) 
	{	
		echo "Error: could not load the ".$filename." class file.";
		exit;
	}
}

// template libraries
foreach(glob($CONFIG->root."library/templates/*.php") as $filename)
{	
	if(!include_once($filename))
	{	
		echo "Error: could not load the ".$filename." template file.";
		exit;
	}
}


/*
if (!include_once(dirname(__FILE__) . "/templates/template.php")) {	
	echo "Error: could not load the template library.";
	exit;
}
if(isset($TEMPLATE) && $TEMPLATE!="")
{
	// extended templates
	if (!include_once(dirname(__FILE__) . "/templates/".$TEMPLATE.".php")) {	
		echo "Error: could not load the template library.";
		exit;
	}
}
*/



?>