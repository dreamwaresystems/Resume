<?php


/*
   Mike Jones
   These are the handlers for formns
   4/22/2009
  
   Handler Commands have the following form:
   function(&$datatable, $table_name, $extra)	
    //  datatable = datatable of data
	//  table_name = database name for table
	//
	
   Pre-Handler Commands have the following form:
   function(&$datatable, $table_name)	
    //  datatable = datatable of data
	//  table_name = database name for table
	//
	
*/

	
	function main_search_handler(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG; //form variables
		
		$url = $CONFIG->url."search/0/";
		foreach($datatable as $Entry)
		{
			if($Entry['data']!="" && $Entry['data']!="All")
			{
				$url .= $Entry['name']."/".urlencode(sanitize_string($Entry['data']))."/";
			}
		}

		forward($url);
	}
	
	//=============================================================================
	//  Create user
	//=============================================================================
    function create_user_command(&$datatable, $table_name, $PT)
	{
		global $F, $CONFIG;
		$salt = "";

		//encrypt password
		$username = sanitize_string($datatable[1]['data']);
		$raw_pass = $datatable[2]['data'];
		$email = sanitize_string($datatable[4]['data']);
		
		$Cipher = new Cipher();
		$iv = $Cipher->create_iv();
		$Cipher->set_iv($iv);
		$password = $Cipher->encrypt($raw_pass);
		
		$password = base64_encode($password);
		$iv = base64_encode($iv);
		$code = generate_random_hex();
		
		//insert with no encryption
		$query = "INSERT INTO `de_users` (`sid`, `username`, `password`, `salt`, `email`, `code`, `time_created`) VALUES (";
		$query .= "'".$_SESSION['sid']."', ";
		$query .= "'".$username."', ";
		$query .= "'".$password."', ";
		$query .= "'".$iv."', ";
		$query .= "'".$email."', ";
		$query .= "'".$code."', ";
		$query .= "'".get_time()."');";
		db_query($query);

		$uid = mysql_insert_id();
		send_registration_email($email, $uid, $code);
		
		forward('pages/login.php?register=1&uid='.$uid);
	}


    //=========================================//
  	//  Login user 
	//=========================================//
  	function login_user_command(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG; //form variables
		
		//get all necesary variables
		$username = sanitize_string($datatable[1]['data']);
		$submitted_passkey = $datatable[3]['data'];
		$login_hash = $_SESSION['login_hash'];
		$ip = $_SERVER['REMOTE_ADDR'];
		
		//first make sure this person hasn't logged in too many times recently 
		$login_block_time = 15;  //minutes until login block resets
		$login_attempts = 10;     //max allowed bad login attempts in time specified
		$time_offset = get_time() - (60*10);   //10 minutes
		$query = "SELECT * FROM `de_login_log` WHERE `username` = '".$username."' AND time_created > ".$time_offset." AND `success` = 0;";
		$result = mysql_query($query);
		$count = 0;
		if($result)
			$count = mysql_num_rows($result);
		if($count > $login_attempts)
			return "You username has been blocked for security reasons.<br> Please contact support for help.";
		
		//get user profile info from DB
		$query = "SELECT * FROM `de_users` WHERE `username` = '".$username."' LIMIT 1;";
		$result = mysql_query($query);
		if(!$result)	
			return "That username does not exist";
		else if($row = mysql_fetch_array($result))
		{
			//get user info from database
			$encrypted_password = base64_decode($row["password"]);
			$iv = base64_decode($row['salt']);
			$uid =    $row["uid"];
			$admin =  $row["admin"];
			$validated =  $row["validated"];
			
			if($validated==0)
			{
				forward('pages/login.php?register=1&uid='.$uid);
			}
			
			//check password
			$Cipher = new Cipher();
			$Cipher->set_iv($iv);
			$password = $Cipher->decrypt($encrypted_password);
			$actual_passkey = hash_password($password, $login_hash);
			$success = false;
			if($actual_passkey == $submitted_passkey)
				$success = true;
				
			//log this in the login log
			$query = "INSERT INTO `de_login_log` (`uid`,`username`,`time_created`, `ip_address`,`success`) VALUES ( ";
			$query .= "'".$uid."', '".$username."', '".get_time()."', '".$ip."', '".$success."');";
			$result = mysql_query($query);
			
			if($success)
			{
				//setup session
				$_SESSION['uid'] = $uid;
				$_SESSION['username'] = $username;
				$_SESSION['admin'] = $admin;
				$_SESSION['email'] = $row['email'];
				
				//check for redirect 
				$review = $_SESSION['review'];
				if($review!="")
					forward($CONFIG->url."restaurant/".$review);
				else
					forward();
			}
			else
				return "Invalid login.";
		}
		
		return "Invalid login.";
	}
	
	
    //=============================================================================
  	//  Tell a Friend Friend Command
	//=============================================================================
    function invite_friend_command(&$datatable, $table_name, $extra)
	{
		global $F, $CONFIG;
		
		$name = sanitize_string($datatable[1]['data']);
		$email = sanitize_string($datatable[2]['data']);
		$msg = strip_tags(sanitize_string($datatable[3]['data']));
		$_SESSION['invite_msg'] = $msg;
		
		$subject = "Your friend invited you to ".$CONFIG->sitename;
		
		$message = "Dear ".$name.", <br />".$msg.'<br /><br /><a href="'.$CONFIG->url.'">'.$CONFIG->url.'</a>';
		$message .= $CONFIG->span; //spam disclaimer
		
		send_email($email, $subject, $message, 0);
		
		forward('pages/invite.php?sent=1');
	}
	
	//================ Pre Handler =======================//
  	function invite_friend_prehandler(&$datatable, $table_name)
	{
		global $F, $CONFIG; //form variables
		
		$msg .= "I found this great site to find restaurant menus in Albany. Check it out!";
		
		if($_SESSION['invite_msg']=="")
			$datatable[3]['data'] = unsanitize_string($msg);
		else
			$datatable[3]['data'] = $_SESSION['invite_msg']; //use their last message
	}
	
  
		//=========================================//
  	//  Post Review Command
	//=========================================//
  	function post_review_prehandler(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG; //form variables
		
		//get all necesary variables
		if($_SESSION['uid']!="")
		{
			$datatable[4]['data'] = $_SESSION['username'];
			$datatable[5]['data'] = $_SESSION['email'];
		}
	}
	
	//=========================================//
  	//  Post Review Command
	//=========================================//
  	function post_review_command(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG; //form variables
		
		//get all necesary variables
		$rating = sanitize_string($datatable[1]['data']);
		$price = sanitize_string($datatable[2]['data']);
		$comment = sanitize_string($datatable[3]['data']);
		$nickname = sanitize_string($datatable[4]['data']);
		$email = sanitize_string($datatable[5]['data']);
		$rid = $extra;
		$uid = $_SESSION['uid'];
		$ip = $_SERVER['REMOTE_ADDR'];
		
		//first make sure this person hasn't reviewed this restaurant in the last hour
		$review_block_time = 60;  //minutes until unblocked
		$time_offset = get_time() - (60*$review_block_time);
		$query = "SELECT * FROM `de_reviews` WHERE `rid` = '".$rid."' AND `ip` = '".$ip."' AND time_created > '".$time_offset."' ";
		$result = db_query($query);
		$count = mysql_num_rows($result);
		if($count > 0 && !is_admin())
			forward($CONFIG->url.'restaurant/'.$rid.'/fail');
		
		$code = generate_random_hex();
		
		$approved = 0;
		if($comment=="" || is_admin()) //automatically approve ratings without comments
			$approved = 1;
			
		//submit review
		$query = "INSERT INTO `de_reviews` (`rid`, `uid`, `nickname`, `email`, `rating`, `price`, `ip`, `approved`, `comment`, `code`, `time_created`) VALUES ( ";
		$query .= "'".$rid."', ";
		$query .= "'".$uid."', ";
		$query .= "'".$nickname."', ";
		$query .= "'".$email."', ";
		$query .= "'".$rating."', ";
		$query .= "'".$price."', ";
		$query .= "'".$ip."', ";
		$query .= "'".$approved."', ";
		$query .= "'".$comment."', ";
		$query .= "'".$code."', ";
		$query .= "'".get_time()."'); ";
		$result = db_query($query);
		
		$review_id = mysql_insert_id();
		//$UserObj = new UserClass($uid);
		$RestObj = new RestaurantClass($rid);
		
		//send email to admin
		$admin_email = $CONFIG->email_support;
		$txt = 'Review is from: <br />';
		$txt .= '<table border="0">';
		$txt .= '<tr><td><b>Nickname: </b></td><td>'.$nickname.'</td></tr>';
		$txt .= '<tr><td><b>Email Address: </b></td><td><a href="mailto:'.$email.'">'.$email.'</a></td></tr>';
		$txt .= '<tr><td><b>IP Address: </b></td><td>'.$ip.'</td></tr>';
		$txt .= '<tr><td><b>Restaurant: </b></td><td> <a href="'.$CONFIG->url.'restaurant/'.$RestObj->rid.'">'.$RestObj->name.'</a></td></tr>';
		$txt .= '</table><br /><br />';
		
		$txt .= 'Review contents: <br />';
		$txt .= '<table border="0">';
		$txt .= '<tr><td><b>Rating: </b></td><td>'.$rating."</td></tr>";
		$txt .= '<tr><td><b>Price:  </b></td><td>'.$price.'</td></tr>';
		$txt .= '<tr><td><b>Comment:</b></td><td>';
		$txt .= '"'.$comment.'"</td></tr>';
		$txt .= '</table><br /><br />';
		
		if($approved==1)
		{
			$txt .= '<br />NOTE: Since this review did not contain a comment, it was automatically approved...';
		}
		else
		{
			$txt .= '<br /><a href="'.$CONFIG->url.'actions/flag_comment.php?review_id='.$review_id.'&code='.$code.'&opt=1">Approve this comment</a>';
			$txt .= '<br /><a href="'.$CONFIG->url.'actions/flag_comment.php?review_id='.$review_id.'&code='.$code.'&opt=0">Flag this comment as abuse</a>';
		}
		
		if(!is_admin())
			send_email($admin_email, $CONFIG->shortname." | Review Submission", $txt, 0);
		else
			forward($CONFIG->url.'restaurant/'.$rid);
			
		forward($CONFIG->url.'restaurant/'.$rid.'/thanks');
	}
	
	    //=============================================================================
  	//  Password Reset Command
	//=============================================================================
    function reset_password_command(&$datatable, $table_name, $extra="")
	{
		global $F, $CONFIG;
		$username = sanitize_string($datatable[1]['data']);
		$email = sanitize_string($datatable[2]['data']);
			
		$query = "SELECT * FROM `de_users` WHERE `username` = '".$username."';";
		$result = db_query($query);
		if($result && $row = mysql_fetch_array($result))
		{
			$plaintext = generate_random_password();
			
			$Cipher = new Cipher();
			$iv = $Cipher->create_iv();
			$Cipher->set_iv($iv);
			
			$new_password = $Cipher->encrypt($plaintext);
		
			//send email
			$subject = "Your ".$CONFIG->shortname." Account Request";
			$message = "Your ".$CONFIG->shortname." password has been reset to the following:\n\n\n";
			$message .= "Username: ".$username."\n";
			$message .= "Password: ".$plaintext."\n \n ";
			$message .= 'You can <a href="'.$CONFIG->url.'pages/login.php">login here</a>';
			$message .= "\n\nRegards, \nThe ".$CONFIG->shortname." support team";
			
			if(defined('LOCAL'))
				echo $message;
			else
				send_email($email, $subject, $message, 0);
			
			//now update database with the new password
			$query = "UPDATE de_users SET `password` = '".base64_encode($new_password)."', ";
			$query .= " `salt` = '".base64_encode($iv)."' WHERE `username` = '".$username."';";
			db_query($query);
			
			forward("pages/messages.php?id=113");
		}
		else
			forward("pages/messages.php?id=143");
	}
	

    function reset_password_validator(&$datatable, $table_name, $extra="")
	{
		global $F, $CONFIG;
		if($_SESSION['pass_reset']=="")
			$_SESSION['pass_reset']=0;
		
		$username = sanitize_string($datatable[1]['data']);
		$email = sanitize_string($datatable[2]['data']);
		$err_msg = "We could not find that username/email combination in our records.";

		$query = "SELECT * FROM `de_users` WHERE `username` = '".$username."' AND `email` = '".$email."' LIMIT 1;";
		$result = db_query($query);
		$count = mysql_num_rows($result);
		if($count==0)
		{
			$_SESSION['pass_reset']++; //security precaution
			if($_SESSION['pass_reset']>5)
				forward("pages/messages.php?code=123");
			return $err_msg;
		}
		return "";		
	}
	
	//=============================================================================
  	//  Forgot Username Command
	//=============================================================================
    function forgot_username_command(&$datatable, $table_name, $extra)
	{
		global $F, $CONFIG;
		$email = sanitize_string($datatable[1]['data']);
		$err_msg = "We could not find that email address in our records.";
		$query = "SELECT * FROM `de_users` WHERE `email` = '".$email."' LIMIT 1;";
		
		$result = db_query($query);
		if($row = mysql_fetch_array($result))
		{
			//send email 
			$email = $row['email'];
			$username = $row['username'];
			
			$subject = "Username request from ".$CONFIG->domain;
			$message = "Your ".$CONFIG->sitename." username: ".$username;
			$message .= "<br /><br />This request was made at ".$CONFIG->domain.".  If you have received this email in error";
			$message .= ' please contact <a href="'.$CONFIG->email_support.'">'.$CONFIG->email_support."</a>";
			
			send_email($email, $subject, $message, 0);
			
			forward("pages/messages.php?id=145");
		}
			
		return "";
	}
	//=============== Forgot username Validator ===================//
    function forgot_username_validator(&$datatable, $table_name, $extra = "")
	{
		global $F, $CONFIG;
		$email = sanitize_string($datatable[1]['data']);
		$err_msg = "We could not find that email address in our records.";
		$query = "SELECT * FROM `de_users` WHERE `email` = '".$email."' LIMIT 1;";
		
		$result = db_query($query);
		$count = mysql_num_rows($result);
		//die("COUNT: ".$count);
		if($count<=0)
			return $err_msg;
		return "";
	}
	
	    //=============================================================================
  	//  Feedback Form Command
	//=============================================================================
    function feedback_command(&$datatable, $table_name, $extra)
	{
		global $F, $CONFIG;
		
		$receiver = $CONFIG->email_support;
		
		$name = sanitize_string($datatable[1]['data']);
		$email = sanitize_string($datatable[2]['data']);
		$feedback = sanitize_string($datatable[3]['data']);

		$message = "Feedback from ".$CONFIG->sitename.": <br /><br />";
		$message .= "<br />Name:  ".$name;
		$message .= '<br />Email: <a href="mailto:'.$email.'">'.$email.'</a>';
		$message .= '<br /><br />'.$feedback.'<br />';
		
		$subject = "Feedback from webform";
		
		send_email($receiver, $subject, $message, 0);
	}

	
	
	//===================================
	//  Newsletter Form
	//===================================
	function newsletter_handler(&$datatable, $table_name, $extra)
	{
		global $F;
		$query = "INSERT INTO `de_newsletter` (`sid`, `email`, `time_created`) VALUES (";
		$query .= "'".$_SESSION['sid']."', ";
		$query .= "'".sanitize_string($datatable[1]['data'])."', ";
		$query .= "'".get_time()."');";
		db_query($query);
	}	

	
	
	//==================================================
	//  Change Password Command (IN account settings)
	//==================================================
	function change_password_handler(&$datatable, $table_name, $extra)
	{
		global $F, $CONFIG;
		$user_pass = $datatable[2]['data'];
		
		$Cipher = new Cipher();
		$salt = $Cipher->create_iv();
		$Cipher->set_iv($salt);
		$password = $Cipher->encrypt($user_pass);
		$password = base64_encode($password);
		$salt = base64_encode($salt);
		
		$query = "UPDATE `de_users` SET ";
		$query .= "`password` = '".$password."', ";
		$query .= "`salt` = '".$salt."' ";
		$query .= " WHERE `uid` = '".$_SESSION['uid']."'";
		$result = db_query($query);
	}
	
    //==================================================
	//  Change Email Command (IN account settings)
	//==================================================
	function change_email_handler(&$datatable, $table_name, $extra)
	{
		global $F, $CONFIG;
		$old = sanitize_string($datatable[1]['data']);
		$new1 = sanitize_string($datatable[2]['data']);
		$new2 = sanitize_string($datatable[3]['data']);
		
		$User = new UserClass("", $_SESSION['uid']);
		
		$query = "UPDATE `de_users` SET `email` = '".$new1."' ";
		$query .= "WHERE `uid` = ".$_SESSION['uid']." LIMIT 1;"; 		
		db_query($query);
	}
	function change_email_validator(&$datatable, $table_name, $extra = "")
	{
		global $F, $CONFIG;
		$old = sanitize_string($datatable[1]['data']);
		$new1 = sanitize_string($datatable[2]['data']);
		$new2 = sanitize_string($datatable[3]['data']);
		
		$User = new UserClass($_SESSION['uid']);
		
		if(!check_email_address($new1))
			return "Email address not valid";
		if(trim($new1)!=trim($new2))
			return "Email addresses do not match";
		if($old != $User->email)
			return "Current email doesn't match records";

	}
	function change_email_prehandler(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG;
		$User = new UserClass($_SESSION['uid']);
		$datatable[1]['data'] = $User->email;
	}
	
	
	
	
	//edit address location
	function edit_address_prehandler(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG;
		
		$query = "SELECT * FROM de_address WHERE address_id = '".$extra."';";
		$result = db_query($query);
		if($row=mysql_fetch_array($result))
		{
			$datatable[1]['data'] = unsanitize_string($row['address_1']);
			$datatable[2]['data'] = unsanitize_string($row['address_2']);
			$datatable[3]['data'] = unsanitize_string($row['city']);
			$datatable[4]['data'] = unsanitize_string($row['state']);
			$datatable[5]['data'] = $row['zipcode'];
			
			$datatable[6]['data'] = $row['phone'];
			$datatable[7]['data'] = $row['fax'];
		}
	}
	
	
	
	//edit restaurant basic info
	function edit_basicinfo_prehandler(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG;
		$query = "SELECT * FROM de_restaurants WHERE rid = '".$extra."';";
		$result = db_query($query);
		if($row=mysql_fetch_array($result))
		{
			$datatable[1]['data'] = unsanitize_string($row['name']);
			$datatable[2]['data'] = $row['delivery'];
			$datatable[3]['data'] = $row['deliv_min'];
			$datatable[4]['data'] = $row['website'];
		}
		
		//get paypass
		/*$query = "SELECT * FROM `de_paypass`, `de_paypass_map` WHERE `de_paypass`.`paypass_id` = `de_paypass_map`.`paypass_id` AND ";
		$query .= "`de_paypass_map`.`rid` = '".$extra."';"; //rid
		$result = db_query($query);
		if($row=mysql_fetch_array($result))
			$datatable[5]['data'] = unsanitize_string($row['paypass_id']);*/
	}


	//Owner request form
	function owner_request_prehandler(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG;
		if($_SESSION['uid']!="")
		{
			$UserObj = new UserClass($_SESSION['uid']);
			$datatable[4]['data'] = unsanitize_string($UserObj->email);
		}
	}
	//edit restaurant basic info
	function owner_request_command(&$datatable, $table_name, $extra= "")
	{
		global $F, $CONFIG;
		
		$RestObj = new RestaurantClass($extra);
		
		$name = sanitize_string($datatable[1]['data']);
		$title = sanitize_string($datatable[2]['data']);
		$number = sanitize_string($datatable[3]['data']);
		$email = sanitize_string($datatable[4]['data']);
		$addinfo = sanitize_string($datatable[5]['data']);
		
		$txt = "Restaurant Owner access request from:<br /><br />";
		$txt .= "name: ".$name."<br />";
		$txt .= "title: ".$title."<br />";
		$txt .= "number: ".$number."<br />";
		$txt .= "email: ".$email."<br /><br />";
		$txt .= "addinfo: ".$addinfo."<br />";
		$txt .= "RID: ".$extra."<br />";
		$txt .= "Restaurant: ".$RestObj->title."<br />";
		$txt .= "Site: ".$CONFIG->sitename."<br />";
		
		$subject = "Rest Owner Request!";
		
		send_email($CONFIG->email_support, $subject, $txt, 0);

		forward($CONFIG->url.'pages/ownersubmit.php?sent=1');
	}
	
?>