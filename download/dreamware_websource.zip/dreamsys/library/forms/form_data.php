<?php

/*
   Author: Mike Jones
   This file holds the actual form data
  
*/


	/*	Types of input fields
		-----------------------
		t = text
		e = email
		e1, e2 = matching email (validated together, seperate form rows)
		a = array of values
		sa = array of values populated at runtime
		sd_cat = array of values populated at runtime
		z = zip code
		dt = datetime stamp
		ml1 = multi-line box type 1 (small)
		file = a file upload (IMPORTANT: file fields should have names that begin with "f_")
		p = phone number
		dob = Date of Brith
		nick = specific nickname for facebake
		pass = password
		pass1, pass2 = matching passwords (validated together, seperate form rows)
		dob2 = date of birth, in the long form (January 1, 1900)
		section = just output centered text of a section header
		ignore = ignore line for form purposes, just output the $f_d 
		format = css or some kind of formatting, just gets written to screen 
		checkbox = checkbox (I agree usually)
		hash = hidden security hash field
		username = username, needs to be checked against bad characters and such
		elm1 = tiny_mce box
		page = page counter
		currency = currency
		neardate = nearby date like "February, 2013"
		captcha = securimage captcha
		*/
		
		
	function global_load_forms()
	{
		global $CONFIG;      //Table array index references
		global $FORMS;  //this will store our form data

		// homepage newsletter form
		$email_label = '<div id="newsletter_label">Join our newsletter: </div>';
		$FORMS->form_mailing_list = array(
		  1 => array( 'name' => "mailemail" ,   'required' => "1",  'desc' => $email_label,  'type' => "e",   'default' => "enter email address", 'size' => 28, 'max_length' => 40));

		//main search form
		// NOTE: this form is created dynamically at run time
		$FORMS->main_search_form = array();
		
		//friend invite form
		$FORMS->invite_form = array(
		  1 => array( 'name' => "name" ,     'required' => "1",   'desc' => "Name:",                       'type' => "t",       'size' => 25,  'max_length' => 30),
		  2 => array( 'name' => "email" ,    'required' => "1",   'desc' => "Email:",                      'type' => "e",       'size' => 25,  'max_length' => 30),
		  3 => array( 'name' => "personal" , 'required' => "1",   'desc' => "Personalize the message:",    'type' => "ml2",     'size' => 25,  'max_length' => 30),
		  4 => array( 'name' => "none" ,     'required' => "1",   'desc' => "Enter the following code:",   'type' => "captcha"));
		  
		//login form
		$FORMS->login_form = array(
		  1 => array( 'name' => "userlogin" , 'required' => "1",   'desc' => "Username:",         'type' => "t",    'size' => 25,  'max_length' => 30),
		  2 => array( 'name' => "password" ,  'required' => "1",   'desc' => "Password:",         'type' => "pass", 'size' => 25,  'max_length' => 30),
		  3 => array( 'name' => "hash" ,      'required' => "1",   'type' => "hash"));

		//review form
		$label = '<div class="review_rating_label">';
		$com_label ='<div class="review_comment_label">';
		$c = '</div>';
		$email_claimer = '<div class="email_subtitle">(not displayed publicly)</div>';

		/*$disclaim = '<div id="comment_disclaimer">Albanytakeout.com regulates comments made in our review section.  We
						invite, and encourage constructive statements, both positive and
						critical.   We recognize that the integrity of our system, in fact,
						relies on the availability of negative criticism; however we also
						reserve the right to not post comments that are derogatory,
						inflammatory, or otherwise overtly malicious.</div>';
					*/

		$FORMS->review_form = array( 
		  1 => array( 'name' => "rating" ,   'required' => "1",   'desc' => $label."Overall Rating".$c,                   'type' => "a", 'list_name' => "review_rating", 'list_default' => "Average (3)", 'size' => 25,  'max_length' => 30),
		  2 => array( 'name' => "price" ,    'required' => "1",   'desc' => $label."Overall Cost".$c,                     'type' => "a", 'list_name' => "review_price",  'list_default' => "Average (3)", 'size' => 25,  'max_length' => 30),
		  3 => array( 'name' => "comment" ,  'required' => "0",   'desc' => $com_label."Comment (optional)".$disclaim.$c, 'type' => "ml2"),
		  4 => array( 'name' => "nickname" , 'required' => "1",   'desc' => $label."Nickname".$c,                         'type' => "t",    'size' => 25,  'max_length' => 50),
		  5 => array( 'name' => "email" ,    'required' => "1",   'desc' => $label."Email Address".$c,                    'type' => "e",    'size' => 40,  'max_length' => 50, 'after' => $email_claimer));

		//password reset form
		$FORMS->password_reset_form = array(
		  1 => array( 'name' => "username" ,  'required' => "1",   'desc' => "Username:<br />",      'type' => "t",    'size' => 25,  'max_length' => 30),
		  2 => array( 'name' => "email" ,     'required' => "1",   'desc' => "<br />Email:<br />",   'type' => "e",    'size' => 25,  'max_length' => 30));

		//forgot username form
		$FORMS->forgot_username_form = array(
		  1 => array( 'name' => "email" ,  'required' => "1",   'desc' => "Email:<br />",      'type' => "e",    'size' => 25,  'max_length' => 30));

		//feedback form
		$FORMS->feedback_form = array(
		  1 => array( 'name' => "name" ,     'required' => "1",   'desc' => "Name:<br />",                    'type' => "t",    'size' => 25,  'max_length' => 30),
		  2 => array( 'name' => "email" ,    'required' => "1",   'desc' => "<br />Email:<br />",             'type' => "e",    'size' => 25,  'max_length' => 30),
		  3 => array( 'name' => "feedback" , 'required' => "1",   'desc' => "<p>&nbsp;</p>Feedback:<br />",   'type' => "ml2",  'size' => 25,  'max_length' => 30));

		//friend invite form
		$FORMS->emailto_friend_from = array(
		  1 => array( 'name' => "name" ,     'required' => "1",   'desc' => "Name:<br />",                           'type' => "t",    'size' => 25,  'max_length' => 30),
		  2 => array( 'name' => "email" ,    'required' => "1",   'desc' => "<br />Email:<br />",                    'type' => "e",    'size' => 25,  'max_length' => 30),
		  3 => array( 'name' => "personal" , 'required' => "1",   'desc' => "<br />Personalize the message:<br />",  'type' => "ml2",  'size' => 25,  'max_length' => 30),
		  4 => array( 'name' => "none" ,     'required' => "1",   'desc' => "<br />Enter the following code:",       'type' => "captcha"));
		  
		$FORMS->change_password = array(
		  1 => array( 'name' => "old" ,      'required' => "1",   'desc' => "Old Password:",                     'type' => "pass",   'size' => 20,  'max_length' => 25),
		  2 => array( 'name' => "newp1" ,    'required' => "1",   'desc' => "New Password:",                     'type' => "pass1",   'size' => 20,  'max_length' => 25),
		  3 => array( 'name' => "newp2" ,    'required' => "1",   'desc' => "New Password (again):",             'type' => "pass2",   'size' => 20,  'max_length' => 25));
		  
		$FORMS->change_email = array(
		  1 => array( 'name' => "old" ,      'required' => "1",   'desc' => "Current Email:",                  'type' => "e",   'size' => 20,  'max_length' => 25),
		  2 => array( 'name' => "new1" ,     'required' => "1",   'desc' => "New Emaill:",                     'type' => "e",   'size' => 30,  'max_length' => 135),
		  3 => array( 'name' => "new2" ,     'required' => "1",   'desc' => "Retype New Email:",               'type' => "e",   'size' => 30,  'max_length' => 135));

		$FORMS->rest_address = array(
		  1 => array( 'name' => "address_1" ,     'required' => "1",   'desc' => "Address",          'type' => "t",       'size' => 40,  'max_length' => 50),
		  2 => array( 'name' => "address_2" ,     'required' => "0",   'desc' => "Address (line 2)", 'type' => "t",       'size' => 40,  'max_length' => 50),
		  3 => array( 'name' => "city" ,          'required' => "1",   'desc' => "City",             'type' => "t",       'size' => 20,  'max_length' => 40),
		  4 => array( 'name' => "state" ,         'required' => "1",   'desc' => "State",            'type' => "a",       'list_default' => "New York", 'list_name' => "state_list"),
		  5 => array( 'name' => "zipcode" ,       'required' => "1",   'desc' => "Zipcode",          'type' => "z",       'size' => 6, 'max_length' => 7),
		  6 => array( 'name' => "phone" ,         'required' => "1",   'desc' => "Phone #",          'type' => "p"),
		  7 => array( 'name' => "fax" ,           'required' => "0",   'desc' => "Fax #",            'type' => "p"));
				
		$FORMS->rest_basic_info = array(
		  1 => array( 'name' => "name" ,         'required' => "1",   'desc' => "Name",                      'type' => "t",                            'size' => 40,    'max_length' => 50),
		  2 => array( 'name' => "delivery" ,     'required' => "1",   'desc' => "Delivers",                  'type' => "a", 'list_name' => "yesno",    'size' => 40,    'max_length' => 50),
		  3 => array( 'name' => "deliv_min" ,    'required' => "0",   'desc' => "Delivery Mininum",          'default' => "0", 'type' => "t",                           'size' => 20,  'max_length' => 20),
		  4 => array( 'name' => "website" ,      'required' => "0",   'desc' => "Website",                   'type' => "t",                            'size' => 40,    'max_length' => 150));						
		$FORMS->owner_form = array(
		  1 => array( 'name' => "fullname" ,      'required' => "1",   'desc' => "Your Full Name",             'type' => "t",         'size' => 40,  'max_length' => 50),
		  2 => array( 'name' => "jobtitle" ,      'required' => "1",   'desc' => "Your job title",             'type' => "t",         'size' => 40,  'max_length' => 50),
		  3 => array( 'name' => "phone" ,         'required' => "1",   'desc' => "Contact Number",             'type' => "p",         'size' => 40,  'max_length' => 50),
		  4 => array( 'name' => "email" ,         'required' => "1",   'desc' => "Email",                      'type' => "e",         'size' => 40,  'max_length' => 50),
		  5 => array( 'name' => "message" ,       'required' => "0",   'desc' => "Any additional information", 'type' => "ml2",       'size' => 40,  'max_length' => 50));
				
				
		//=====================================
		// This for the register form
		//=====================================
		
		//reused formatting
		$terms_link = '&nbsp;&nbsp;I agree with the <a href="'.$CONFIG->url.'view/terms" target="_blank">terms of use</a><br />';
		$terms_link .= '&nbsp;&nbsp;<span class="small_terms">(our lawyers made us do this)</span>';
		
		$password_subtext = '<br /><span class="small_terms">(must be at least 7 characters long)</span>';
		$label_o = '<div class="register_label">';
		$c = '</div>';
		
		//actual registration form
		$FORMS->register_user = array(
		  1 => array( 'name' => "username",    'required' => "1",   'desc' => $label_o."Create Username".$c,               		'type' => "username",          			'size' => 25,  'max_length' => 20),
		  2 => array( 'name' => "password",    'required' => "1",   'desc' => $label_o."Create a Password".$password_subtext.$c,   'type' => "pass1",   'spacer' => 1,    'size' => 25,  'max_length' => 20),
		  3 => array( 'name' => "password2",   'required' => "1",   'desc' => $label_o."Re-enter Your Password".$c,         		'type' => "pass2",                      	'size' => 25,  'max_length' => 20),
		  4 => array( 'name' => "email" ,      'required' => "1",   'desc' => $label_o."Enter Your Email Address".$c,       		'type' => "e1",      'spacer' => 1,    'size' => 35,  'max_length' => 120),
	      5 => array( 'name' => "email2" ,     'required' => "1",   'desc' => $label_o."Re-enter Your Email Address".$c,    		'type' => "e2",                        	'size' => 35,  'max_length' => 120),
		  6 => array( 'name' => "agreement" ,  'required' => "1",   'desc' => $label_o.$terms_link.$c,                      		'type' => "checkbox",'spacer' => 1,	'size' => 25,  'max_length' => 20));


		//==============================
		//  Restaurant edit forms
		//==============================
		$label ='<div class="edit_rest_label">';
		$FORMS->edit_foodtype = array(
		  1 => array( 'name' => "foodtype",    'required' => "1",   'desc' => $label."Add Food Type".$c,    'type' => "a", 'list_name' => "edit_foodtype",	'size' => 25,  'max_length' => 20));		  
		
	}



	//load form lists
	function global_load_form_lists()
	{
		global $FORM_LISTS; //store form lists

		$FORM_LISTS->foodtype = get_foodtype_array();
		$FORM_LISTS->zipcodes = get_zipcode_array();
		$FORM_LISTS->regions = get_region_array();
		$FORM_LISTS->colleges = get_college_array();
		$FORM_LISTS->cities = get_city_array();
		$FORM_LISTS->paypass = get_paypass_options(1);
		
		//edits
		$FORM_LISTS->edit_foodtype = get_foodtype_array(1);
		//$FORM_LISTS->regions = get_region_array(0);
		
		$FORM_LISTS->select_number = array('1' => 'Select Number');

		$FORM_LISTS->review_price = array(
			'1'=>'Very Inexpensive (1)',
			'2'=>'Inexpensive (2)',
			'3'=>'Average (3)',
			'4'=>'Expensive (4)',
			'5'=>'Very Expensive (5)',);
			
		$FORM_LISTS->review_rating = array(
			'1'=>'Very Poor (1)',
			'2'=>'Poor (2)',
			'3'=>'Average (3)',
			'4'=>'Good (4)',
			'5'=>'Excellent (5)',);
			
		$FORM_LISTS->month_list = array(
			'1'=>"January",  
			'2'=>"February",
			'3'=>"March",
			'4'=>"April",  
			'5'=>"May",
			'6'=>"June",
			'7'=>"July",
			'8'=>"August",
			'9'=>"September",
			'10'=>"October",
			'11'=>"November",
			'12'=>"December");
		
		$FORM_LISTS->credit_cards = array(
			'1'=>"Visa",  
			'2'=>"Mastercard",
			'3'=>"Discover",
			'4'=>"American Express");

		$FORM_LISTS->yesno = array(
			'1'=>'No',
			'2'=>'Yes');
			
		//the 50 states
		$FORM_LISTS->state_list = array(
			'AL'=>"Alabama",  
			'AK'=>"Alaska",  
			'AZ'=>"Arizona",  
			'AR'=>"Arkansas",  
			'CA'=>"California",  
			'CO'=>"Colorado",  
			'CT'=>"Connecticut",  
			'DE'=>"Delaware",  
			'DC'=>"District Of Columbia",  
			'FL'=>"Florida",  
			'GA'=>"Georgia",  
			'HI'=>"Hawaii",  
			'ID'=>"Idaho",  
			'IL'=>"Illinois",  
			'IN'=>"Indiana",  
			'IA'=>"Iowa",  
			'KS'=>"Kansas",  
			'KY'=>"Kentucky",  
			'LA'=>"Louisiana",  
			'ME'=>"Maine",  
			'MD'=>"Maryland",  
			'MA'=>"Massachusetts",  
			'MI'=>"Michigan",  
			'MN'=>"Minnesota",  
			'MS'=>"Mississippi",  
			'MO'=>"Missouri",  
			'MT'=>"Montana",
			'NE'=>"Nebraska",
			'NV'=>"Nevada",
			'NH'=>"New Hampshire",
			'NJ'=>"New Jersey",
			'NM'=>"New Mexico",
			'NY'=>"New York",
			'NC'=>"North Carolina",
			'ND'=>"North Dakota",
			'OH'=>"Ohio",  
			'OK'=>"Oklahoma",  
			'OR'=>"Oregon",  
			'PA'=>"Pennsylvania",  
			'RI'=>"Rhode Island",  
			'SC'=>"South Carolina",  
			'SD'=>"South Dakota",
			'TN'=>"Tennessee",  
			'TX'=>"Texas",  
			'UT'=>"Utah",  
			'VT'=>"Vermont",  
			'VA'=>"Virginia",  
			'WA'=>"Washington",  
			'WV'=>"West Virginia",  
			'WI'=>"Wisconsin",  
			'WY'=>"Wyoming");

			
	}



?>