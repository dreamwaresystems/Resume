<?php

//===========================================================================
//  This is Mike Jones' form system 3.0 4/24/2010 Built for SHOPROC.COM
//  -------------------------------------------------------------------
//  This file stores the functions that implement outputting, validating
//  and storing form data.
//=============================================================================*/


class WebForm
{
	//data passed to the form class
	protected $m_root = ""; //root directory
	protected $m_PT = null; //page template class (for writing to)

	//these string are to allow customization of the form from the calling function
	protected $m_form_header = "<table>";
	protected $m_form_closer = "</table>";
	protected $m_error_header = "";
	protected $m_error_closer = "";
	protected $m_display_error_message = true;
	protected $m_use_horz_table = false;
	protected $m_use_css = false; //use a css table
	protected $m_print_local_errors = false; //print errors next to each box
	protected $m_is_login_form = false;
	protected $m_two_column_text = false;
	protected $m_page_prev = false;
	protected $m_extra = "";
	protected $m_css_arr = array();
	protected $m_submit_replace = "";
	
	public function set_page_prev($val) {$this->m_page_prev = $val;}
	public function set_use_horz_table($val) {$this->m_use_horz_table = $val;}
	public function set_display_error_messages($val) {$this->m_display_error_message = $val;}
	public function set_form_header($pheader) {$this->m_form_header = $pheader;}
	public function set_form_closer($closer) {$this->m_form_closer = $closer;}
	public function set_error_header($pheader) {$this->m_error_header = $pheader;}
	public function set_error_closer($closer)	{$this->m_error_closer = $closer;}             
	public function set_use_css($value) {$this->m_use_css = $value;}                          //use form specified css or table codes
	public function set_print_local_erros($value) {$this->m_print_local_errors = $value;}  
	public function set_login_form($value) {$this->m_is_login_form = $value;} //set login form and use "SubmitForm()" as action to allow js hashing
	public function set_two_column_text($value) {$this->m_two_column_text = $value;} //set two columns, right side is f_after
	public function set_extra($value) {$this->m_extra = $value;} //Albanytakeout item ID (for purchase form)
	public function set_css_array($value) {$this->m_css_arr = $value;} 
	public function set_submit_replacement_code($value) {$this->m_submit_replace = $value;}
	
	//to set the code that gets executed upon success
	protected $m_success_code = "Form submitted successfully";
	public function set_success_code($code) {$this->m_success_code = $code;}
	
	protected $m_is_error = false; //flags if error is present, output different css on each input
	protected $m_form_name = "";
	
	//constructor
	function __construct ($root_dir, $page_template )  
	{
		$this->m_root = $root_dir;
		$this->m_PT = $page_template;
		
		//load form data
		global_load_form_lists();
		global_load_forms();
		
	}
	
	//==============================================================
	//This is the main function that's gonna output the whole form
	//==============================================================
	/*
		$data = the table array of form data
		$total = the total fields in the table
		$submit = whether the form has been submitted (the post value)
		$table_name = the name of the table in the database, or blank if it's gonna be emailed
		$success_text = what to output when the form is successfully submitted
		$file_folder = folder for files to be uploaded to (can be left blank if no uploads are needed)
		$file_prefix = prefix to add to any file being uploaded (cen be left blank if no uploads needed)
	*/
	public function output_form($form_name, $table_name, $button_text, $file_folder, $file_prefix, $handler = "", $pre_handler = "", $name_override = "", $form_validator = "")
	{
		global $F, $CONFIG;
				
		//save any redirects to the session
		$redirect = $_GET['redirect'];
		if($redirect != "")
			$_SESSION['redirect'] = $redirect;

		$data = $this->get_form($form_name);

		if($name_override != "")
			$form_name = $name_override;
		$this->m_form_name = $form_name;
		
		$total = count($data);
		$page = $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
		$submit = $_POST[$form_name.'_submit']; //whether page was submitted
		$prev = $_POST[$form_name.'_prev']; //whether prev was clicked
	
		if($submit == "" && $pre_handler!="")
		{
			if($this->m_extra!="")
				$pre_handler($data, $table_name, $this->m_extra); //purchase form
			else
				$pre_handler($data, $table_name); //call pre form handler (populator)
		}
		
		$errortext = array();
	
		//CSRF attack prevention
		$server_hash = $_SESSION['csrf_hash'];
		$user_hash = $_POST['csrf_hash'];
		generate_csrf_hash(); //generate new hash
		$csrf_error = "Your session has either expired or has been hijacked.";
		
		
		
		if($submit!="" || $remove!="") //application was submitted or "remove uploaded file" clicked
		{
			//CSRF prevention
			if($server_hash!=$user_hash)
				array_push($errortext, $csrf_error);
				
			//get posted data
			for($i=1;$i<=$total;$i++)
			{
				//these are some special cases we need to handle
				if($data[$i]['type']=="file") //check if we need to handle a file
				{
					//grab file data from previous file submission (if any)
					$data[$i]['data'] = $_POST[$data[$i]['name']."_name"];
					$data[$i]['file'] = $_POST[$data[$i]['name']."_file"];
					
					$file_name = $_FILES[$data[$i]['name']]['name'];
					$file_tmp_name = $_FILES[$data[$i]['name']]['tmp_name'];
					$errortext = $this->handle_file_submission($data[$i], $file_name, $file_tmp_name, $file_folder, $file_prefix, $remove);
				}
				else if($data[$i]['type']=="p")  //phone number
				{
					//get the three pieces of the number and put them together
					$phone_1 = $_POST[$data[$i]['name']."_phone_1"];
					$phone_2 = $_POST[$data[$i]['name']."_phone_2"];
					$phone_3 = $_POST[$data[$i]['name']."_phone_3"];
					if($data[$i]['data']=="")
						$data[$i]['data'] = $phone_1."-".$phone_2."-".$phone_3;
				}
				else if($data[$i]['type']=="dob")  //DOB
				{
					//get the three pieces of the DOB and put them together
					$dob_1 = $_POST[$data[$i]['name']."_dob_1"];
					$dob_2 = $_POST[$data[$i]['name']."_dob_2"];
					$dob_3 = $_POST[$data[$i]['name']."_dob_3"];
					$data[$i]['data'] = $dob_1."/".$dob_2."/".$dob_3;
				}
				else if($data[$i]['type']=="dob2")  //DOB long entry
				{
					//get the three pieces of the DOB and put them together
					$dob_1 = $_POST[$data[$i]['name']."_dob_1"];
					$dob_2 = $_POST[$data[$i]['name']."_dob_2"];
					$dob_3 = $_POST[$data[$i]['name']."_dob_3"];
					$data[$i]['data'] = $dob_1.", ".$dob_2." ".$dob_3;
				}
				else if($data[$i]['type']=="neardate") //a nearby date (ex: January, 2008)
				{
					$nbd_1 = $_POST[$data[$i]['name']."_nbd_1"];
					$nbd_2 = $_POST[$data[$i]['name']."_nbd_2"];
					$data[$i]['data'] = $nbd_1.", ".$nbd_2;
				}
				else if($data[$i]['type']=="dt") //time stamp
				{
					$data[$i]['data'] = get_time();
				}
				else
				{
					$post = $_POST[$data[$i]['name']];
					$data[$i]['data'] = $post;
				}
		
			} //end loop through posted data

			
			//call custom validator if there is one
			if($form_validator != "")
			{
				$temp_error = $form_validator($data, $table_name);
				if($temp_error != "")
					array_push($errortext, $temp_error);
			}
				
			//now validate all entries and record any errors
			for($i=1;$i<=$total;$i++)
			{
				$temp_error = $this->validate($data, $i, $submit, 0);
				if($temp_error != "")
					array_push($errortext, $temp_error);
			}
			
			//if errors exists
			if(count($errortext)==0)  //form submitted sucessfully, try to update database
			{
				//update database
				$temp_error = "";
				
				//HANDLE SPECIAL FORMS
				// NOTE: In the future we should create a special callback function for this !!! MTJ
				//       This is crude and is not reusable 
				if($this->m_email_address != "")
					$temp_error = $this->email_form_data($data, $total); //email form data
				else if($handler != "") //form handler specified
				{
					if($this->m_extra != "")
						$temp_error = $handler($data, $table_name, $this->m_extra);
					else
						$temp_error = $handler($data, $table_name, $prev);
				}
				else
					$temp_error = $this->insert_into_database($data, $total, $table_name); //update database using field names
				if($temp_error != "")	
					array_push($errortext, $temp_error);
			}
			
			if(count($errortext)==0) //if still no errors, success
			{
				//SUCESS CODE
				$this->m_PT->write($this->m_success_code);
				return;
			}
		} //end if form submitted
		
		//output any errors
		if(count($errortext)!=0 && $this->m_display_error_message)
		{
			$this->m_PT->write($this->m_error_header);
			$this->m_PT->write($this->print_errors($errortext));
			$this->m_PT->write($this->m_error_closer);
		}
		
		$this->m_PT->write( $this->m_form_header);
		
		//output the form
		if($this->m_is_login_form) //if its a login form, call the javascript function to hash the password first
			$this->m_PT->write( '<form name="'.$form_name.'" action="" onsubmit="return SubmitForm()" method="post" enctype="multipart/form-data">');
		else
			$this->m_PT->write( '<form name="'.$form_name.'" action="'.$page.'" method="post" enctype="multipart/form-data">');

		//csrf attack prevention hash
		$this->m_PT->write(chr(10).'<input name="csrf_hash" type="hidden" value="'.$_SESSION['csrf_hash'].'" />'); 

		
		for($i=1;$i<=$total;$i++)
		{
			$this->output_form_entry($data, $i, $submit, $form_name);
		}
		if(!$this->m_use_css)
		{
			if($this->m_two_column_text)
				$this->m_PT->write('</table>');
			if($this->m_use_horz_table)
				$this->m_PT->write('<td>');
			else
				$this->m_PT->write('<tr><td colspan="2" align="center">');
		}
		
		if($this->m_page_prev)
			$this->m_PT->write('<input type="submit" name="'.$form_name.'_prev" value="Back" />');
		else if($this->m_submit_replace!="")
			$this->m_PT->write($this->m_submit_replace);
		else
			$this->m_PT->write('<input type="submit" name="'.$form_name.'_submit" value="'.$button_text.'" />');
	
		
		if(!$this->m_use_css)
		{
			if($this->m_use_horz_table)
				$this->m_PT->write('</td>');
			else	
				$this->m_PT->write('</td></tr>');
		}
		
		$this->m_PT->write( '</form>');
		
		$this->m_PT->write($this->m_form_closer);

	}
	
	//remove duplicate errors from an array of errors
	public function print_errors($error_list)
	{
		//first remove any duplicate errors
		$final_list = array();
		foreach ($error_list as $key => $value)
		{
			if(!in_array($value, $final_list))
				array_push($final_list, $value);
		}
		
		foreach($final_list as $value)
			$this->m_PT->write( $value."<br />");
	}
	
	//=======================================================
	// This outputs one field of a form table
	/*	
		$arr = one row of a table
		$submitted = whether the form was submitted or not
	*/				  
	protected function output_form_entry(&$full_array, $index, $submitted, $form_name)
	{
		global $CONFIG, $F;
		$page = $_SERVER['PHP_SELF'];
		$arr = $full_array[$index];
		
		$flagfile = 0;
		$type = $arr['type'];
		$this->m_PT->write(chr(10));
		
		//css formatting, just output it
		if($type == "format")
		{
			$this->m_PT->write($arr['desc']);
			return;
		}
		
		$class = "";
		$errors = $this->validate($full_array, $index, $submitted, 0);
		if($errors != "")
			$class = "formerr"; // this is how we mark errors
		
		//get default box size
		if($arr['size']==0)
			$size = "20";  //default box size
		else
			$size = $arr['size'];
			
		//get default max size
		if($arr['size']==0)
			$maxsize = "20";  //default box size
		else
			$maxsize = $arr['max_length'];
			
		//add a spacer before this field if specified
		if($arr['spacer']==1 && !$this->m_use_horz_table && !$this->m_use_css)
			$this->m_PT->write( "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
		
		//section title		
		if($type=="section")
		{
			if(!$this->m_use_css)
			{
				if(!$this->m_use_horz_table)
					$this->m_PT->write( '<tr><td colspan="2" align="center">');
				else
					$this->m_PT->write( '<td>');
			}
			$this->m_PT->write($arr['desc']);
			if(!$this->m_use_css)
			{
				if(!$this->m_use_horz_table)
					$this->m_PT->write( "</td></tr>");
				else
					$this->m_PT->write( '</td>');
			}
			return;
		}
		
		//print description of field		
		if(!$this->m_use_css)
		{
			if($this->m_use_horz_table)
				$this->m_PT->write( '<td>');
			else if($this->m_two_column_text)
				$this->m_PT->write( '<tr><td align="left" valign="top">');
			else
				$this->m_PT->write( '<tr><td align="right" valign="top">');
		}
		
		$this->m_PT->write($this->m_css_arr['label_open']);
		$this->m_PT->write($arr['desc']);
		$this->m_PT->write($this->m_css_arr['label_close']);	
						
		if(!$this->m_use_css && !$this->m_two_column_text)
		{
			if($this->m_use_horz_table)
				$this->m_PT->write( '</td><td>');
			else
				$this->m_PT->write( '</td><td align="left" valign="top">');
		
		}
		else if($this->m_two_column_text)
			$this->m_PT->write( '<br />');
		
		//output input form
		$this->m_PT->write($this->m_css_arr['input_open']);
		if($type == "t" || $type=="e" || $type=="e1" || $type=="e2" || $type=="nick" || $type=="username" || $type=="cc")  //text box
		{
			$id = $form_name.'_'.$arr['name'];
			$script = "";
			$value = $arr['data'];
			if($arr['default']!="")
			{
				if($value=="")
					$value = $arr['default'];
				$script = ' onfocus="ActivateGreyBox(\''.$id.'\', \''.$arr['default'].'\');" ';
			}
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'" id="'.$id.'" value="'.$value.'" size="'.$size.'" maxlength="'.$maxsize.'" '.$script.' />');
		}
		if($type == "pass" || $type == "pass1" || $type == "pass2")  //password
			$this->m_PT->write( '<input type="password" class="'.$class.'" name="'.$arr['name'].'" value="'.$arr['data'].'" size="'.$size.'" maxlength="'.$maxsize.'" />');
		if($type == "z")  //zip code
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'" id="'.$form_name."_".$arr['name'].'" value="'.$arr['data'].'" size="5" maxlength="5"/>');
		if($type == "dt")  //datetime stamp
			$this->m_PT->write( '<input type="hidden" class="'.$class.'" name="'.$arr['name'].'" value="'.get_time().'" size="5" />');
		if($type == "ml1")  //large box type 1 (small)
			$this->m_PT->write( '<textarea name="'.$arr['name'].'" class="'.$class.'" cols="25" rows="3" >'.$arr['data'].'</textarea>');
		if($type == "ml2")  //large box type 1 (small)
			$this->m_PT->write( '<textarea name="'.$arr['name'].'" class="'.$class.'" cols="62" rows="5" >'.$arr['data'].'</textarea>');
		if($type == "ml3")  //large box type 1 (small)
			$this->m_PT->write( '<textarea name="'.$arr['name'].'" class="'.$class.'" cols="65" rows="4" >'.$arr['data'].'</textarea>');
		if($type == "ml4")  //large box type 1 (small)
			$this->m_PT->write( '<textarea name="'.$arr['name'].'" class="'.$class.'" cols="80" rows="7" >'.$arr['data'].'</textarea>');
		if($type =="elm1") //tiny mce box
			$this->m_PT->write( '<textarea id="e1m1" name="'.$arr['name'].'" class="'.$class.'" cols="55" rows="14" >'.$arr['data'].'</textarea>');
		if($type =="elm2") //tiny mce box
			$this->m_PT->write( '<textarea id="e1m1" name="'.$arr['name'].'" class="'.$class.'" cols="80" rows="14" >'.$arr['data'].'</textarea>');
		if($type =="hidden") //hidden field
			$this->m_PT->write( '<input type="hidden" name="'.$arr['name'].'" class="'.$class.'" value="'.$arr['data'].'" />');
		
		if($type=="currency")  
		{
			if($arr['data']!=0)
				$this->m_PT->write( '$<input type="text" class="'.$class.'" name="'.$arr['name'].'" value="'.$arr['data'].'" size="'.$size.'" maxlength="'.$maxsize.'" />');
			else
				$this->m_PT->write( '$<input type="text" class="'.$class.'" name="'.$arr['name'].'" value="0.00" size="'.$size.'" maxlength="'.$maxsize.'" />');
		}
	
			
		
		if($type == "captcha")
		{
			//CAPTCHA
			$image = new Securimage();
			$_SESSION['securimage_code_value'] = $image->createCode();
			$this->m_PT->write('<div id="captcha">');
			$this->m_PT->write('<img src="'.$CONFIG->url.'library/securimage/securimage_show.php?sid='.md5(uniqid(time())).'" id="captcha" alt="captcha" />');
			$this->m_PT->write('</div>');
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'" value="'.$arr['data'].'" size="'.$size.'" maxlength="'.$maxsize.'" />');
			
		}
		
		if($type == "a")  //array of values
		{
			$ID = $form_name."_".$arr['name'];
			$this->output_form_select_array($ID, $class, $arr['name'], $arr['data'], $arr['list_default'], $this->get_form_list($arr['list_name']));
		
		}
		//country array
		if($type=="country")
			$this->output_form_country_select($arr['name'], $class, $arr['data'], $this->get_form_list($arr['list_name']));
		
		//radio buttons
		if($type == "radio")
			$this->output_radio_field($arr['div_wrapper'], $arr['name'], $arr['desc'], $arr['data'], $this->get_form_list($arr['list_name']), 0);
		
		//Albanytakeout Special Form Stuff
		//============================
		if($type == "sa")  //special array of values
			$this->output_styledig_size($class, $arr['name'], $arr['data'], $arr['list_default'], $arr['list_name'], $arr['special']);
		if($type == "sd_cat")
			$this->output_styledig_category($class, $arr['name'], $arr['data'], $arr['list_default'], $this->get_form_list($arr['list_name']));
		if($type == "size") //size of garment
		{
			if($arr['data']=="")
				$arr['data'] = 0;
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'" value="'.$arr['data'].'" size="3" maxlength="4"/>');
		}
		if($type=="sd5") //Special Style Dig Size boxes
			$this->output_styledig_add_size($full_array, $arr);
			
		if($type=="sd9") //Special Style Dig Shipping FOrm
			$this->output_styledig_item_shipping($full_array, $arr);
		//=============================
		
		 //login security hash and javascript form submitter
		if($type == "hash") 
		{
			//see if hash already exists
			$hash = "";
			$session_hash = $_SESSION["login_hash"];
			if($session_hash != "")
				$hash = $session_hash;
			else
			{
				for($r=0;$r<4;$r++) //create 32 character hash
					$hash .= generate_random_hex();
			}
			$_SESSION["login_hash"] = $hash;
			$this->m_PT->write( '<input name="'.$arr['name'].'" class="'.$class.'" value="'.$hash.'" type="hidden" />');
		
			//output login hash algorithm Javacript
			/*login hash function*/
			$action = $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
			$java_script = chr(10).chr(10).'<script type="text/JavaScript"><!--'.chr(10);
			$java_script .= 'function SubmitForm() { pword = window.document.'.$form_name.'.password.value; ';
			$java_script .= 'hash = hex_md5(pword + "'.$hash.'"); ';
			$java_script .= 'window.document.'.$form_name.'.hash.value = hash; ';
			//$java_script .= 'window.document.'.$form_name.'.password.value = "password"; '; //erase password, important!
			$java_script .= 'window.document.'.$form_name.'.password.value = string_replace(window.document.'.$form_name.'.password.value, \'x\'); ';
			$java_script .= 'window.document.'.$form_name.'.action = "'.$action.'"; window.document.'.$form_name.'.onSubmit = ""; ';
			$java_script .= 'window.document.'.$form_name.'.submit();}';
			$java_script .= chr(10).'  --></script>'.chr(10);
  			$this->m_PT->write($java_script);
		}
		
		
		if($type == "checkbox")
		{
			$this->m_PT->write( '<input type="checkbox" class="'.$class.'" name="'.$arr['name'].'" ', 1);
			if($arr['data']!="") //if checked
				$this->m_PT->write('checked="1"', 1);
			$this->m_PT->write( ' />');
			
		}
			
		if($type == "file")
		{
			if($arr['data'] == "")
			{
				$this->m_PT->write('<input type="file" class="'.$class.'" name="'.$arr['name'].'" size="'.$size.' />');  
				$this->m_PT->write( '<input type="hidden" name="MAX_FILE_SIZE" value="2000000" />');
			}
			else
			{
				//output the file and a hidden field so we know it's already uploaded if the user re-submits
				$this->m_PT->write( "<b><a href='".$arr['data']."' target='_blank'>[".$arr['file']."]</a></b>");
				$this->m_PT->write( '<input type="submit" name="remove" value="Remove File" />');
				$this->m_PT->write( '<input type="hidden" name="'.$arr['name'].'_name" value="'.$arr['data'].'" />');
				$this->m_PT->write( '<input type="hidden" name="'.$arr['name'].'_file" value="'.$arr['file'].'" />');
			}
		}

		if($type == "p") //phone number
		{
			//get posted data if any
			if($arr['data']=="")
			{
				$phone_1 = $_POST[$arr['name']."_phone_1"];
				$phone_2 = $_POST[$arr['name']."_phone_2"];
				$phone_3 = $_POST[$arr['name']."_phone_3"];
			}
			else
			{
				//its preloaded with a handler
				$phone_1 = substr($arr['data'], 0, 3);
				$phone_2 = substr($arr['data'], 3, 3);
				$phone_3 = substr($arr['data'], 6, 4);
			}
			$this->m_PT->write( '(<input type="text" class="'.$class.'" name="'.$arr['name'].'_phone_1" id="'.$form_name.'_'.$arr['name'].'_phone_1" value="'.$phone_1.'" size="3" maxlength="3"');
			$this->m_PT->write(     ' onkeyup="advance(\''.$form_name.'_'.$arr['name'].'_phone_1\', \''.$form_name.'_'.$arr['name'].'_phone_2\', 3);" />)-');
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'_phone_2" id="'.$form_name.'_'.$arr['name'].'_phone_2" value="'.$phone_2.'" size="3" maxlength="3"');
			$this->m_PT->write(     ' onkeyup="advance(\''.$form_name.'_'.$arr['name'].'_phone_2\', \''.$form_name.'_'.$arr['name'].'_phone_3\', 3);" />-');
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'_phone_3" id="'.$form_name.'_'.$arr['name'].'_phone_3" value="'.$phone_3.'" size="4" maxlength="4" />');
		}
		
		if($type == "dob") //dob entry
		{
			//get posted data if any
			$dob_1 = $_POST[$arr['name']."_dob_1"];
			$dob_2 = $_POST[$arr['name']."_dob_2"];
			$dob_3 = $_POST[$arr['name']."_dob_3"];
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'_dob_1" value="'.$dob_1.'" size="2" maxlength="2"');
			$this->m_PT->write(   ' onkeyup="advance(this, \''.$arr['name'].'_dob_2\', 2)" />/');
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'_dob_2" value="'.$dob_2.'" size="2" maxlength="2"');
			$this->m_PT->write(   ' onkeyup="advance(this, \''.$arr['name'].'_dob_3\', 2)"/>/');
			$this->m_PT->write( '<input type="text" class="'.$class.'" name="'.$arr['name'].'_dob_3" value="'.$dob_3.'" size="4" maxlength="4" />');
		}
		
		if($type == "dob2") //dob entry (long form)
		{
			//get posted data if any
			$dob_1 = $_POST[$arr['name']."_dob_1"];
			$dob_2 = $_POST[$arr['name']."_dob_2"];
			$dob_3 = $_POST[$arr['name']."_dob_3"];
			$this->output_form_select_array("", $class, $arr['name']."_dob_1", $dob_1, "Month", $month_list);
			$this->output_form_select_array("", $class, $arr['name']."_dob_2", $dob_2, "Day", "", 1, 31);
			$this->output_form_select_array("", $class, $arr['name']."_dob_3", $dob_3, "Year", "", 2008, 1900);
		}
		
		if($type == "neardate")  //nearby date (ex: Junuary, 2008)
		{
			$nbd_1 = $_POST[$arr['name']."_nbd_1"];
			$nbd_2 = $_POST[$arr['name']."_nbd_2"];
			$this->output_form_select_array("", $class, $arr['name']."_nbd_1", "", $nbd_1, $this->get_form_list("month_list"));
			$this->output_form_select_array("", $class, $arr['name']."_nbd_2", "", $nbd_2, $this->get_form_list("closeyears_list"));
		}
		
		if($this->m_print_local_errors)
		{
			$errors = $this->validate($full_array, $index, $submitted, 0);
			if($errors != "")
			{
				$this->m_PT->write($this->m_error_header);
				$this->m_PT->write($errors);
				$this->m_PT->write($this->m_error_closer);
			}
		}
				
		if($arr['after'] != "") 
		{
			if($this->m_use_css == 1)
				$this->m_PT->write($arr['after'].chr(10));
			else
				$this->m_PT->write('</td><td>');
		}
		
		if(!$this->m_use_horz_table && !$this->m_use_css)
		{
			$this->m_PT->write( '</td>');
			$this->m_PT->write( '</tr>'.chr(10));
		}
		$this->m_PT->write($this->m_css_arr['input_close']);
		
	}
	
	
	//output radio buttons
	private function output_radio_field($div, $name, $desc, $value, $arr, $linebreaks = 0)
	{
		foreach($arr as $item)
		{
			$output = "";
			if($div != "")
				$output .= '<div id="'.$div.'">';
			$output .= '<input type="radio" name="'.$name.'" value="'.$item.'" ';
			if($value == $item)
				$output .= 'checked " ';
			$output .= " /> ".$item." &nbsp;&nbsp;";
			if($linebreaks==1)
				$output .= "<br />";
			if($div != "")
				$output .= '</div>';
			$this->m_PT->write($output);
		}
	}
	
	
	//==============
	// Output a drop down selection from a list of drop-down options
	// $name is the field name
	// $value is the user entered value
	// $list is the array of data to put in the drop-down
	protected function output_form_select_array($ID, $class, $name, $value, $default, $list, $begin=0, $end=0, $purchase = 0)
	{
		if($purchase==0)
			$this->m_PT->write('<select name="'.$name.'" class="'.$class.'" ', 1);
		if($ID!="")
			$this->m_PT->write('id="'.$ID.'" ', 1);
		$this->m_PT->write(' >');
		
		//output a range of numbers
		if(count($list)==0)
		{
			if($begin > $end) //decreasing
			{
				for($i=$begin;$i>=$end;$i--)
					$this->m_PT->write( "<option value='".$i."'>".$i."</option>");
			}
			else //increasing
			{
				for($i=$begin;$i<=$end;$i++)
					$this->m_PT->write( "<option value='".$i."'>".$i."</option>");
			}
		}
		else //output a list
		{
			foreach($list as $i => $opt)
			{
				$ref = $i;
				if($opt=="Yes"||$opt=="No")
					$ref--;
				if($ref == "")
					$ref = $opt;
					
				if($ref == $value || ($value=="" && $ref==$default) || ($name=="state" && $value=="" && $opt==$default))
					$this->m_PT->write('<option value="'.$ref.'" selected="true">'.$opt.'</option>');
				else
					$this->m_PT->write('<option value="'.$ref.'">'.$opt.'</option>');
			}
		}
		
		$this->m_PT->write( '</select>');
	}
	
	
	//================================
	//  Output Country Select Array
	//================================
	function output_form_country_select($name, $class, $value, $list)
	{
		//echo "VALUE: ".$value."<br />";
		$default = '';
		$this->m_PT->write('<select name="'.$name.'" class="'.$class.'" >');
		foreach($list as $code => $country)
		{
			$this->m_PT->write( "<option value='".$code."' ", 1);
			if($code == $value || ($value=="" && $default==$code))
				$this->m_PT->write('selected="true" ', 1);
			$this->m_PT->write(">".$country."</option>");
		}
		$this->m_PT->write( '</select>');
	}
			
				
	//=======================================================
	//  Special out for styledig item shipping
	//=======================================================
	protected function output_styledig_item_shipping(&$full_array, &$arr)
	{
		global $F, $CONFIG;
		$shipsto_arr = $arr['data'];
		$shipping_arr = $full_array[3]['data'];  //NOTE these are HARD CODED!
		$addship_arr = $full_array[4]['data'];
		
		if($shipsto_arr=="")
			$shipsto_arr = array();
		$count = 0;
		foreach($shipsto_arr as $val)
			if($val!="") $count++;
		if($count==0)
			$count = 1;
		for($i=0;$i<($count);$i++)
		{
			$shipto_value = $shipsto_arr[$i];
			$shipping_value = $shipping_arr[$i];
			$addship_value = $addship_arr[$i];
			
			if($shipping_value == 0)
				$shipping_value = "0.00";	
			if($addship_value == 0)
				$addship_value = "0.00";	
			
			$class = "dynamicBoxClass_".$i;
			$delSearch = "SHIPS TO</div>"; //marks where to put the delete link
			
			$this->m_PT->write('<div id="dynbox_container">');
				$this->m_PT->write('<div id="dynamicbox" class="'.$class.'">');
					$this->m_PT->write('<div id="additem_ship_box">');
						$this->m_PT->write('<div id="shipping_namebar">');
							$this->m_PT->write('<div id="shipping_name">SHIPS TO</div>');
							if($i!=0) //deleteShippingBox(\''.$class.'\')
								$this->m_PT->write('<div id="remove_ship_button" onclick="deleteDynamicBox(\''.$class.'\')">[remove]</div>');
						$this->m_PT->write('</div><div style="clear:both"></div>');
						$this->output_form_country_select("shipsto[]", "", $shipto_value, $this->get_form_list('country_list'));
					$this->m_PT->write('</div>');
					$this->m_PT->write('<div id="additem_extracontain_box">');
						$this->m_PT->write('<div id="additem_shipextra_box">');
							$this->m_PT->write('Cost $ <input name="shipping[]" id="shipping" type="text" value="'.$shipping_value.'" size=6>');
						$this->m_PT->write('</div>');
						$this->m_PT->write('<div id="additem_shipextra_box">');
							$this->m_PT->write('Cost with additional item* $ <input name="addship[]" id="addship" type="text" value="'.$addship_value.'" size=6>');
						$this->m_PT->write('</div>');
					$this->m_PT->write('</div>');	
				$this->m_PT->write('</div>');					
			$this->m_PT->write('</div>');
		}
		
		$this->m_PT->write('<div id="additem_add_box" onclick="addDynamicBox(\''.$delSearch.'\')">+ Add another destination</div>');
	}
	
	
	//=======================================================
	//  Special out for styledig add sizes on additem form
	//=======================================================
	protected function output_styledig_add_size(&$full_array, &$arr)
	{
		global $F, $CONFIG;
		$size_arr = $arr['data'];
		$quant_arr = $full_array[8]['data']; //this is HARD coded for this form!!

		if($size_arr=="")
			$size_arr = array();
		$count = 0;
		foreach($size_arr as $val)
			if($val!="") $count++;
		if($count==0)
			$count = 1;
		for($i=0;$i<($count);$i++)
		{
			$size_value = $size_arr[$i];
			$quant_value = $quant_arr[$i];
			if($quant_value == 0)
				$quant_value = "";	
			if($size_value=="" && $i==0)
				$size_value = $CONFIG->blank_size_text;
			
			$class = "dynamicBoxClass_".$i;
			$delSearch = "<div></div></div>"; //marks where to put the delete link
			
			$this->m_PT->write('<div id="dynbox_container">');
				$this->m_PT->write('<div id="dynamicbox"  class="'.$class.'">');
				$this->m_PT->write('<div style="clear:both"></div>');
					$this->m_PT->write('<div id="additem_size_box">');
						$this->m_PT->write('<div id="add_item_name">ENTER SIZE</div>');
						$this->m_PT->write('<input name="sizes[]" id="sizes" type="text" value="'.$size_value.'" onclick="'.$onclick.'" size=18 maxsize=24>');
					$this->m_PT->write('</div>');
					$this->m_PT->write('<div id="additem_qty_box">');
						$this->m_PT->write('<div id="add_item_name">QTY</div>');
						$this->m_PT->write('<input name="quants[]" id="quants" type="text" value="'.$quant_value.'" size=3>');
					$this->m_PT->write('<div></div></div>'); //this is funky only so we can search for it
					if($i!=0) 
						$this->m_PT->write('<div id="remove_ship_button" onclick="deleteDynamicBox(\''.$class.'\')">[remove]</div>');
				
				$this->m_PT->write('</div>');					
			$this->m_PT->write('</div>');
		}
		
		$this->m_PT->write('<div id="additem_add_box" onclick="addDynamicBox(\''.$delSearch.'\')">+ Add another size</div>');
	}
	
	//=============================================
	// Special output for styledig category form
	//=============================================
	protected function output_styledig_category($class, $name, $value, $default, $list)
	{
		//only used for styledig on the the item purchase page
		$this->m_PT->write('<select name="'.$name.'" id="category" class="'.$class.'"');
		$this->m_PT->write(' onchange="update_sub_category()" >');
		$this->m_PT->write( "<option value='".$default."'>".$default."</option>\n");

		foreach($list as $opt)
		{
			if($opt == $default && $value=="")
				continue;
			if($opt == $value)
				$this->m_PT->write( "<option value='".$opt."' selected=\"1\">".$opt."</option>\n");
			else
				$this->m_PT->write( "<option value='".$opt."'>".$opt."</option>\n");
		}

		$this->m_PT->write( '</select>');
	}
		
	//=============================================================
	// Special output for styledig purchase form (Size selection)
	//=============================================================
	protected function output_styledig_size($class, $name, $value, $default, $list, $purchase = 0)
	{
		$Item = new SaleItem($this->m_base_dir, $this->m_extra[0]);
		
		//only used for styledig on the the item purchase page
		$this->m_PT->write('<select name="'.$name.'" class="'.$class.'"');
		$this->m_PT->write(' onchange="update_stock('.$Item->get_inventory_string().')" >');

		$this->m_PT->write( "<option value='".$default."'>".$default."</option>\n");
			
		$arr = $Item->get_inventory_array();
		
		//Create size options array
		$options = array();
		if($arr['ONESIZE']!=0)
			array_push($options, array(0 => 'ONESIZE', 1 => 'Universal Size ('.$arr['ONESIZE'].')'));
		if($arr['XXS']!=0)
			array_push($options, array(0 => 'XXS', 1 => 'XXS ('.$arr['XXS'].')'));
		if($arr['XS']!=0)
			array_push($options, array(0 => 'XS', 1 => 'XS ('.$arr['XS'].')'));
		if($arr['S']!=0)
			array_push($options, array(0 => 'S', 1 => 'S ('.$arr['S'].')'));
		if($arr['M']!=0)
			array_push($options, array(0 => 'M', 1 => 'M ('.$arr['M'].')'));
		if($arr['L']!=0)
			array_push($options, array(0 => 'L', 1 => 'L ('.$arr['L'].')'));
		if($arr['XL']!=0)
			array_push($options, array(0 => 'XL', 1 => 'XL ('.$arr['XL'].')'));
		if($arr['XXL']!=0)
			array_push($options, array(0 => 'XXL', 1 => 'XXL ('.$arr['XXL'].')'));
			
		//output options
		foreach($options as $opt)
		{
			if($opt == $value)
				$this->m_PT->write( '<option value="'.$opt[0].'" selected="1">'.$opt[1]."</option>\n");
			else
				$this->m_PT->write( "<option value='".$opt[0]."'>".$opt[1]."</option>\n");

		}

		$this->m_PT->write( '</select>');
	}
	
	//=============================================
	//  function to mark incomplete form objects
	//=========
	/*

		return 0f "" means everything is valid
	*/
	protected function validate($full_array, $i, $submitted, $output)
	{
		global $F;
		$value = trim($full_array[$i]['data']);
		$type = $full_array[$i]['type'];
		$required = $full_array[$i]['required'];
		$name = $full_array[$i]['name'];
		$default = $full_Array[$i]['default']; //default value
		
		$badvalue = "";
		if($type == "z")
			$badvalue = 5;
		if($type == "t" || $type == "pass" || $type == "ml1" || $type == "ml2")
		{
			$badvalue = "";
			if($default!="")
				$badvalue = $default;
		}
		if($type == "a")
			$badvalue = "Select";
		if($type == "dt")
			return "";
			
			
		//Special Styledig checks
		if($submitted)
		{			
			if($type=="size")  //styledig cloth size
			{
				if(is_numeric($value))
					return "";
				else
					return "Your Inventory amount is not a valid number";
					
				//check that we have at least one size!
			}
			else if(($type=="a" && $name=="quantity") || $type=="sa")
			{
				if(strstr($value, "Select") || $value=="")
					return "One or more required entries are either blank or invalid";
				else
					return "";
			}
		}
			
		if($required && $submitted) //only check for errors is the field is required and the form has been submitted
		{
			if($type=="checkbox")
			{
				if($value=="")
					return "Please acknowledge our terms of use";
			}
			
			//ALBANYTAKEOUT
			if($type=="pass" && $name =="old") //old password
			{
				if($value=="")
					return "Your current password entry does not match the one on file.";
					
				$query = "SELECT `password`, `salt` FROM `de_users` WHERE `uid` = '".$_SESSION['uid']."';";
				$result = mysql_query($query);
				if($result && $row = mysql_fetch_array($result))
				{
					$act_password = base64_decode($row['password']);
					$salt = base64_decode($row['salt']);
					$Cipher = new Cipher();
					$Cipher->set_iv($salt);
					$decrypted_pass = $Cipher->decrypt($act_password);
					
					if($decrypted_pass != $value)
						return "Your current password entry does not match the one on file.";
				}
			}
			
			
			//handle dual passwords (specific to StyleDig), you need two passwords for this to work
			if($type=="pass1")
			{
				if(!$this->validate_password($value))
					return "Pleas choose a password that is at least seven (7) characters in length";
				if(count($full_array)>$i+1 && $full_array[$i+1]['type'] == "pass2") //check for matching passwords
				{
					$password2 = $full_array[$i+1]['data'];
					if($value != $password2)
						return "Your passwords don't match.";
				}
			}
			
			else if($type=="pass2")
			{
				//just invalidate if it doesn't match one so that they both show up in red
				if(($i-1)>=0 && $full_array[$i-1]['type'] == "pass1") //check for matching passwords
				{
					$password1 = $full_array[$i-1]['data'];
					if($value != $password1)
						return "&nbsp;"; //returns error but no message
				}
			}
			
			
			if($type=="a")
			{
				if(strstr($value, "Select") || $value=="")
					return "One or more required entries are either blank or invalid";
				else
					return "";
			}
			
			if($type=="neardate")
			{
				$arr = explode(",", $value);
				if($arr[0]=="" || $arr[1]=="")
					return "One or more required entries are either blank or invalid";
				else
					return "";
			}
			
			if($type=="username") 
			{			
				if($value=="")
					return "Please enter a username";
					
				//check for bad characters
				if(contains_bad_characters($value))
					return 'Usernames may only contain letters and numbers';
				
				if(strlen($value)>12 || strlen($value)<5 )
					return 'Username must be between 5 and 12 characters';
					
				$table_name = "de_users";
				//first check that username doesn't already exist
				$query = "SELECT * FROM `de_users` WHERE username = '".sanitize_string($value)."' LIMIT 1;";
				$result = mysql_query($query);
				if($result)
				{
					if($row = mysql_fetch_array($result))
					{
						return "We're sorry, that username is already in use"; //name already exists(
					}
				}
				return "";
			}
			
			if($type=="t" && $name == "storename") //store name
			{
				if($value=="")
					return "This field is required";
				//check for bad characters
				if(validate_storename($value)==false)
					return 'Storename may only contain alpha numeric characters without spaces';
				
				$table_name = "sr_store_profile";
				//first check that username doesn't already exist
				$query = "SELECT * FROM `".$table_name."` WHERE storename = '".sanitize_string($value)."' AND `uid` <> '".$_SESSION['uid']."' LIMIT 1;";
				$result = mysql_query($query);
				if($result && $row = mysql_fetch_array($result))
					return "Storename already in use"; //name already exists(
				return "";
			}
			
			//handle some special cases here
			if($type=="cc") //credit card number
			{
				if(strlen($value)<16 || !is_numeric($value))
					return "Invalid credit card number";
				else
					return "";
			}
			
			//handle some special cases here
			if($type=="p") //it's a phone number
			{
				//split into it's three parts
				$pn = explode("-", $value);
				if(!$this->validate_phone_number($pn[0], $pn[1],$pn[2]))
				{
					if($output)
						$this->output_error_flag();
					return "One or more required entries are either blank or invalid";
				}
				else
					return "";
			}
			
			if($type=="dob") //it's a DOB
			{
				//split into it's three parts
				$dob = explode("/", $value);
				if(!$this->validate_dob($dob[0],$dob[1],$dob[2]))
				{
					if($output)
						$this->output_error_flag();
					return "One or more required entries are either blank or invalid";
				}
				else
					return "";
			}
			
			if($type=="dob2") //it's a DOB (long)
			{
				//split into it's three parts
				$month = explode(", ", $value);
				$day_year = explode(" ", $month[1]);
				if($month[0]!="Month" && $day_year[0]!="Day" && $day_year[1]!="Year")
				{
					return "";
				}
				else
				{
					if($output)
						$this->output_error_flag();
					return "One or more required entries are either blank or invalid";
				}
			}
			
			if($type=="e")
			{
				if($this->check_email_address($full_array[$i]['data']))
				{
					if($default!="" && $value == $default)
						return "Enter email";
					return "";
				}
				else
					return "Please enter a valid email address";
			}
			
			//handle dual emails (specific to StyleDig), you need two passwords for this to work
			if($type=="e1")
			{
				//first check that username doesn't already exist
				$query = "SELECT * FROM sr_users WHERE email = '".$full_array[$i]['data']."' LIMIT 1;";
				$result = mysql_query($query);
				if($result)
				{
					if(mysql_fetch_array($result))
						return "That email address is already in use"; //name already exists
				}
				
				//check for valid email
				if(!$this->check_email_address($full_array[$i]['data']))
					return "Please enter a valid email address";
				if(count($full_array)>$i+1 && $full_array[$i+1]['type'] == "e2") //check for matching emails
				{
					$email2 = $full_array[$i+1]['data'];
					if($value != $email2)
						return "Email entries do not match.";
				}
			}
			else if($type=="e2")
			{
				if($i-1>=0 && $full_array[$i-1]['type'] == "e1") //check for matching emails
				{
					$email2 = $full_array[$i-1]['data'];
					if($value != $email2)
						return "&nbsp;";
				}
			}
			
			if($type == "captcha")
			{
				//CAPTCHA
				$img = new Securimage();
				$valid = $img->check($value);
				if($valid == false)
					return "Security code does not match";
				else
					return "";
					
			}
		
			if(is_numeric($badvalue)) //if user gives a number we're checking for bounds only, thats all i got
			{
				if(strlen($value) < $badvalue)
				{
					if($output)
						$this->output_error_flag();
					if($this->m_print_local_errors)
						return "This field is required";
					return "Please complete the missing fields";
				}
				
				if(!is_numeric($value))
				{
					if($output)
						$this->output_error_flag();
					if($this->m_print_local_errors)
						return "This field is required";
					return "Please complete the missing fields";
				}
			}
			else if($value==$badvalue) //esle just check if its blank
			{
				if($output)
					$this->output_error_flag();
				if($this->m_print_local_errors)
					return "This field cannot be left blank";
				return "Please complete the missing fields";
			 }
		}
	  
	  return ""; //return valid by default
	}
	
	//pretty self explainatory
	protected function output_error_flag()
	{
		$this->m_PT->write( "<span class='form_error_flag'> * </span>");
	}
	
	//used to validate phone numbers (in three parts)
	protected function validate_phone_number($p1,$p2,$p3)
	{
		global $F;
		if(!is_numeric($p1) || !is_numeric($p2) || !is_numeric($p3))
			return false;
		if($p1 > 999 || $p1 < 1 || 
		   $p2 > 999 || $p2 < 1 ||
		   $p3 > 9999 || $p3 < 1)
		   return false;
		return true;
	}
	
	//used to DOB entry (in three parts)
	protected function validate_dob($p1,$p1,$p3)
	{
		if(!is_numeric($p1) || !is_numeric($p2) || !is_numeric($p3))
			return false;
		if($p1 > 99 || $p1 < 1 || 
		   $p2 > 99 || $p2 < 1 ||
		   $p3 > 9999)
		   return false;
		return true;
	}
	
	protected function validate_password($pass)
	{
		if(strlen($pass) > 6)
			return true;
		else
			return false;
	}
	
	//this is ripped from "http://www.addedbytes.com/php/email-address-validation/"
	protected function check_email_address($email) 
	{
		// First, we check that there's one @ symbol, and that the lengths are right
		if (!ereg("^[^@]{1,64}@[^@]{1,255}$", $email)) 
		{
			// Email invalid because wrong number of characters in one section, or wrong number of @ symbols.
			return false;
		}
		
		// Split it into sections to make life easier
		$email_array = explode("@", $email);
		$local_array = explode(".", $email_array[0]);
		for ($i = 0; $i < sizeof($local_array); $i++) 
		{
			if (!ereg("^(([A-Za-z0-9!#$%&'*+/=?^_`{|}~-][A-Za-z0-9!#$%&'*+/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$", $local_array[$i]))
				return false;
		}
		if (!ereg("^\[?[0-9\.]+\]?$", $email_array[1])) 
		{ 
			// Check if domain is IP. If not, it should be valid domain name
			$domain_array = explode(".", $email_array[1]);
			if (sizeof($domain_array) < 2)
				return false; // Not enough parts to domain

			for ($i = 0; $i < sizeof($domain_array); $i++) 
			{
				if (!ereg("^(([A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9])|([A-Za-z0-9]+))$", $domain_array[$i])) 
					return false;
			}
		}
	   return true;
   }
	
	
	//MTJ 6/8/2011 - I don't think this is used anymore?
	//FUNCTION to email form data
	// assumes m_email_address, m_email_from, m_email_subject are set
	// $data is the table data array, 
	// $total is the total elements of the array
	protected function email_form_data($data, $total)
	{
		global $F;
		$message = "<HTML><body>";
		$message .= "<center>"."Form submission data from ".$this->m_email_from;
		$message .= "<br /><br />";
		
		$message .= "<table cellspacing='3' cellpadding='3' borders='0'>";
		//create message body
		for($i=1;$i<=$total;$i++)
		{
			if($data[$i]['type']=="section")
			{
				$message .= "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>\r\n";
				continue;
			}
			
			if($data[$i]['spacer']==1) //check for add spacer
				$message .= "<tr><td>&nbsp;</td><td>&nbsp;</td></tr>\r\n";
				
			$message .= "<tr><td><b>";
			$message .= $data[$i]['name'].":     ";
			$message .= "</b></td><td>";
			$message .= $data[$i]['data'];
			$message .= "</td></tr>\r\n";

		}
		$message .= "</table></body></html>";
		
		$headers .= "From: ".$this->m_email_from."\r\n";
		$headers .= "Content-Type: text/html\r\n";
		$headers .= "X-Mailer: php\r\n";
		
		//mail it
		if(!send_email($this->m_email_address, $this->m_email_subject, $message))
		{
			$this->m_PT->write( '<center class="form_err">Error mailing your form.  Please contact site administrator.</center>');
		}
	}
	
	//this handles the submission of a file
	// $arr = the file entry in the table
	// $file_name = $_FILES['']['name'];
	// $file_tmp_name = $_FILES['']['tmp_name'];
	// $targ_prefix is the target prefix for the target file
	// $remove = whether to remove uploaded file
	//This will upload the file to the destination location and add the filename to the table entry to go into a database for reference
	protected function handle_file_submission(&$arr, $file_name, $file_tmp_name, $target_dir, $targ_prefix, $remove)
	{
		global $F;
		if($remove!="")  //it's a command to remove uploaded file
		{
			unlink($arr['data']);
			$arr['data'] = "";
			$arr['file'] = "";
			return "";
		}
		
		if($arr['data']!="") //file already uploaded
			return "";
		
		$ext=end(explode('.',$file_name));
		
		if($file_name == "") //no file specified for upload
			return "";
	
		//check for safe extension of file
		if(!$this->safe_extension($ext))  
		{
		   return "The file you submitted is not in a safe format. Please use another format and try again.";
		}
	
		//move file to target location
		$name = $targ_prefix."_".date("_dmygis").".".$ext;
		$target_path = $target_dir.$name;
	
		//echo "PATH: ".$target_path;
		if(!move_uploaded_file($file_tmp_name, $target_path)) 
			return "There was an error uploading the file, please try again!";
			
		//save filenames in table entry to show that the file has been uploaded
		$arr['data'] = $target_path;  //our created name
		$arr['file'] = $file_name;  //user chosen name
	}
	
	function safe_extension($ext)
	{
	  if($ext=="exe" || $ext=="js" || $ext=="bat")
		 return false;
	  return true;
	}

	protected function get_form($form_name)
	{
		global $FORMS; //global forms
		return $FORMS->{$form_name};
	}
	
	protected function get_form_list($list_name) //get array of preset values
	{
		global $FORM_LISTS;
		return $FORM_LISTS->{$list_name};
	}
}


?>