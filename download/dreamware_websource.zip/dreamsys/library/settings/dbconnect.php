<?php

	// Mike Jones
	// Database Connection Settings
	//==========================

include_once(dirname(dirname(__FILE__)) . "/security.php");
/*global $CONFIG, $CSS_VERION, $JS_VERSION, $DEBUG_FLAG;

//function connect_admin()
{
	$hostname="";
	$user_name="";
	$password="";
	$dbname="";

	if($_SERVER['HTTP_HOST']=="localhost")
	{
		//Local Server
		$hostname="localhost";
		$user_name="root";
		$password="";
		$dbname="demeter";
	}
	else
	{
		//if(strstr($_SERVER['HTTP_HOST'], "albanytakeout.com"))
		{
			//Release server
			$hostname="localhost";
			$user_name="demeterrunner";
			$password="makemoney1675$";
			$dbname="live_demeter";
		}
	}
	//connect to database server using admin settings
	mysql_connect($hostname,$user_name, $password);
	mysql_select_db($dbname);
	
	//dataabases
	global $CONFIG;
	$CONFIG->image_db = "`amadeus`";
	$CONFIG->data_db = "`demeter`";
	
	
	//run a query
	function db_query($query)
	{
		global $DEBUG_FLAG;
		$result = mysql_query($query);
		if(!$result)
		{
			if($DEBUG_FLAG==1)
				echo $query;
			else
			{
				error_log("Query error: ".$query);
				forward('ERROR'); 
			}
		}
		else
		{
			return $result;
		}
	}
	
}
*/
?>