//==========================
//  Upgrading the database
//==========================

In ordet to upgrade the database first put the tested changes in
a .sql file.  Then Use upgrade.php in the root directory.

-------------------------------------------------------------------------

How it works:
	
	1 - Put all sql changes in 'library/database/upgrades/
		Name the file "upgrade_[version#]" where [version#] is an
		increment of the last upgrade file's trailing number.
		It can be any number as long as it's greater than the
		current db_version in the "db_config" table.
	2 - Run www.sitename.com/upgrade.php?code=AMANDA
	3 - Pat yourself on the back

//======================================================================

