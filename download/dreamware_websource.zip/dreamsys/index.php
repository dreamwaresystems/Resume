<?php
include_once('library/start.php');
global $CONFIG;
$PT = new DreamwarePageTemplate();
$PT->printWrapperBegin("home");
$PT->printContentBegin(true);


	// twinkle CSS effect
	//echo '<div class="stars"></div>';
    //echo '<div class="twinkling"></div>';
    //echo '<div class="clouds"></div>';
	

    echo '<div class="starlight_home"></div>'.chr(10);
	
	echo '<div class="home_spacer"></div>'.chr(10);
		
		/*	
		echo '<div class="home_text_left">';
			echo 'Dreamware Systems LLC is a custom software development and management company specializing in web, mobile, ';
			echo 'fat-client, and back-end software solutions.';
		echo '</div>';
		
		echo '<div class="darkGrayBtn"><a href="<?=$CONFIG->url?>pg/products">Products</a></div>';
		echo '<div class="darkGrayBtn"><a href="<?=$CONFIG->url?>pg/development">Development</a></div>';
		echo '<div class="darkGrayBtn"><a href="<?=$CONFIG->url?>pg/contact">Contact</a></div>';
		*/
		
	//echo '</div>';
	

?>
<script>
	/* custom twinkle starter */
	$(document).ready(function(){
		configureStarlightForHomepage();
	});
</script>
<?php

$PT->printContentEnd();
$PT->printWrapperEnd();
$PT->outputPage();

?>