<?php
include_once('../../library/start.php');
global $CONFIG;
$PT = new DreamwarePageTemplate();
$PT->printWrapperBegin("apps/holyquotes");
$PT->printContentBegin(true);
?>
	
	<div class="general_box_left" style="margin-top:40px;">
	
		<div class="page_title">HolyQuotes - iPhone/iPad App</div>
		<div class="app_box">
			<div class="app_image"><img src="<?= $CONFIG->url?>images/products/app_holyquotes.png" width="200px" height="200px" /></div>
			<div class="app_fadebox">
				HolyQuotes takes carefully selected, motivational passages from the Bible and puts them in your pocket with this convenient app. 
				HolyQuotes features over 1700 hand-picked Bible verses including hundreds of verses categorized for specific life events and everyday 
				situations such as: Bereavement, Love, Faith, Forgiveness, Guidance, Anger, Mercy and many more. 
				<br /><br />
				Whether you are looking for a good verse to quote during a speech or eulogy, seeking the Lord's word in a time of need or just 
				wishing to bring more faith into your everyday life, HolyQuotes will fulfill all of your Bible reference needs and more.  
				HolyQuotes offers more passages, easier sharing ability and greater relevance than the competition. 
				<br /><br />
				Impress your friends at cocktail parties with contextually relevant passages.  Save your favorite verses for later 
				reference and easily share verses with those around you using Social Networks, Email and Text Message. 
				<br /><br />
				<b>FEATURES:</b>
				<ul>
					<li>Categorized verses for specific life events and situations</li>
					<li>Browse quotes from over 1700 hand-selected passages </li>
					<li>Share verses and quotes via Twitter, Email and Text Message</li>
					<li>Search for verses in specific books and testaments </li>
					<li>Save your favorite verses for later reference </li>
				</ul>
				
				<b>LATEST VERSION:</b>
				<ul>
					<li>Version 1.2</li>
				</ul>
				
				<b>DOWNLOAD:</b>
				<ul>
					<li><a href="https://itunes.apple.com/us/app/holyquotes/id479143644">iTunes Store</a></li>
				</ul>
				
				<br /><br />
				For comments or suggestions please use our <a href="<?=$CONFIG->url?>pg/contact">contact form</a>
				<br /><br />
				<strong>Support Contact:</strong> <a href="mailto:support@dreamwaresys.com">support@dreamwaresys.com</a>
				
			</div>
		</div>
		<div class="clear" style="margin-top:20px;">&nbsp;</div>
	</div>
<?php

$PT->printContentEnd();
$PT->printWrapperEnd();
$PT->outputPage();
?>