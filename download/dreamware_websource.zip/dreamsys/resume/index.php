<?php
global $CONFIG, $TEMPLATE;
$TEMPLATE = "resume";
include_once('../library/start.php');

$PT = new ResumePageTemplate();
$PT->printWrapperBegin("resume");
$PT->printContentBegin(true);

?>
<div class="anchor_div" id="summary"></div>
<div class="cv_section" style="margin-top:180px;">
	<div class="cv_inner_title">Summary</div>
	<div class="cv_box">
		<p>
			In my ten-year career as a software engineer I have worked at both large and small firms, developing software across an array of architectures 
			and languages.  I have been tasked with building web, mobile and fat-client software systems from the ground-up, communicating directly with 
			clients to better understand and fulfill their needs. My strongest qualities are perhaps my breadth of experience and my ability to communicate 
			and work with persons outside the technical arena.
			<br><br>
			In addition to my dual degree in mathematics, I have spent a large portion of my career on Wall Street converting theoretical algorithms and 
			financial models into practical software applications.  This background in mathematics can be invaluable not only in the area of finance but 
			in the application of general software design and better understanding the pitfalls befalling large-scale database systems and high-performance 
			applications. 
			<br><br>
			Lastly, I have spent the last five years in a partial leadership role – mentoring junior employees, overseeing the division of projects and 
			managing small teams of software developers.  While I currently serve as Director of Software Development and I am not shy of stepping into 
			a leadership role, writing code is my true passion and I would hesitate to take a role that wasn’t largely hands on at this stage of my 
			career.
		</p>
	</div>
</div> <!-- end summary -->




<div class="anchor_div" id="skills"></div>
<div class="cv_section_title">Professional Skills</div>
<div class="cv_section_clear">
<?php

	$Skills = array(
		"PHP"          => array("years" => 14, "type" => "lang"),
		"C"            => array("years" => 12, "type" => "lang"),
		"C++"          => array("years" => 10, "type" => "lang"),
		"Objective-C"  => array("years" => 7,  "type" => "lang", "abbr" => "Obj-C"),
		".NET"         => array("years" => 6,  "type" => "lang"),
		"C#"           => array("years" => 6,  "type" => "lang"),
		"VB"           => array("years" => 6,  "type" => "lang"),
		"Java"         => array("years" => 5,  "type" => "lang"),
		"Python"       => array("years" => 4,  "type" => "lang"),
		"Swift"        => array("years" => 2,  "type" => "lang"),
		"MySQL"        => array("years" => 12, "type" => "db"),
		"SQL Server"   => array("years" => 6,  "type" => "db"),
		"NoSQL"   	   => array("years" => 2,  "type" => "db"),
		"iOS"          => array("years" => 6,  "type" => "platform"),
		"Android"      => array("years" => 5,  "type" => "platform"),
		"Linux"        => array("years" => 14, "type" => "platform"),
		"Win32"        => array("years" => 14, "type" => "platform"),
		"Finance"      => array("years" => 14, "type" => "field"),
		"Quant"        => array("years" => 14, "type" => "field"),
		"DBAdmin"      => array("years" => 14, "type" => "field"),
		);
	
	// for language bar chart
	$profLists = array(
		"lang"     => array("title" => "Programming Languages", "list" => array()),
		"db"       => array("title" => "Database Engines", "list" => array()),
		"platform" => array("title" => "Architectures", "list" => array()),
		"field"    => array("title" => "General Fields", "list" => array()),
		);
	$langLabelList = array();
	$langYearList = array();
	foreach($Skills as $name => $Info)
	{
		$title = $name;
		if($Info['abbr']!="")
			$title = $Info['abbr'];
		
		if($Info['type']=="lang")
		{
			array_push($langLabelList, $title);
			array_push($langYearList, $Info['years']);
		}
		$profLists[$Info['type']]['list'][] = $title;
	}
?>

	<div class="cv_split_box" style="width:40%;float:left;">
		<?php
		foreach($profLists as $prof => $Data)
		{
			echo '<div class="cv_skills_group">';
				echo '<h1>'.$Data['title'].'</h1>';
				echo '<ul>';
				$list = $Data["list"];
				for($i=0;$i<count($list);$i++)
				{
					echo '<li>'.$list[$i];
					if($i<count($list)-1)
						echo ',';
					echo '</li>';
				}
				echo '</ul>';
			echo '</div>';
		}
		?>
	</div>
	
	<div class="cv_split_box" style="width:58%;float:right;">
		<h1>Programming Languages by Years of Experience</h1>
		<canvas id="langChart" width="650" height="350"></canvas>
	</div>
	
	<div class="clearfix"></div>

	
	<script>
		var barOptions = {
			scaleIntegersOnly: false,
			scaleFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
			scaleFontSize: 15,
			scaleFontStyle: "bold",
			scaleFontColor: "#FFF",
			responsive: true,
			// bar-specific options
			scaleBeginAtZero : true,
			scaleShowGridLines : true,
			scaleGridLineColor : "rgba(0,0,0,.05)",
			scaleGridLineWidth : 1,
			scaleShowHorizontalLines: false,
			scaleShowVerticalLines: true,
			barShowStroke : false,
			barStrokeWidth : 2,
			barValueSpacing : 5,
			barDatasetSpacing : 1,
			legendTemplate : "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>"
		}


		/* language bar chart */
		var langData = {
			labels: <?=getJSArrayString($langLabelList)?>,
			datasets: 
				[
					{
						label: "Years", 
						fillColor: ["#B9BEDC","#92C5B6","#61B4D6","#B4B48E","#689365","#937365","#994949","#639698","#484779","#CCCCCC","#0B5015"],
						data: <?=getJSArrayString($langYearList, true)?>
					}
				]
			};
		var ctx = document.getElementById("langChart").getContext("2d");
		var langChart = new Chart(ctx).Bar(langData, barOptions);

	</script>
</div> 
<!-- end skills -->




<div class="anchor_div" id="experience"></div>
<div class="cv_section_title">Professional Experience</div>
<div class="cv_section_clear" style="margin-top:0px;">

	<div class="cv_box cv_exp_box">
		<p>
			<div class="cv_exp_company">World Steel Dynamics</div>
			<div class="cv_exp_location">Englewood Cliffs, NJ</div>
			<div class="cv_dates">
				<li>May 2012</li>
				<li>Present</li>
			</div>
			<div class="cv_exp_title">Director of Software Development / Lead Software Engineer</div>
			<ul>
				<li>Develop the Global Steel Information System – an online suite of steel forecasting and analysis tools</li>
				<li>Work directly with financial analysts to develop economic forecasting models</li>
				<li>Manage 3 part-time developers and the modular division of projects</li>
				<li>Report directly to CEO to meet revenue goals and release schedules</li>
				<li>Set company-wide technology policy and software stack choices</li>
				<li>Redesigned corporate website, built SEO presence and social networking footprint</li>
			</ul>
		</p>

		<p>
			<div class="cv_exp_company">CooCoo</div>
			<div class="cv_exp_location">Huntington, NY</div>
			<div class="cv_dates">
				<li>Apr 2011</li>
				<li>May 2012</li>
			</div>
			<div class="cv_exp_title">Senior Mobile App Developer</div>
			<ul>
				<li>Pioneered a mobile POS system for processing real-time transactions aboard commuter railcars</li>
				<li>Developed 3 iOS apps and 2 Android apps grossing over 100,000 downloads</li>
				<li>Managed two entry-level engineers overseeing 20 high-traffic servers and fail-safe systems</li>
				<li>Implemented company security policy and maintained PCI-Compliant architecture</li>
			</ul>
		</p>
		
		<p>
			<div class="cv_exp_company">Dreamware Systems LLC</div>
			<div class="cv_exp_location">New York, NY</div>
			<div class="cv_dates">
				<li>Jan 2009</li>
				<li>May 2015</li>
			</div>
			<div class="cv_exp_title">Software Developer (Self Employed)</div>
			<ul>
				<li>Designed and maintained 8+ commercial websites (see portfolio)</li>
				<li>Co-founder and chief architect of TrooYoo – a video-based mobile dating app</li>
				<li>Optimized and load-balanced linux-based VPS clusters to maintain performance under heavy loads</li>
				<li>Designed custom e-commerce systems for secure payment processing</li>
			</ul>
		</p>
		
		<p>
			<div class="cv_exp_company">SS&C Technologies Inc.</div>
			<div class="cv_exp_location">New York, NY</div>
			<div class="cv_dates">
				<li>Sep 2006</li>
				<li>Apr 2011</li>
			</div>
			<div class="cv_exp_title">Financial Programmer / Analyst – Municipal Finance Division</div>
			<ul>
				<li>Promoted to Senior Developer for DBC Debt Manager  - a database application for debt management and reporting</li>
				<li>Implemented custom option-pricing models including variants of Black Dermon Toy and Black-Scholes</li>
				<li>Enhanced source code for DBC Finance – a linear optimization model used to structure 95% of U.S. municipal bonds</li>
				<li>Worked directly with top wall street firms to create custom software models and forecasting engines</li>
			</ul>
		</p>
		
		<p>
			<div class="cv_exp_company">Harve Benard Ltd.</div>
			<div class="cv_exp_location">Clifton, NJ</div>
			<div class="cv_dates">
				<li>May 2005</li>
				<li>(Summer)</li>
			</div>
			<div class="cv_exp_title">Assistant to Chief Technology Officer (Internship)</div>
			<ul>
				<li>Maintained and serviced over 30 Unix, NT, and AS400 servers</li>
				<li>Taught advanced level Microsoft Excel, Word, and Visual Basic employee courses</li>
				<li>Designed and tested emergency server recovery procedures</li>
			</ul>
		</p>
	</div>
</div> 
<!-- end experience -->




<div class="anchor_div" id="education"></div>
<div class="cv_section_title">Education</div>
<div class="cv_section_clear" style="margin-top:5px;">

	<div class="cv_educ_icon">
		<img src="../images/resume/educAlbany.png" alt="University at Albany" />
	</div>
	<div class="cv_educ_wrap">
		<div class="cv_educ_school cv_educ_color">University at Albany (SUNY)</div>
		<div class="cv_dates">
			<li>Sep 2002</li>
			<li>May 2006</li>
		</div>
		<div class="cv_educ_info">
			<ul>
				<li>B.S. Computer Science & Applied Mathematics</li>
				<li>Cum Laude Graduate, Major GPA: 3.85</li>
				<li>Honors Study in Cryptology & Information Security</li>
				<li>President of Sigma Alpha Epsilon Fraternity 2005-2006</li>
			</ul>
		</div>
	</div>
	
	<div class="clearfix" style="margin-bottom:22px;"></div>
	<div class="cv_educ_icon">
		<img src="../images/resume/educScarsdale.png" alt="University at Albany" />
	</div>
	<div class="cv_educ_wrap">
		<div class="cv_educ_school" style="color:#BF848F;">Scarsdale High School</div>
		<div class="cv_dates">
			<li>Sep 1998</li>
			<li>May 2002</li>
		</div>
		<div class="cv_educ_info">
			<ul>
				<li>AP Calculus (5), AP Statistics (5)</li>
				<li>Football Team Captain</li>
			</ul>
		</div>
	</div>
	
</div> <!-- end education -->
<div class="clearfix"></div>

<div class="anchor_div" id="portfolio"></div>
<div class="cv_section_title">Project Portfolio</div>
<div class="cv_proj_sect_title cv_app_color">Mobile App Development</div>
<div class="cv_section_clear" style="margin-top:0px;width:85%;">
	<div class="cv_proj_split">
		<div class="cv_proj_wrap cv_proj_app_wrap">
			<div class="cv_proj_thumb cv_proj_app"><img src="<?=$CONFIG->url?>images/projects/thumbnails/app_coocoo.jpg" alt="CooCoo iOS" /></div>
			<div class="cv_proj_text">
				<div class="cv_proj_title">CooCoo (iOS/Android)</div>
				<div class="cv_proj_link">
					<a class="cv_link_segment" href="http://" target="_blank">App Store Link</a>
					<a class="cv_link_segment_final" href="http://" target="_blank">Google Play Link</a>
				</div>
				<div class="cv_proj_desc">
					In April 2011 I was hired by CooCoo to help build out their mobile application platform 
					from the ground-up. The first task was to convert the back-end of what had been until then a text-message based 
					system into a secure and scalable API.  I then developed CooCoo's primary mobile app natively for both iOS and 
					Android.
				</div>
			</div>
		</div>
		
		<div class="cv_proj_wrap cv_proj_app_wrap">
			<div class="cv_proj_thumb cv_proj_app"><img src="<?=$CONFIG->url?>images/projects/thumbnails/app_holyquotes.jpg" alt="Holy Quotes App" /></div>
			<div class="cv_proj_text">
				<div class="cv_proj_title">HolyQuotes (iOS)</div>
				<div class="cv_proj_link"><a href="http://" target="_blank">App Store Link</a></div>
				<div class="cv_proj_desc">
					My boss at the time bet $100 that I couldn't develop a useful app in a single weekend ...and thus Holy Quotes 
					was born the following Monday.  After creating a data-mining tool to scrape meaningful quotes from the King James, 
					I spent the remainder of the weekend designing the app's interface.  The completed app garnered 10,000 downloads in the first month.  
					I should note that I am not a religious person; however, the concept struck me as simple enough yet still useful.
				</div>
			</div>
		</div>
	</div>
	
	<div class="cv_proj_split">
		<div class="cv_proj_wrap cv_proj_app_wrap">
			<div class="cv_proj_thumb cv_proj_app"><img src="<?=$CONFIG->url?>images/projects/thumbnails/app_ticketing.jpg" alt="CooCoo Ticketing" /></div>
			<div class="cv_proj_text">
				<div class="cv_proj_title">CooCoo Ticketing (iOS)</div>
				<div class="cv_proj_link" style="clear:both;">Not publicly available</div>
				<div class="cv_proj_desc">
					One of the more innovative projects I worked on while employed at CooCoo was the development of a mobile-based POS system for accepting 
					payments and validating tickets on-board commuter railroads.  The concept utilized a fleet of iPhones attached to LineaPro devices capable  
					of scanning barcodes and swiping payment cards.
				</div>
			</div>
		</div>
		<div class="cv_proj_wrap cv_proj_app_wrap">
			<div class="cv_proj_thumb cv_proj_app"><img src="<?=$CONFIG->url?>images/projects/thumbnails/app_liub.jpg" alt="LIUB Android" /></div>
			<div class="cv_proj_text">
				<div class="cv_proj_title">Light It Up Blue (iOS/Android)</div>
				<div class="cv_proj_link">
					<a class="cv_link_segment" href="http://" target="_blank">App Store Link</a>
					<a class="cv_link_segment_final" href="http://" target="_blank">Google Play Link</a>
				</div>
				<div class="cv_proj_desc">
					Whilst working at CooCoo, during a brief lapse in startup funding I was loaned to a sister company that developed 
					marketing sites for non-profits. During this time, I was tasked with developing both the iOS and Android versions 
					of Light It Up Blue (2012) for Autism Speaks.
				</div>
			</div>
		</div>
	</div>
</div> <!-- end mobile development -->
<div class="clearfix"></div>

<div class="cv_proj_sect_title cv_web_color">Website Development</div>
<div class="cv_section_clear" style="margin-top:0px;width:85%;">	
	<?php
		$WebProjects = array(
			"wsdweb"      => array("col" => 1, "link" => "www.worldsteeldynamics.com",  "title" => "World Steel Dynamics",    "desc" => "Developed from scratch while working full-time for World Steel Dynamics Inc. Beyond advertising the company's primary business, behind the login wall lies a secure report access system and a custom-built client management portal &amp; billing platform coded primarily in PHP."),
			"sammyandnat" => array("col" => 1, "link" => "www.sammyandnat.com",         "title" => "Sammy &amp; Nat",         "desc" => "Originally built using open-source e-commerce platform Opencart, I constructed SammyAndNat.com in a matter of months for my friend Samantha Benson to retail her line of fashionable baby rampors."),
			"facebake"    => array("col" => 1, "link" => "www.facebake.com",            "title" => "Facebake",                "desc" => "Coded in a single summer post college using the open-source social networking engine Elgg, facebake.com was one of my early \"million dollar ideas\" that didn't quite pan out as I had hoped.  Though the user base has moved on, the site and the concept still make for humorous cocktail conversation."),
			"ato"         => array("col" => 1, "link" => "www.albanytakeout.com",       "title" => "Albanytakeout",           "desc" => "One of the more profitable of my personal website endeavors, I built Albanytakeout during my sophomore year of college and its visitor numbers have steadily increased ever since. It's basically a query able database of restaurant menus in Albany, NY."),
			"tradeflow"   => array("col" => 1, "link" => "www.dreamware-systems.com",   "title" => "Global Tradeflow Demo",   "desc" => "For the purpose of showcasing my work in quantative programming on large data sets, I extracted a single module of the GSIS suite and converted it to a functional demo. I scrambled the original data to avoid giving away a proprietary software tool but it is otherwise fully functional."),
			"dreamware"   => array("col" => 2, "link" => "www.dreamwaresys.com",        "title" => "Dreamware Systems LLC",   "desc" => "A simple company site built to showcase my abilities as a self-employed software developer. While the site is still live, I have since abondoned moonlighting work in order to focus on full-time employment."),
			"coocoo"      => array("col" => 2, "link" => "www.coocoo.com",              "title" => "CooCoo",                  "desc" => "While primarily tasked with developing the mobile app platform at CooCoo, the lean start-up culture dictated that I lend a hand anywhere it was needed, including with their website presence.  I cannot take full credit for the site design as it was a team effort."),
			"gsis"        => array("col" => 2, "link" => "gsis.worldsteeldynamics.com", "title" => "GSIS Interactive System", "desc" => "While working at WSD full-time my primary task was maintaining and enhancing an online suite of market forecasting and analysis tools known as the Global Steel Information System. While development of the site was a team effort, I was personally responsible for coding 3 of the 7 final modules."),
			"groovecard"  => array("col" => 2, "link" => "www.groovecard.com",          "title" => "Student Groove Card",     "desc" => "The first commerical website I was begrudgingly coersed into coding.  Please don't judge it based on the table-based layout, I was largely ignorant of web development techniques at the time. I include it here only to show how far I've come... "),
			"resume"      => array("col" => 2, "link" => "www.dreamwaresys.com/resume", "title" => "Personal Resume Website", "desc" => "This one is self-explanatory given the context... The neat thing is that the source code is available below"),
			
			);
	
		echo '<div class="cv_proj_split">'.chr(10);
		
		$currCol = 1;
		foreach($WebProjects as $name => $Proj)
		{
			$title = $Proj['title'];
			$link = $Proj['link'];
			$desc = $Proj['desc'];
	
			if($currCol != $Proj['col'])
			{
				$currCol++;
				echo '</div>'.chr(10);
				echo '<div class="cv_proj_split">'.chr(10);
			}
			echo '<div class="cv_proj_wrap">'.chr(10);
				echo '<div class="cv_proj_thumb"><img src="'.$CONFIG->url.'images/projects/thumbnails/web_'.$name.'.jpg" alt="'.$name.'" /></div>'.chr(10);
				echo '<div class="cv_proj_text">'.chr(10);
					echo '<div class="cv_proj_title">'.$title.'</div>'.chr(10);
					echo '<div class="cv_proj_link"><a href="http://'.$link.'" target="_blank">'.$link.'</a></div>'.chr(10);
					echo '<div class="cv_proj_desc">'.$desc.'</div>'.chr(10);
				echo '</div>'.chr(10);
			echo '</div>'.chr(10);
		}
			
		echo '</div>'.chr(10);
		
	?>
	<div class="clearfix"></div>
</div>  <!-- end web development -->
<!-- end portfolio -->


<div class="anchor_div" id="sourcecode"></div>
<div class="cv_section_title">Source Code Samples</div>
<div class="cv_section_clear" style="width:68%;">

	<div class="cv_proj_split">
		<div class="cv_proj_wrap cv_proj_app_wrap">
			<div class="cv_proj_thumb cv_proj_app" style="margin-left:10px;">
				<!-- <img src="<?=$CONFIG->url?>images/projects/thumbnails/app_holyquotes.jpg" alt="HolyQuotes App" /> -->
			</div>
			<div class="cv_proj_text" style="width:60%;margin-left:12px;">
				<div class="cv_proj_title">HolyQuotes (iOS)</div>
				<div class="cv_proj_link" style="clear:both;">Source Code Sample</div>
				<div class="cv_proj_desc">
					<div class="cv_download_btn" id="downloadLink" tag="holyquotes">Download Source Code</div>
				</div>
			</div>
		</div>
	</div>
	<div class="cv_proj_split">
		<div class="cv_proj_wrap">
			<div class="cv_proj_thumb">
				<!-- <img src="<?=$CONFIG->url?>images/projects/thumbnails/web_dreamware.jpg" alt="Dreamware Systems LLC" /> -->
			</div>
			<div class="cv_proj_text">
				<div class="cv_proj_title">Dreamware / Resume (Website)</div>
				<div class="cv_proj_link" style="clear:both;">Source Code Sample</div>
				<div class="cv_proj_desc">
					<div class="cv_download_btn" id="downloadLink" tag="dreamware">Download Source Code</div>
				</div>
			</div>
		</div>
	</div>
</div> <!-- end code samples -->


<script>
	/* custom twinkle starter 
	$(document).ready(function(){
		configureStarlightForHomepage();
	});*/
	
	$(document).on('click', '#downloadResumeLink', function(){
		document.location.href = '<?=$CONFIG->url?>resume/download.php?target=resume';
	});
</script>
<?php

$PT->printContentEnd();
$PT->printWrapperEnd();
$PT->outputPage();

?>