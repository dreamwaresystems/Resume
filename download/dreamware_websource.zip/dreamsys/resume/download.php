<?php
//================================
//  Download Resume Link Control 
//================================
//
//  basically this code just timestamps any download 
//  and requests no-caching by browsers in attempt to 
//  preserve integrity post any changes to the target file
//

include_once('../library/start.php');
global $CONFIG;

$target = $_GET['target'];

$filePath = ""; // path to file on local disk
$fileName = ""; // user-friendly filename
$contentType = ""; // content-type

if($target=="resume")
{
	$filePath = $CONFIG->url."resume/download/resume.docx"; // path to file on local disk
	$fileName = "Michael T Jones - Resume ".date("Ymd").".docx"; // user-friendly filename
	$contentType = "docx"; // content-type
}
else if($target=="holyquotes")
{
	$filePath = $CONFIG->url."resume/download/holyquotes_appsource.zip"; // path to file on local disk
	$fileName = "MTJ HolyQuotes AppSource ".date("Ymd").".zip"; // user-friendly filename
	$contentType = "zip"; // content-type
}
else if($target=="dreamware")
{
	$filePath = $CONFIG->url."resume/download/dreamware_websource.zip"; // path to file on local disk
	$fileName = "MTJ Dreamware WebSource ".date("Ymd").".zip"; // user-friendly filename
	$contentType = "zip"; // content-type
}
else
	exit('Error: bad file reference');

header('Content-type: application/'.$contentType);
header('Content-Disposition: attachment; filename="'.$fileName.'"');
header('Cache-Control: no-store, no-cache, max-age=0, must-revalidate');
//header('Content-Length: '.(string)(filesize($filePath)));
//echo $filePath;

readfile($filePath);

?>