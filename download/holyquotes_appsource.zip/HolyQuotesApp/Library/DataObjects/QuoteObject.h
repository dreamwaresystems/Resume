//
//  QuoteObject.h
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface QuoteObject : NSObject {
    
}

@property (nonatomic,assign) int vid;
@property (nonatomic,assign) int bid;
@property (nonatomic,assign) int testament;
@property (nonatomic,copy) NSString *author;
@property (nonatomic,assign) int book;
@property (nonatomic,assign) int chapter;
@property (nonatomic,assign) int verse;
@property (nonatomic,assign) int rating;
@property (nonatomic,copy) NSString *quote;
@property (nonatomic,copy) NSString *type;

- (id)initWithRow:(sqlite3_stmt *)init_statement;
-(void)saveToFavoritesDatabase:(sqlite3 *)database;
-(NSString *)getProverb;

@end
