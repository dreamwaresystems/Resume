//
//  BookObject.h
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface BookObject : NSObject {
    
}

@property (nonatomic,assign) int bid;
@property (nonatomic,assign) int testament;
@property (nonatomic,copy) NSString *author;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,assign) int book;
@property (nonatomic,assign) int chapters;

- (id)initWithRow:(sqlite3_stmt *)init_statement;

@end
