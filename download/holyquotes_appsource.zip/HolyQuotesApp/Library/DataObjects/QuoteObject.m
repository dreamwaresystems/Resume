//
//  QuoteObject.m
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "QuoteObject.h"
#import <sqlite3.h>

@implementation QuoteObject

@synthesize vid;
@synthesize bid;
@synthesize testament;
@synthesize author;
@synthesize book;
@synthesize chapter;
@synthesize verse;
@synthesize rating;
@synthesize quote;
@synthesize type;

-(void) dealloc
{
}

- (id)initWithRow:(sqlite3_stmt *)init_statement
{
    self = [self init];
    if(self)
    {
        self.vid = sqlite3_column_int(init_statement, 0);
        self.bid = sqlite3_column_int(init_statement, 1);
        self.testament = sqlite3_column_int(init_statement, 2);
        self.author = [NSString stringWithFormat:@"%s", sqlite3_column_text(init_statement, 3)];
        self.book = sqlite3_column_int(init_statement, 4);
        self.chapter = sqlite3_column_int(init_statement, 5);
        self.verse = sqlite3_column_int(init_statement, 6);
        self.rating = sqlite3_column_int(init_statement, 7);
        self.quote = [NSString stringWithFormat:@"%s", sqlite3_column_text(init_statement, 8)];
        self.type = [NSString stringWithFormat:@"%s", sqlite3_column_text(init_statement, 9)];
    }
    
    return(self);
}

- (id)init {
    self = [super init];
    if (self) {
    }
    return self;
}

-(NSString *)getProverb
{
    NSMutableString * proverb = [NSMutableString stringWithString: @""];
    if(self.book != 0)
        [proverb appendFormat:@"%d", self.book];
    [proverb appendFormat:@" %@", self.author];
    [proverb appendFormat:@" %d:%d", self.chapter, self.verse];
    return proverb;
}

//saves to favorites! not the quotes arc!
-(void)saveToFavoritesDatabase:(sqlite3 *)database
{
    sqlite3_stmt *init_statement = nil;

    //see if already exists
    NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT * FROM arc_faves WHERE "]; 
    [query appendFormat:@"vid = '%d'", self.vid];
    if(sqlite3_prepare_v2(database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"Error: Database query failed '%s'.", sqlite3_errmsg(database));
    
    if(sqlite3_step(init_statement)== SQLITE_ROW)
    {
         //it already exists in favorites table, do nothing
        return;
    }
    else
    {        
        query = [NSMutableString stringWithFormat: @"INSERT INTO `arc_faves` VALUES ("];
        [query appendFormat:@"'%d','%d','%d','%@','%d',", self.vid, self.bid, self.testament, self.author, self.book];
        [query appendFormat:@"'%d','%d','%d', '%@', '');", self.chapter, self.verse, self.rating, self.quote];
        
        //NSLog(@"%@", query);
        if(sqlite3_prepare_v2(database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
            NSLog(@"Error: Stations update query failed '%s'.", sqlite3_errmsg(database));
        if(sqlite3_step(init_statement) != SQLITE_DONE)
            NSLog(@"ERR: %s",sqlite3_errmsg(database));
    }
    return;
}


@end
