//
//  BookObject.m
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BookObject.h"
#import <sqlite3.h>

@implementation BookObject

@synthesize bid;
@synthesize testament;
@synthesize author;
@synthesize title;
@synthesize book;
@synthesize chapters;

-(void) dealloc
{
}

- (id)initWithRow:(sqlite3_stmt *)init_statement
{
    self = [self init];
    if(self)
    {
        self.bid = sqlite3_column_int(init_statement, 0);
        self.testament = sqlite3_column_int(init_statement, 1);
        self.author = [NSString stringWithFormat:@"%s", sqlite3_column_text(init_statement, 2)];
        self.title= [NSString stringWithFormat:@"%s", sqlite3_column_text(init_statement, 3)];
        self.book = sqlite3_column_int(init_statement, 4);
        self.chapters = sqlite3_column_int(init_statement, 5);
    }
    
    return(self);
}

- (id)init {
    self = [super init];
    if (self) {
        self.bid = -1;
    }
    return self;
}


@end
