//
//  GabrielAppDelegate.m
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "GabrielAppDelegate.h"
#import "QuoteView.h"
#import "GabrielViewController.h"
#import "SettingsViewController.h"
#import "CustomTabBarController.h"
#import "FavViewController.h"
#import "settings.h"
#import "functions.h"
#import "BookObject.h"
#import "CategoryListController.h"
#import "PurchaseViewController.h"

@implementation UINavigationBar (TENavigationBar)
- (void)drawRect:(CGRect)rect 
{
    UIImage *img = [UIImage imageNamed: @"header_blank.png"];
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextDrawImage(context, CGRectMake(0, 0, 320, self.frame.size.height), img.CGImage);

    UIColor *color = [UIColor blackColor];
    /*
    UIImage *img  = [UIImage imageNamed: @"header_blank.png"];
    [img drawInRect:CGRectMake(0, 0, 320, 51)];*/
    self.tintColor = color;
}
@end

@implementation GabrielAppDelegate


//NSString *const FBSessionStateChangedNotification = @"com.dreamwaresystems.holyquotes:FBSessionStateChangedNotification";


@synthesize window = _window;
@synthesize viewController = _viewController;
@synthesize database = database;
@synthesize mainQuote;
@synthesize selectedBooks;
@synthesize catsAreEnabled;
@synthesize action;

#pragma mark - Main App Calls
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.mainQuote = nil;
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    
    /*if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        self.viewController = [[GabrielViewController alloc] initWithNibName:@"GabrielViewController_iPhone" bundle:nil];
    } else {
        self.viewController = [[GabrielViewController alloc] initWithNibName:@"GabrielViewController_iPad" bundle:nil];
    }*/
    
    //in-App purchase observer
    //MKStoreObserver *observer = [[MKStoreObserver alloc] init];
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    
    //check version
    float currentVersion = APP_VERSION;
    float previousVersion;
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    previousVersion = [[prefs objectForKey:@"version"] floatValue];

    //update proceedures if needed
    if(currentVersion > previousVersion)
        [self updateFromVersion:previousVersion toVersion:currentVersion];
    
    //database support
    [self createEditableCopyOfDatabaseIfNeeded:FLUSH_DATABASE];  //set to 1 to flush out old database and replace on Phone
    if(![self initializeDatabase])
        NSLog(@"%@", @"Unable to initialize database!");
    
    //save version number
    [prefs setObject:[NSNumber numberWithFloat:currentVersion] forKey:@"version"];
    
    //create category view count if it doesn't exist
    NSNumber * catViewCount = [prefs objectForKey:@"catViewCount"];
    if(catViewCount==nil)
        [prefs setObject:[NSNumber numberWithInt:0] forKey:@"catViewCount"];
         
    //create catEnabled flag if it doesn't exist
    NSString * catsEnabled = [prefs objectForKey:@"CategoriesEnabled"];
    if(catsEnabled==nil)
    {
        self.catsAreEnabled = FALSE;
        [prefs setObject:@"0" forKey:@"CategoriesEnabled"];
    }
    else if([catsEnabled isEqualToString:@"1"])
        self.catsAreEnabled = TRUE;
    else
        self.catsAreEnabled = FALSE;
    
    [prefs synchronize];
    
    //check for selected books string, if not, make it
    NSMutableArray *selBooks = [[NSMutableArray alloc] init];
    selBooks = [prefs objectForKey:@"selectedBooks"];
    if(selBooks==nil || [selBooks count]<=0) //it's empty, create it
    {
        selBooks = [self createSelectedBooksList];
        [self saveBookList];
    }
    self.selectedBooks = selBooks;
    
    //tab Bar
    tabBarController = [[CustomTabBarController alloc] init];
    
    //main screen
    mainScreen = [[QuoteView alloc] init];
    UINavigationController * navCont1 = [[UINavigationController alloc] initWithRootViewController:mainScreen];
    navCont1.navigationBar.tintColor = COL_DARK_BROWN;
    
    favScreen = [[FavViewController alloc] init];
    UINavigationController * navCont2 = [[UINavigationController alloc] initWithRootViewController:favScreen];
    navCont2.navigationBar.tintColor = COL_DARK_BROWN;
    
    categoryScreen = [[CategoryListController alloc] init];
    purchaseScreen = [[PurchaseViewController alloc] init];
    UINavigationController * navCont3 = [[UINavigationController alloc] initWithRootViewController:categoryScreen];
    navCont3.navigationBar.tintColor = COL_DARK_BROWN;
    
    settingsScreen = [[SettingsViewController alloc] init];
    UINavigationController * navCont4 = [[UINavigationController alloc] initWithRootViewController:settingsScreen];
    navCont4.navigationBar.tintColor = COL_DARK_BROWN;
    
    tabBarController.viewControllers = [NSArray arrayWithObjects:navCont1, navCont2, navCont3, navCont4, nil];
    self.window.rootViewController = tabBarController;

    //background for all list views
    UIImageView * backView = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    backView.contentMode = UIViewContentModeScaleToFill;
    backView.image = [UIImage imageNamed:@"background.png"];
    //[backView sizeToFit];
    
    [self.window addSubview:backView];
    if(!isPad())
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault]; //TODO: Make sure this works in iOS7+
    
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    //[FBSession.activeSession handleDidBecomeActive];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    //[FBSession.activeSession close];
}

#pragma mark - In App Purchase Functions
- (void)loadStore
{
    // restarts any purchases if they were interrupted last time the app was open
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    
    // get the product description (defined in early sections)
    //[self requestProUpgradeProductData];
}
- (BOOL)canMakePurchases
{
    return [SKPaymentQueue canMakePayments];
}
- (void)purchaseProduct:(SKProduct *) product
{
    SKPayment *payment = [SKPayment paymentWithProduct:product];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}
-(void)provideContent:(NSString *)productID 
{
    if([productID isEqualToString:INAPP_CAT_PURCHASE_ID])
    {
        NSUserDefaults * prefs = [[NSUserDefaults alloc] init];
        [prefs setValue:@"1" forKey:@"CategoriesEnabled"];
        [prefs synchronize];
    }
}
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    for (SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
                break;
            default:
                break;
        }
    }
} 

#pragma mark - In App Purchase Helpers
- (void)recordTransaction:(SKPaymentTransaction *)transaction
{
    if ([transaction.payment.productIdentifier isEqualToString:INAPP_CAT_PURCHASE_ID])
    {
        // save the transaction receipt to disk
        
        //TODO: Update this to work with iOS7+
        /*
        [[NSUserDefaults standardUserDefaults] setValue:transaction.transactionReceipt forKey:@"categoryTransactionReceipt" ];
        [[NSUserDefaults standardUserDefaults] synchronize];
        */
    }
} 
- (void)completeTransaction:(SKPaymentTransaction *)transaction
{
    [self recordTransaction:transaction];
    [self provideContent:transaction.payment.productIdentifier];
    [self finishTransaction:transaction wasSuccessful:YES];
}
- (void)restoreTransaction:(SKPaymentTransaction *)transaction
{
    [self recordTransaction:transaction.originalTransaction];
    [self provideContent:transaction.originalTransaction.payment.productIdentifier];
    [self finishTransaction:transaction wasSuccessful:YES];
}
- (void)failedTransaction:(SKPaymentTransaction *)transaction
{
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        // error!
        [self finishTransaction:transaction wasSuccessful:NO];
    }
    else
    {
        // this is fine, the user just cancelled, so don’t notify
        [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    }
}
- (void)finishTransaction:(SKPaymentTransaction *)transaction wasSuccessful:(BOOL)wasSuccessful
{
    // remove the transaction from the payment queue.
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:transaction, @"transaction" , nil];
    if (wasSuccessful)
    {
        // send out a notification that we’ve finished the transaction
        [[NSNotificationCenter defaultCenter] postNotificationName:INAPP_CAT_PURCHASE_SUCCESS object:purchaseScreen userInfo:userInfo];
    }
    else
    {
        //Testing For Success 
        //[self provideContent:transaction.payment.productIdentifier];
        //[[NSNotificationCenter defaultCenter] postNotificationName:INAPP_CAT_PURCHASE_SUCCESS object:purchaseScreen userInfo:userInfo];
        
        // send out a notification for the failed transaction
        [[NSNotificationCenter defaultCenter] postNotificationName:INAPP_CAT_PURCHASE_FAILURE object:purchaseScreen userInfo:userInfo];
    }
} 




#pragma mark - Version Update
-(void)updateFromVersion:(float)oldVersion toVersion:(float)newVersion
{
    BOOL replaceDatabase = false;
    
    if(fequal(newVersion,1.1)) //added cats
        replaceDatabase = true;
    
    if(replaceDatabase)
    {
        if([self initializeDatabase]) //initialize old database if we can
        {
            //save the user's old favorites
            NSMutableArray * oldFaves = [[NSMutableArray alloc] init];
            NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT * FROM arc_faves;"];
            sqlite3_stmt * init_statement;//[self select_query:query];
            if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
                NSLog(@"%s", sqlite3_errmsg(self.database));
            while(sqlite3_step(init_statement)== SQLITE_ROW)
            {
                QuoteObject * quoteObj = [[QuoteObject alloc] initWithRow:init_statement];
                [oldFaves addObject:quoteObj];
            }
            sqlite3_close(database);
            
            //flush to new database
            [self createEditableCopyOfDatabaseIfNeeded:1];
            if(![self initializeDatabase])
                NSLog(@"%@", @"Unable to initialize new database");
            
            //add back all our old favorites
            for(QuoteObject * quoteObj in oldFaves)
                [quoteObj saveToFavoritesDatabase:self.database];
        }
        else
            [self createEditableCopyOfDatabaseIfNeeded:1]; //old one doesnt exist, just flush to new
    }
}



#pragma mark - Database Functions
//===== Database Functions ======

// Creates a writable copy of the bundled default database in the application Documents directory.
- (void)createEditableCopyOfDatabaseIfNeeded:(NSInteger)flush 
{
    // First, test for existence.
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"archangel.sqlite"];
    success = [fileManager fileExistsAtPath:writableDBPath];
    if (success)
    {
        if(flush!=0)
        {
            [fileManager removeItemAtPath:writableDBPath error:&error];
        }
        else
            return;
    }
    // The writable database does not exist, so copy the default to the appropriate location.
    NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"archangel.sqlite"];
    success = [fileManager copyItemAtPath:defaultDBPath toPath:writableDBPath error:&error];
    if (!success) 
        NSLog(@"Failed to create writable database file with message '%@'.", [error localizedDescription]);
}

// Open the database connection and retrieve minimal information for all objects.
- (BOOL)initializeDatabase
{
    @try 
    {
        // The database is stored in the application bundle. 
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *path = [documentsDirectory stringByAppendingPathComponent:@"archangel.sqlite"];
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if(![fileManager fileExistsAtPath:path])
            return false;
        
        // Open the database. The database was prepared outside the application.
        if (!sqlite3_open([path UTF8String], &database) == SQLITE_OK) 
        {
            // Even though the open failed, call close to properly clean up resources.
            sqlite3_close(database);
            NSLog(@"Failed to open database with message '%s'.", sqlite3_errmsg(database));
            // Additional error handling, as appropriate...
        }
        return true;
    }
    @catch (NSException *exception) 
    {
        NSLog(@"main: Caught %@: %@", [exception name], [exception reason]);
        return false;
    }
}





#pragma mark - Helper Functions
//creates list of all books in database
-(NSMutableArray *)createSelectedBooksList
{
    //get books in database
    NSMutableArray * bookList = [[NSMutableArray alloc] init];
    NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT * FROM arc_books WHERE arc_books.bid IN (SELECT bid FROM arc_verses);"];
    sqlite3_stmt * init_statement;
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"%s", sqlite3_errmsg(self.database));
    while(sqlite3_step(init_statement)== SQLITE_ROW)
    {
        BookObject * book = [[BookObject alloc] initWithRow:init_statement];
        [bookList addObject:[NSNumber numberWithInt: book.bid]];
    }
    return bookList;
}

-(void)saveBookList  
{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setObject:self.selectedBooks forKey:@"selectedBooks"];
    [prefs synchronize];
}

//get view's max width/height allowed for this device given context
-(CGRect)getViewBounds:(NSString *)context
{
    CGRect screen = [[UIScreen mainScreen] bounds];
    if([context isEqualToString:@"tbl"])
        screen.size.height -= TBL_HEIGHT_OFFSET;
    else
        screen.size.height -= STD_HEIGHT_OFFSET;
    return screen;
}


//get quote categories
-(NSMutableArray *)getCategories
{
    NSMutableArray * categories = [[NSMutableArray alloc] init];
    [categories addObject:[NSArray arrayWithObjects:@"A", @"Love", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"B", @"Faith", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"C", @"Bereavement", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"D", @"Forgiveness", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"E", @"Inspiration",nil]];
    [categories addObject:[NSArray arrayWithObjects:@"F", @"Mercy", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"G", @"Guidance", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"H", @"Quotes for Anger", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"I", @"Law of the Lord", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"J", @"Charity", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"K", @"Wrath of God", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"L", @"Quotes for Women", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"M", @"Quotes for Men", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"N", @"Growing Up", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"O", @"Patience", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"P", @"Temptation", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"Q", @"Wisdom", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"R", @"Friendship", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"S", @"Penance", nil]];
    [categories addObject:[NSArray arrayWithObjects:@"T", @"Quotes for Battle", nil]];
    return categories;
}

-(void)loadPurchaseView
{
    UINavigationController * navCont = categoryScreen.navigationController;
    [navCont setViewControllers:[NSArray arrayWithObject:purchaseScreen]];
}
//load category view screen
-(void)loadCatgoryView
{
    UINavigationController * navCont = purchaseScreen.navigationController;
    [navCont setViewControllers:[NSArray arrayWithObject:categoryScreen]];
}




#pragma mark - Facebook Post Functions
//TODO: Update Facebook Code to iOS7+
-(void)authorizeFacebook
{
   /* if (!FBSession.activeSession.isOpen)
    {
        // The user has initiated a login, so call the openSession method
        // and show the login UX if necessary.
        [self openSessionWithAllowLoginUI:YES];
    }
    else
    {
        [self postQuoteToFacebook];
    }*/
}
-(BOOL)openSessionWithAllowLoginUI:(BOOL)allowLoginUI
{
    /*NSArray *permissions = [[NSArray alloc] initWithObjects:@"email", nil];
    //@"publish_stream",
    return [FBSession openActiveSessionWithReadPermissions:permissions allowLoginUI:allowLoginUI completionHandler:^(FBSession *session, FBSessionState state,NSError *error)
    {
        [self sessionStateChanged:session state:state error:error];
    }];*/
    return true;
}
//TODO: Update Facebook Code to iOS7+
//- (void)sessionStateChanged:(FBSession *)session state:(FBSessionState)state error:(NSError *)error
//{
    /*switch (state)
    {
        case FBSessionStateOpen:
            if (!error) {
                // We have a valid session
                NSLog(@"User session found");
                [self postQuoteToFacebook];
            }
            break;
        case FBSessionStateClosed:
        case FBSessionStateClosedLoginFailed:
            [FBSession.activeSession closeAndClearTokenInformation];
            
            break;
        default:
            break;
    }
    
    //[[NSNotificationCenter defaultCenter] postNotificationName:FBSessionStateChangedNotification object:session];
    
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Error"
                                  message:error.localizedDescription
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }*/
//}

-(void)postQuoteToFacebook
{
    self.action = @"";
    //UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"HERE" message:@"HERE" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    //[alert show];
}


#pragma mark - Facebook Delegates
/*
 * If we have a valid session at the time of openURL call, we handle
 * Facebook transitions by passing the url argument to handleOpenURL
 */
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    // attempt to extract a token from the url
    //return [FBSession.activeSession handleOpenURL:url];
    return true;
}
- (void)fbDidLogin
{
    //if([self.action isEqualToString:@"uploadToFacebook"])
    {
        [self postQuoteToFacebook];
    }
}
- (void)fbDidLogout
{
    return;
}
- (void)fbDidNotLogin:(BOOL)cancelled
{
    UIAlertView * failedAlert = [[UIAlertView alloc] initWithTitle:@"Facebook Login Canceled" message:@"Unable to post quote to facebook." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    failedAlert.tag=10; //failure
    [failedAlert show];
}
- (void)fbSessionInvalidated
{
    UIAlertView * failedAlert = [[UIAlertView alloc] initWithTitle:@"Facebook Login Failed" message:@"Unable to post quote to facebook." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    failedAlert.tag=10; //failure
    [failedAlert show];
}
- (void)fbDidExtendToken:(NSString*)accessToken expiresAt:(NSDate*)expiresAt
{
    return;
}

#pragma mark - Post Request Handlers
//TODO: Update Facebook Code to iOS7+
/*
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error
{
    NSLog(@"Request error: %@", [error description]);
}
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"Success response: %@", response);
}*/



@end



