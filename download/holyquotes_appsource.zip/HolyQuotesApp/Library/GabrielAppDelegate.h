//
//  GabrielAppDelegate.h
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import "QuoteObject.h"
#import <StoreKit/StoreKit.h>
//#import <FacebookSDK/FacebookSDK.h>
#import "Twitter/TWTweetComposeViewController.h" 

@class GabrielViewController;

//extern NSString *const FBSessionStateChangedNotification;


@interface GabrielAppDelegate : UIResponder <UIApplicationDelegate, SKPaymentTransactionObserver>
{
    UITabBarController * tabBarController;
    UIViewController * mainScreen;
    UIViewController * favScreen;
    UIViewController * settingsScreen;
    UIViewController * categoryScreen;
    UIViewController * purchaseScreen;
    sqlite3 * database;
}
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) GabrielViewController *viewController;
@property (nonatomic, assign) sqlite3 * database;
@property (strong, nonatomic) QuoteObject * mainQuote;
@property (strong, nonatomic) NSMutableArray * selectedBooks;
@property (nonatomic, retain) NSString * action; //an action like "post to facebook" that requires breaking control flow

@property (nonatomic, assign) BOOL catsAreEnabled;

- (BOOL)initializeDatabase;
- (void)createEditableCopyOfDatabaseIfNeeded:(NSInteger)flush;
-(NSMutableArray *)createSelectedBooksList;
-(void)saveBookList;
-(void)updateFromVersion:(float)oldVersion toVersion:(float)newVersion;

//get view max width/height allowed for this device
-(CGRect)getViewBounds:(NSString *)context;

-(NSMutableArray *)getCategories;

//in app purchase functions
- (void)loadStore;
- (BOOL)canMakePurchases;
- (void)purchaseProduct:(SKProduct *) product;
-(void)provideContent:(NSString *)productID;
- (void)finishTransaction:(SKPaymentTransaction *)transaction wasSuccessful:(BOOL)wasSuccessful;

//in app purchase helpers
- (void)recordTransaction:(SKPaymentTransaction *)transaction;
- (void)completeTransaction:(SKPaymentTransaction *)transaction;
- (void)restoreTransaction:(SKPaymentTransaction *)transaction;
- (void)failedTransaction:(SKPaymentTransaction *)transaction;

-(void)loadPurchaseView;
-(void)loadCatgoryView;

//Facebook post functions
-(void)authorizeFacebook;
-(void)postQuoteToFacebook;
-(BOOL)openSessionWithAllowLoginUI:(BOOL)allowLoginUI;

@end
