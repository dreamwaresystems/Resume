//
//  FavViewController.h
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "QuoteView.h"

@interface FavViewController : BaseViewController <UITableViewDataSource, UITableViewDelegate, UIAlertViewDelegate>
{
    UITableView * localTableView;
    NSMutableArray * quoteList;
    
    //buttons
    UIBarButtonItem *editButton;
    UIBarButtonItem *clearButton;
    
    UILabel * noFavesLabel;
}

-(void)refreshButtons;
-(void)loadFaves;
- (UITableViewCell *) getCellContentView:(NSString *)cellIdentifier;
@end
