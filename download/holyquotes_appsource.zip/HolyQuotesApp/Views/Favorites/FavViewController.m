//
//  FavViewController.m
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "FavViewController.h"
//#import "QuoteObject.h"
#import "GabrielAppDelegate.h"
#import "settings.h"
#import "functions.h"
#import <QuartzCore/QuartzCore.h>

@implementation FavViewController

-(id)init
{
    self.title = @"Favorites";
    self.tabBarItem.image = [UIImage imageNamed:@"29-heart.png"];
    return [super init];
}

#pragma mark - View lifecycle
-(void)loadView
{
    GabrielAppDelegate *theDelagate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    CGRect screen = [theDelagate getViewBounds:@"tbl"];
    
    int header_height = 23; //includes graphic offset at top
    CGRect MF = [[UIScreen mainScreen] bounds];
    CGSize MS = MF.size;
    
    //add edit button
    editButton = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editList)];
    //self.navigationItem.rightBarButtonItem = editButton;
    
    //add clear button
    clearButton = [[UIBarButtonItem alloc] initWithTitle:@"Clear" style:UIBarButtonItemStylePlain target:self action:@selector(clearListPrompt)];
    //self.navigationItem.rightBarButtonItem = clearButton;
    
    UIView * tempView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen.size.width, screen.size.height)];
    self.view = tempView;
    localTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 10, screen.size.width, screen.size.height - header_height) style:UITableViewStyleGrouped];
    localTableView.dataSource = self;
    localTableView.delegate = self;
    localTableView.backgroundColor = [UIColor clearColor];
    localTableView.backgroundView = nil;
    UIImageView * headBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, MS.width, 27)];
    headBack.contentMode = UIViewContentModeScaleToFill;
    if (isPad())
        headBack.image = [UIImage imageNamed:@"fav_header_wide.png"];
    else
        headBack.image = [UIImage imageNamed:@"fav_header.png"];
    
    //to add extra hieght to table
    UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen.size.width, 20)];
    localTableView.tableHeaderView = header;
    
    //no faves label
    noFavesLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height/2-70, self.view.frame.size.width, 50)];
    noFavesLabel.text = @"No favorites to display";
    noFavesLabel.backgroundColor = [UIColor clearColor];
    noFavesLabel.font = [UIFont fontWithName:@"Arial" size:18];
    noFavesLabel.hidden = TRUE;
    noFavesLabel.textAlignment = NSTextAlignmentCenter;
    noFavesLabel.textColor = COL_DARK_BROWN;
    noFavesLabel.layer.shadowColor = [[UIColor whiteColor] CGColor];
    noFavesLabel.layer.shadowOffset = CGSizeMake(0, 0);
    noFavesLabel.layer.shadowRadius = 3;
    noFavesLabel.layer.shadowOpacity = .95;
    noFavesLabel.layer.masksToBounds = NO;
    noFavesLabel.shadowColor = [UIColor whiteColor];
    
    [self.view addSubview:noFavesLabel];
    
    
    [self.view addSubview: localTableView];
    self.view.backgroundColor = [UIColor clearColor];
    //[localTableView.backgroundView addSubview:backView];
    [self.view addSubview:headBack];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}
-(void)viewWillAppear:(BOOL)animated
{
    //change back button on next page
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:nil action:nil];

    [self refreshButtons];
}
-(void)viewDidAppear:(BOOL)animated
{
    [self loadFaves];
    [localTableView reloadData];
    [self refreshButtons];
    
    [super viewDidAppear:animated];
}
- (void)viewDidUnload{
    [super viewDidUnload];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(void)loadFaves
{
    quoteList = [[NSMutableArray alloc] init];
    NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT * FROM arc_faves;"];
    sqlite3_stmt * init_statement;//[self select_query:query];
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"%s", sqlite3_errmsg(self.database));
    while(sqlite3_step(init_statement)== SQLITE_ROW)
    {
        QuoteObject * quoteObj = [[QuoteObject alloc] initWithRow:init_statement];
        [quoteList addObject:quoteObj];
    }
}


#pragma mark - Table View 
//TABLE VIEW
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if([quoteList count]>0)
        noFavesLabel.hidden = TRUE;
    else
        noFavesLabel.hidden = FALSE;
    
    return [quoteList count];
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"";
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    return 40;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
        cell = [self getCellContentView:CellIdentifier];
    QuoteObject * quoteObj = [quoteList objectAtIndex:indexPath.row];
    
    UILabel *lblText = (UILabel *)[cell viewWithTag:1];
    lblText.text = [quoteObj getProverb];
    return cell;
}
- (UITableViewCell *) getCellContentView:(NSString *)cellIdentifier 
{    
    CGRect CellFrame = CGRectMake(0, 0, 320, 40);
    UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    
    UILabel *lblTemp;
    
    //main text
    CGRect nightFrame = CGRectMake(10, 0, 320, 40);
    lblTemp = [[UILabel alloc] initWithFrame:nightFrame];
    lblTemp.tag = 1;
    lblTemp.font = [UIFont fontWithName:@"Arial" size:16];
    lblTemp.backgroundColor = [UIColor clearColor];
    [cell.contentView addSubview:lblTemp];
    
    return cell;
}
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    QuoteObject * quoteObj = [quoteList objectAtIndex:indexPath.row];
    
    QuoteView * quoteView = [[QuoteView alloc] init];
    [quoteView setFavoriteViewQuote:quoteObj];
    [self.navigationController pushViewController:quoteView animated:TRUE];
    
    [localTableView deselectRowAtIndexPath:indexPath animated:true];
    
    //[self.tabBarController setSelectedIndex:0]; //removed MTJ 2013-08-03
}

// TABLE EDITING
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle==UITableViewCellEditingStyleDelete)
    {
        QuoteObject * quoteObj = [quoteList objectAtIndex:indexPath.row];
        //remove object from database
        NSString *query = [NSString stringWithFormat:@"DELETE FROM arc_faves WHERE vid = '%d'",  quoteObj.vid];
        [self ddl_query:query];
        
        [quoteList removeObjectAtIndex:indexPath.row];
        
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationFade];
        [tableView endUpdates];
    }
    [self refreshButtons];
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:COL_LIGHT_BROWN2];
}


#pragma mark - List Functions

-(void)refreshButtons
{
    if([quoteList count]==0)
    {
        [self.navigationItem setLeftBarButtonItem: nil];
        [self.navigationItem setRightBarButtonItem: nil];
    }
    else
    {
        [self.navigationItem setLeftBarButtonItem: editButton];
        [self.navigationItem setRightBarButtonItem: clearButton];
    }
}
- (void) clearListPrompt
{
    NSString * msg = @"Erase all of your favorites?";
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:msg message:nil delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
    [alert show];
}
- (void) clearList
{
    //remove trip from database
    NSString *query = [NSString stringWithFormat:@"DELETE FROM arc_faves WHERE 1=1"];
    [self ddl_query:query];
    [quoteList removeAllObjects];
    [localTableView reloadData];
    [self refreshButtons];
}
- (void) editList
{
    [localTableView setEditing:true animated:true];
    editButton.title = @"Done";
    editButton.style = UIBarButtonItemStyleDone;
    editButton.action = @selector(unEditList);
}
- (void) unEditList
{
    [localTableView setEditing:false animated:true];
    editButton.title = @"Edit";
    editButton.style = UIBarButtonItemStylePlain;
    editButton.action = @selector(editList);
}


#pragma mark - AlertView Delegate
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(buttonIndex==1) //OK
       [self clearList];
}

@end

