//
//  PurchaseViewController.h
//  HolyQuotes
//
//  Created by Mike Jones on 12/20/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "BaseViewController.h"
#import <StoreKit/StoreKit.h>

@interface PurchaseViewController : BaseViewController <SKProductsRequestDelegate, SKRequestDelegate>
{
    UIButton * button;
    UILabel * price;
    UILabel * productLoadFalure;
}

@property (nonatomic, retain) SKProduct * product;


- (void)initiatePurchase;
- (void)requestProductData;
-(void)purchaseSuccessfulCallback;
@end
