//
//  PurchaseViewController.m
//  HolyQuotes
//
//  Created by Mike Jones on 12/20/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "PurchaseViewController.h"
#import "settings.h"
#import "GabrielAppDelegate.h"
#import <StoreKit/StoreKit.h>
#import "SKProduct+LocalizedPrice.h"

@implementation PurchaseViewController

@synthesize product;

- (id)init
{
    self.title = @"Categories Trial Expired";
    self.tabBarItem.title = @"Categories";
    self.tabBarItem.image = [UIImage imageNamed:@"152-rolodex.png"];
    return [super init];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)loadView
{
    self.view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 376)];
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIImage * backImage = [UIImage imageNamed:@"background.png"];
    UIImageView * backView = [[UIImageView alloc] initWithFrame:self.view.frame];
    backView.image = backImage;
    [self.view addSubview:backView];
    
    [super viewDidLoad];
    
    //little wood edging
    UIImageView * headBack = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"fav_header.png"]];
    [self.view addSubview:headBack];
    
    //description
    NSMutableString * desc = [NSMutableString stringWithString:@""];
    [desc appendString:@"The Categories Section of Holy Quotes is a premium feature.\n\n "];
    [desc appendString:@"You have reached the maximum category views allowed by the trial version. "];
    [desc appendString:@" For a one-time fee you can have unlimited access to our convenient library of categorized bible quotes."];
    UILabel * description = [[UILabel alloc] initWithFrame:CGRectMake(10, 20, 300, 250)];
    description.font = [UIFont systemFontOfSize:20];
    description.lineBreakMode  = NSLineBreakByWordWrapping;
    description.numberOfLines = 0;
    description.textAlignment = NSTextAlignmentCenter;
    description.text = desc;
    //description.backgroundColor = COL_LIGHT_BROWN3;
    description.backgroundColor = [UIColor clearColor];
    description.textColor = [UIColor blackColor];
    [self.view addSubview:description];
    
    //get the product price and stuff
    [self requestProductData];
    
    //price
    price = [[UILabel alloc] initWithFrame:CGRectMake(200, 0, 80, 45)];
    price.text = @"...";
    price.textAlignment = NSTextAlignmentCenter;
    price.font = [UIFont boldSystemFontOfSize:17];
    price.textColor = COL_DARK_GREEN;
    price.backgroundColor = [UIColor clearColor];
    
    //purchase button
    UIImage * buttonImage = [UIImage imageNamed:@"button_back_wide.png"];
    button = [[UIButton alloc] initWithFrame:CGRectMake(20, 290, 280, 45)];
    [button setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [button addSubview:price];
    [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [button setTitle: @"   Purchase Categories" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    [button.titleLabel setFont:[UIFont boldSystemFontOfSize:15]];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal|UIControlStateHighlighted| UIControlStateDisabled|UIControlStateSelected];
    button.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    button.titleLabel.textColor = [UIColor blackColor];
    button.titleLabel.textAlignment = NSTextAlignmentLeft;
    [button addTarget:self action:@selector(initiatePurchase) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    [button setHidden:TRUE];
    
    //failure to load product label
    productLoadFalure = [[UILabel alloc] initWithFrame:CGRectMake(20, 290, 280, 45)];
    productLoadFalure.backgroundColor = [UIColor clearColor];
    productLoadFalure.font = [UIFont boldSystemFontOfSize:15];
    productLoadFalure.textAlignment = NSTextAlignmentCenter;
    productLoadFalure.textColor = COL_DARK_RED;
    productLoadFalure.text = @"Failed to load Product!";
    productLoadFalure.hidden = TRUE;
    [self.view addSubview:productLoadFalure];
    
    //add listener for purchase notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(purchaseSuccessfulCallback) name:INAPP_CAT_PURCHASE_SUCCESS object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(purchaseFailureCallback) name:INAPP_CAT_PURCHASE_FAILURE object:nil];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)viewWillAppear:(BOOL)animated
{
    //[self requestProductData];
    
}

- (void)initiatePurchase
{
    GabrielAppDelegate *theDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    [theDelegate purchaseProduct:self.product];
}
     
- (void)requestProductData
{
    SKProductsRequest *request= [[SKProductsRequest alloc] initWithProductIdentifiers: [NSSet setWithObject: INAPP_CAT_PURCHASE_ID]];
    request.delegate = self;
    [request start];
}
- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse: (SKProductsResponse *)response
{
    //NSLog(@"SKProduct Response: %@", response);
    NSArray *products = response.products;
   // NSLog(@"SKProduct Array: %@", products);
    for(SKProduct * productObject in products)
    {
        if (productObject)
        {
            if([productObject.productIdentifier isEqualToString:@"com.holyquotes.categories"])
            {
                self.product = productObject;
                NSString * priceStr = [productObject localizedPrice];
                price.text = priceStr;
                [button setHidden:FALSE];
                //NSLog(@"PRICE: %@", priceStr);
                return;
            }
            /*
             NSLog(@"Product title: %@" , productObject.localizedTitle);
             NSLog(@"Product description: %@" , productObject.localizedDescription);
             NSLog(@"Product price: %@" , productObject.price);
             NSLog(@"Product id: %@" , productObject.productIdentifier);
             */
        }
    }
    //show failed product load
    productLoadFalure.hidden = FALSE;
}

-(void)purchaseSuccessfulCallback
{
    GabrielAppDelegate *theDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    [theDelegate loadCatgoryView];
    //[self displayAlert:@"Purchase Complete!" message:@"Hi Mom"];
}
-(void)purchaseFailureCallback
{
    [self displayAlert:@"Purchase Failed!" message:@"Transaction either failed or was cancelled by the user"];
}
@end
