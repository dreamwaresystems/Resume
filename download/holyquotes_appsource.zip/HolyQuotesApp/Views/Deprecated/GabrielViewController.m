//
//  GabrielViewController.m
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

//==========================================
//   NOT USED ANYMORE - 2013-07-28 - MTJ
//     QuoteView now used sans a NIB
//     for iPad/Retina compatibility
//==========================================


#import "GabrielViewController.h"
#import <stdlib.h>
#import "GabrielAppDelegate.h"
#import "settings.h"
#import "CategoryAddView.h"
#import <QuartzCore/QuartzCore.h>

@implementation GabrielViewController
-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    //self.title = @"";
    self.tabBarItem.image = [UIImage imageNamed:@"96-book.png"];
    self.title = @"Verse";

    return [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
	
    //add image to favorite button
    UIImageView * favImage = [[UIImageView alloc] initWithFrame:CGRectMake(15, 12, 24, 21)];
    favImage.image = [UIImage imageNamed:@"29-heart.png"];
    [favButton addSubview:favImage];
    
    //Main bible quote Label
    textView.textColor = [UIColor blackColor];
    //textView.font = [UIFont fontWithName:@"Callibri" size:44];
    textView.layer.shadowColor = [COL_DARK_BROWN CGColor];
    textView.layer.shadowOffset = CGSizeMake(0.3, 0.3);
    textView.layer.shadowRadius = 0.6;
    textView.layer.shadowOpacity = .95;
    textView.layer.masksToBounds = NO;
    
    //Header
    UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 51)];
    UILabel * lblHead = [[UILabel alloc] initWithFrame:CGRectMake(0, 17, 320, 30)];
    lblHead.textAlignment = NSTextAlignmentCenter;
    lblHead.font = [UIFont fontWithName:@"Papyrus" size:24];
    lblHead.text = @"Holy  Quotes";
    lblHead.layer.shadowColor = [[UIColor whiteColor] CGColor];
    lblHead.layer.shadowOffset = CGSizeMake(1.3, 1.3);
    lblHead.layer.shadowRadius = 0.5;
    lblHead.layer.shadowOpacity = 1;
    lblHead.layer.masksToBounds = NO;
    lblHead.backgroundColor = [UIColor clearColor];
    lblHead.textColor = COL_DARK_BROWN;
    UIImageView * headBack = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"header_blank.png"]];
    [header addSubview:headBack];
    [header addSubview:lblHead];
    
    [self.view addSubview:header];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [[self navigationController] setNavigationBarHidden:YES animated:NO];
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    
    //load all quotes
    [self loadAllQuotes];
    
    GabrielAppDelegate * appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    if(appDelegate.mainQuote!=nil)
    {
        [self displayQuote:appDelegate.mainQuote];
    }
    else
        [self randomQuote:self];
    
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}


#pragma mark - Custom Functions
-(void)loadAllQuotes
{
    quoteList = [[NSMutableArray alloc] init];
    GabrielAppDelegate *appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    NSMutableArray * selBooks = appDelegate.selectedBooks;
    
    //create BID string
    NSMutableString * bidStr = [[NSMutableString alloc] init];
    int c = 1;
    for(NSNumber * bid in selBooks)
    {
        [bidStr appendFormat:@"%d", [bid intValue]];
        if(c!=[selBooks count])
            [bidStr appendString:@", "];
        c++;
    }
    
    //query fro quotes
    NSString * query = [NSString stringWithFormat:@"SELECT * FROM arc_verses WHERE bid IN (%@);", bidStr];
    sqlite3_stmt * init_statement;
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"SQL ERROR: %s", sqlite3_errmsg(self.database));
    while(sqlite3_step(init_statement)== SQLITE_ROW)
    {
        QuoteObject * quoteObj = [[QuoteObject alloc] initWithRow:init_statement];
        [quoteList addObject:quoteObj];
    }
}

-(IBAction)randomQuote:(id)sender
{
    if([quoteList count]==0)
    {
        textView.text = @"No books selected.";
        proverbView.text = @"";  
        return;
    }
    int r = arc4random() % ([quoteList count]);
    QuoteObject * chosenQuote = [quoteList objectAtIndex:r];
    [self displayQuote:chosenQuote];
}

-(void)displayQuote:(QuoteObject *)quoteObj
{
   // textView.backgroundColor = COL_LIGHT_BROWN3;
    GabrielAppDelegate * appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    appDelegate.mainQuote = quoteObj;
    currQuote = quoteObj;
    textView.text = quoteObj.quote;
    proverbView.text = [quoteObj getProverb];  
}
-(IBAction)addToFavorites:(id)sender
{
    //GabrielAppDelegate * appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    //[appDelegate authorizeFacebook];
  
    [currQuote saveToFavoritesDatabase:self.database];
    //[self displayAlert:@"Verse Added" message:@"This verse has been added to your favorites"];
    
}

-(IBAction)categorizeQuote:(id)sender
{
    CategoryAddView * catAddView = [[CategoryAddView alloc] init];
    [self.navigationController pushViewController:catAddView animated:TRUE];
}

@end
