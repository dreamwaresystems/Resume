//
//  GabrielViewController.h
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "QuoteObject.h"

@interface GabrielViewController : BaseViewController
{
    IBOutlet UITextView * textView;
    IBOutlet UITextView * proverbView;
    IBOutlet UIButton * favButton;
    IBOutlet UIButton * catButton;
    
    QuoteObject * currQuote;
    NSMutableArray * quoteList;
}    

-(void)loadAllQuotes;
-(void)displayQuote:(QuoteObject *)quoteObj;
-(IBAction)randomQuote:(id)sender;
-(IBAction)addToFavorites:(id)sender;
-(IBAction)categorizeQuote:(id)sender;

@end

