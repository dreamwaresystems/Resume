//
//  CategoryAddView.h
//  HolyQuotes
//
//  Created by Mike Jones on 12/2/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "BaseViewController.h"
#import "GabrielAppDelegate.h"
#import "settings.h"

@interface CategoryAddView : BaseViewController <UITableViewDelegate, UITableViewDataSource>
{
    UITableView * localTableView;
    NSMutableArray * categoryList;
    NSMutableArray * selectedList;
    
    //add button
    UIBarButtonItem *addButton;
}

-(void)addToCats:(id)sender;
- (UITableViewCell *) getCellContentView:(NSString *)cellIdentifier;
@end
