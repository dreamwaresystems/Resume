//
//  CategoryAddView.m
//  HolyQuotes
//
//  Created by Mike Jones on 12/2/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "CategoryAddView.h"

@implementation CategoryAddView

- (id)init
{
    self.title = @"Add to Cats";
    self.tabBarItem.image = [UIImage imageNamed:@"152-rolodex.png"];
    return [super init];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    GabrielAppDelegate *theDelagate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    CGRect screen = [theDelagate getViewBounds:@"tbl"];
    
    int header_height = 27; //includes graphic offset at top
    
    //load categories
    categoryList = [theDelagate getCategories];
    
    //add clear button
    addButton = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonItemStylePlain target:self action:@selector(addToCats:)];
    self.navigationItem.rightBarButtonItem = addButton;
    
    
    //load views
    self.view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen.size.width, screen.size.height)];;
    localTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 10, screen.size.width, screen.size.height-header_height) style:UITableViewStyleGrouped];
    localTableView.dataSource = self;
    localTableView.delegate = self;
    localTableView.backgroundColor = [UIColor clearColor];
    
    UIImage * backImage = [UIImage imageNamed:@"background.png"];
    UIImageView * backView = [[UIImageView alloc] initWithFrame:self.view.frame];
    backView.image = backImage;
    
    [self.view addSubview:backView];
    [self.view addSubview: localTableView];
}
-(void)viewWillAppear:(BOOL)animated
{
    [[self navigationController] setNavigationBarHidden:FALSE animated:NO];
    [super viewWillAppear:animated];
}
-(void)viewDidAppear:(BOOL)animated
{
    [localTableView reloadData];
    [super viewDidAppear:animated];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table View Functions
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [categoryList count];
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"";
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    return 40;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
        cell = [self getCellContentView:CellIdentifier];
    
    NSArray * category = [categoryList objectAtIndex:indexPath.row];
    
    NSString * title = [category objectAtIndex:1];
    UILabel *lblText = (UILabel *)[cell viewWithTag:1];
    lblText.text = title;
    
    return cell;
}
- (UITableViewCell *) getCellContentView:(NSString *)cellIdentifier 
{    
    CGRect CellFrame = CGRectMake(0, 0, 320, 40);
    UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    UILabel *lblTemp;
    
    //main text
    CGRect nightFrame = CGRectMake(10, 0, 320, 40);
    lblTemp = [[UILabel alloc] initWithFrame:nightFrame];
    lblTemp.tag = 1;
    lblTemp.font = [UIFont fontWithName:@"Arial" size:16];
    lblTemp.backgroundColor = [UIColor clearColor];
    [cell.contentView addSubview:lblTemp];
    
    return cell;
}
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [localTableView deselectRowAtIndexPath:indexPath animated:true];
}


#pragma mark - Misc Functions
-(void)addToCats:(id)sender
{
    
    
}

@end
