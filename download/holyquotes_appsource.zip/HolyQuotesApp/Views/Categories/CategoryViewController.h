//
//  CategoryViewController.h
//  HolyQuotes
//
//  Created by Mike Jones on 12/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//


//
// Not used anymore! 2013-08-03 - MTJ
//

#import "BaseViewController.h"
#import "QuoteObject.h"
#import "settings.h"

@interface CategoryViewController : BaseViewController
{
    IBOutlet UITextView * textView;
    IBOutlet UITextView * proverbView;
    IBOutlet UIButton * favButton;
    IBOutlet UIButton * lastButton;
    IBOutlet UIButton * nextButton;
    
    QuoteObject * currQuote;
    NSMutableArray * quoteList;
    int currCount;
    
}

@property (nonatomic, retain) NSString * catCode;
@property (nonatomic, retain) NSString * catName;

-(void)loadQuotes;
-(IBAction)randomQuote:(id)sender;
-(void)displayQuote:(QuoteObject *)quoteObj;
-(IBAction)addToFavorites:(id)sender;


-(IBAction)nextCommand:(id)sender;
-(IBAction)lastCommand:(id)sender;

@end