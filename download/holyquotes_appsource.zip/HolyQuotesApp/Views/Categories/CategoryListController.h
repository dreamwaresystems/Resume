//
//  CategoryListController.h
//  HolyQuotes
//
//  Created by Mike Jones on 12/2/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "GabrielAppDelegate.h"
#import "settings.h"
#import "QuoteView.h"

@interface CategoryListController : BaseViewController <UITableViewDelegate, UITableViewDataSource>
{
    UITableView * localTableView;
    NSMutableArray * categoryList;
    NSMutableArray * categoryCounts;
}

- (UITableViewCell *) getCellContentView:(NSString *)cellIdentifier;

//Data loading
-(void)calcCategoryCounts;

@end
