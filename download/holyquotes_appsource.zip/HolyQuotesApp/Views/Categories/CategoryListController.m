//
//  CategoryListController.m
//  HolyQuotes
//
//  Created by Mike Jones on 12/2/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "CategoryListController.h"
#import "PurchaseViewController.h"
#import "functions.h"

@implementation CategoryListController

- (id)init
{
    self.title = @"Categories";
    self.tabBarItem.image = [UIImage imageNamed:@"152-rolodex.png"];
    return [super init];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    GabrielAppDelegate *theDelagate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    CGRect screen = [theDelagate getViewBounds:@"tbl"];
    
    int header_height = 27; //includes graphic offset at top
    CGRect MF = [[UIScreen mainScreen] bounds];
    CGSize MS = MF.size;
    
    //load categories
    categoryList = [theDelagate getCategories];
    [self calcCategoryCounts];
    
    //load views
    self.view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen.size.width, screen.size.height)];;
    localTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 10, screen.size.width, screen.size.height-header_height) style:UITableViewStyleGrouped];
    localTableView.dataSource = self;
    localTableView.delegate = self;
    localTableView.backgroundColor = [UIColor clearColor];
    localTableView.backgroundView = nil;
    
    //to add extra hieght to table
    UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen.size.width, 20)];
    localTableView.tableHeaderView = header;
    
    UIImageView * headBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, MS.width, 27)];
    headBack.contentMode = UIViewContentModeScaleToFill;
    if (isPad())
        headBack.image = [UIImage imageNamed:@"fav_header_wide.png"];
    else
        headBack.image = [UIImage imageNamed:@"fav_header.png"];
    
    [self.view addSubview: localTableView];
    [self.view addSubview:headBack];
}
-(void)viewDidAppear:(BOOL)animated
{
    GabrielAppDelegate *theDelagate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    //increment cat view count
    NSUserDefaults * prefs = [NSUserDefaults standardUserDefaults];
    NSNumber * catViewCount = [prefs objectForKey:@"catViewCount"];
    NSString * catsEnabled = [prefs objectForKey:@"CategoriesEnabled"];
    if([catViewCount intValue] > MAX_CAT_VIEWS && ![catsEnabled isEqualToString:@"1"])
    {
        if(INAPP_PURCHASE_ENABLED==1)
            [theDelagate loadPurchaseView];
    }
    else if([catViewCount intValue] <= MAX_CAT_VIEWS) //only do it if were under (otherwise the int grows large)
    {
        catViewCount = [NSNumber numberWithInt:[catViewCount intValue]+1];
        [prefs setObject:catViewCount forKey:@"catViewCount"];
        [prefs synchronize];
    }
    
    
    [localTableView reloadData];
    [super viewDidAppear:animated];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table View Functions
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [categoryList count];
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"";
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    return 40;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
        cell = [self getCellContentView:CellIdentifier];

    NSArray * category = [categoryList objectAtIndex:indexPath.row];
    NSNumber * count = [[NSNumber alloc] initWithInt:0];
    if([categoryCounts count]>indexPath.row)
        count = [categoryCounts objectAtIndex:indexPath.row];
    
    //title
    NSString * title = [category objectAtIndex:1];
    UILabel *lblText = (UILabel *)[cell viewWithTag:1];
    lblText.text = title;
    
    //count
    lblText = (UILabel *)[cell viewWithTag:2];
    lblText.text = [NSString stringWithFormat:@"%d", [count intValue]];
    return cell;
}
- (UITableViewCell *) getCellContentView:(NSString *)cellIdentifier 
{    
    CGRect CellFrame = CGRectMake(0, 0, 320, 40);
    UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleGray;;
    
    UILabel *lblTemp;
    
    //main text
    CGRect frame = CGRectMake(10, 0, 320, 40);
    lblTemp = [[UILabel alloc] initWithFrame:frame];
    lblTemp.tag = 1;
    lblTemp.font = [UIFont fontWithName:@"Arial" size:16];
    lblTemp.backgroundColor = [UIColor clearColor];
    [cell.contentView addSubview:lblTemp];

    //count
    frame = CGRectMake(240, 0, 70, 40);
    lblTemp = [[UILabel alloc] initWithFrame:frame];
    lblTemp.tag = 2;
    lblTemp.font = [UIFont fontWithName:@"Arial" size:16];
    lblTemp.backgroundColor = [UIColor clearColor];
    lblTemp.textColor = [UIColor lightGrayColor];
    //[cell.contentView addSubview:lblTemp];
    
    return cell;
}
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray * category = [categoryList objectAtIndex:indexPath.row];
    
    //MTJ - 2013-08-03 not used anymore
    //CategoryViewController * catView = [[CategoryViewController alloc] initWithNibName:@"CategoryViewController_iPhone" bundle:nil];
    //catView.catCode = [category objectAtIndex:0];
    //catView.catName = [category objectAtIndex:1];
    
    QuoteView * quoteView = [[QuoteView alloc] init];
    [quoteView setCategoryViewCatCode:[category objectAtIndex:0] catName:[category objectAtIndex:1]];
    [self.navigationController pushViewController:quoteView animated:TRUE];
    [localTableView deselectRowAtIndexPath:indexPath animated:true];
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:COL_LIGHT_BROWN2];
}

#pragma mark - Data loading
-(void)calcCategoryCounts
{
    categoryCounts = [[NSMutableArray alloc] init];
    //loop through cats
    for(NSArray * catArr in categoryList)
    {
        NSString * code = [catArr objectAtIndex:0];
        //NSString * name = [catArr objectAtIndex:1];
        NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT COUNT(*) FROM arc_cats WHERE cat LIKE '%%%@%%';", code];
        sqlite3_stmt * init_statement;
        if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
            NSLog(@"%s", sqlite3_errmsg(self.database));
        while(sqlite3_step(init_statement)== SQLITE_ROW)
        {
            int count = sqlite3_column_int(init_statement, 0);
            [categoryCounts addObject:[NSNumber numberWithInt:count]];
        }
    }
}

@end
