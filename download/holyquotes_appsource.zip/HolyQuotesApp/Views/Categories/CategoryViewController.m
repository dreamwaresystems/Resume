//
//  CategoryViewController.m
//  HolyQuotes
//
//  Created by Mike Jones on 12/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "CategoryViewController.h"
#import "GabrielAppDelegate.h"
#import <QuartzCore/QuartzCore.h>

@implementation CategoryViewController
@synthesize catCode;
@synthesize catName;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {
        
    
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    self.title = self.catName;
    [super viewDidLoad];
    
    UIImageView * headBack = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"fav_header.png"]];
    UIImage * backImage = [UIImage imageNamed:@"background.png"];
    UIImageView * backView = [[UIImageView alloc] initWithFrame:self.view.frame];
    backView.image = backImage;
    [self.view addSubview:headBack];
    
    textView.layer.shadowColor = [COL_DARK_BROWN CGColor];
    textView.layer.shadowOffset = CGSizeMake(0.3, 0.3);
    textView.layer.shadowRadius = 0.6;
    textView.layer.shadowOpacity = .95;
    textView.layer.masksToBounds = NO;
    
    [self loadQuotes];
    [self randomQuote:nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Custom Functions
-(void)loadQuotes
{
    quoteList = [[NSMutableArray alloc] init];
    NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT * FROM arc_cats WHERE cat LIKE '%%%@%%';", self.catCode];
    sqlite3_stmt * init_statement;
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"%s", sqlite3_errmsg(self.database));
    while(sqlite3_step(init_statement)== SQLITE_ROW)
    {
        QuoteObject * quoteObj = [[QuoteObject alloc] initWithRow:init_statement];
        [quoteList addObject:quoteObj];
    }
}


-(IBAction)randomQuote:(id)sender
{
    int r = arc4random() % ([quoteList count]);
    currCount = r;
    QuoteObject * tempQuote = [quoteList objectAtIndex:r];
    [self displayQuote:tempQuote];
}
-(void)displayQuote:(QuoteObject *)quoteObj
{
    // textView.backgroundColor = COL_LIGHT_BROWN3;
    GabrielAppDelegate * appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    appDelegate.mainQuote = quoteObj;
    currQuote = quoteObj;
    textView.text = quoteObj.quote;
    proverbView.text = [quoteObj getProverb];  
}


#pragma mark - Custom Commands
-(IBAction)addToFavorites:(id)sender
{
    [currQuote saveToFavoritesDatabase:self.database];
    [self displayAlert:@"Verse Added" message:@"This verse has been added to your favorites"];
}
-(IBAction)nextCommand:(id)sender
{
    currCount++;
    if(currCount>=[quoteList count])
        currCount=0;
    currQuote = [quoteList objectAtIndex:currCount];
    [self displayQuote:currQuote];
}
-(IBAction)lastCommand:(id)sender
{
    currCount--;
    if(currCount<0)
        currCount=[quoteList count]-1;
    currQuote = [quoteList objectAtIndex:currCount];
    [self displayQuote:currQuote];
}

@end
