//
//  CustomTabBarController.h
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTabBarController : UITabBarController
{
    
    
}

@end


