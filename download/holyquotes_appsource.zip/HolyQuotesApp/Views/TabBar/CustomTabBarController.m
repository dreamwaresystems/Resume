//
//  CustomTabBarController.m
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomTabBarController.h"

@implementation CustomTabBarController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    CGRect frame = CGRectMake(0.0, 0.0, [self tabBar].frame.size.width, [self tabBar].frame.size.height);
    UIView *v = [[UIView alloc] initWithFrame:frame];
    
    [v setBackgroundColor:[UIColor colorWithRed:.25490   green:.15686   blue:.01176   alpha:1]];
    [v setAlpha:0.5];
    [[self tabBar] addSubview:v];//:v atIndex:0];
    [super viewDidLoad];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
@end
