//
//  QuoteView.m
//  HolyQuotes
//
//  Created by Mike Jones on 7/28/13.
//
//

#import "QuoteView.h"
#import "GabrielViewController.h"
#import <stdlib.h>
#import "GabrielAppDelegate.h"
#import "settings.h"
#import "functions.h"
#import "CategoryAddView.h"
#import <QuartzCore/QuartzCore.h>

@implementation QuoteView

//properties
@synthesize catView;
@synthesize favView;

#pragma mark - Initialization
-(id)init
{
    self.tabBarItem.image = [UIImage imageNamed:@"96-book.png"];
    self.title = @"Verse";
    self.favView = false;
    self.catView = false;
    return [super init];
}

#pragma mark - View lifecycle

- (void)loadView
{
    [super loadView];

    viewChangesMade = false;
    currCount = 0;
    
    //Sizing Calculations to dynamically size screen objects
    // Header size: 320 / 51 px
    CGRect MF = [[UIScreen mainScreen] bounds];
    CGSize MS = MF.size;
    float headerHeight = 51;
    float statusBarOffset = 0;
    
    // damn iOS7 fix for floating status bar....thanks apple!
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
    {
        statusBarOffset = 10;
        //MF.size.height -= statusBarOffset;
        //MF.origin.y += statusBarOffset;
    }
    
    CGRect headerRect = CGRectMake(0, statusBarOffset, MS.width, headerHeight/*(51 * (MS.width / 320.0))*/ );
    CGRect quoteRect = CGRectMake (MS.width*0.02, statusBarOffset+headerRect.size.height+headerRect.size.height*0.10, MS.width-(MS.width*0.04), MS.height*0.45);
    CGRect verseRect = CGRectMake (0, statusBarOffset+quoteRect.origin.y + quoteRect.size.height + quoteRect.size.height*0.01, MS.width, quoteRect.size.height/7);
    CGRect controlRect = CGRectMake(0, statusBarOffset+verseRect.origin.y + verseRect.size.height, MS.width, MS.height-quoteRect.size.height-headerRect.size.height-verseRect.size.height);
    
    //adjust boxes a bit for iPad screen size
    if(isPad())
    {
        quoteRect.origin.y += 50;
        controlRect.origin.y += 50;
    }
    
    //Header
    header = [[UIView alloc] initWithFrame:headerRect];
    lblHead = [[UILabel alloc] initWithFrame:CGRectMake(0, headerRect.size.height * 0.27, MS.width, headerRect.size.height * 0.70)];
    lblHead.textAlignment = NSTextAlignmentCenter;
    lblHead.font = [UIFont fontWithName:@"Papyrus" size:24];
    lblHead.text = @"Holy  Quotes";
    lblHead.layer.shadowColor = [[UIColor whiteColor] CGColor];
    lblHead.layer.shadowOffset = CGSizeMake(1.3, 1.3);
    lblHead.layer.shadowRadius = 0.5;
    lblHead.layer.shadowOpacity = 1;
    lblHead.layer.masksToBounds = NO;
    lblHead.backgroundColor = [UIColor clearColor];
    lblHead.textColor = COL_DARK_BROWN;
    headBack = [[UIImageView alloc] initWithFrame:headerRect];
    headBack.contentMode = UIViewContentModeScaleToFill;
    if(isPad())
        headBack.image = [UIImage imageNamed:@"header_blank_wide.png"];
    else
        headBack.image = [UIImage imageNamed:@"header_blank.png"];
    [header addSubview:headBack];
    [header addSubview:lblHead];
    
    //Main quote Label
    quoteView = [[UITextView alloc] initWithFrame:quoteRect];
    quoteView.backgroundColor = [UIColor clearColor];
    quoteView.editable = false;
    quoteView.textColor = [UIColor blackColor];
    quoteView.textAlignment = NSTextAlignmentCenter;
    quoteView.contentMode = UIViewContentModeScaleToFill;
    quoteView.font = [UIFont fontWithName:@"Papyrus" size:25];
    quoteView.layer.shadowColor = [COL_DARK_BROWN CGColor];
    quoteView.layer.shadowOffset = CGSizeMake(0.3, 0.3);
    quoteView.layer.shadowRadius = 0.6;
    quoteView.layer.shadowOpacity = .95;
    quoteView.layer.masksToBounds = NO;
    
    //Verse reference label
    verseLabel = [[UILabel alloc] initWithFrame:verseRect];
    verseLabel.backgroundColor = [UIColor clearColor];
    verseLabel.textColor = [UIColor blackColor];
    verseLabel.textAlignment = NSTextAlignmentCenter;
    verseLabel.contentMode = UIViewContentModeScaleToFill;
    verseLabel.font = [UIFont fontWithName:@"Arial" size:14];
    verseLabel.layer.shadowColor = [COL_DARK_BROWN CGColor];
    verseLabel.layer.shadowOffset = CGSizeMake(0.3, 0.3);
    verseLabel.layer.shadowRadius = 0.6;
    verseLabel.layer.shadowOpacity = .95;
    verseLabel.layer.masksToBounds = NO;
    
    //User Control Panel
    float btnHeight = controlRect.size.height*0.24;
    CGRect newBtnRect = CGRectMake(MS.width*0.06, 0, MS.width*0.88, btnHeight);
    CGRect favBtnRect = CGRectMake(newBtnRect.origin.x, newBtnRect.size.height+newBtnRect.size.height*0.20, MS.width*0.43, btnHeight);
    CGRect shrBtnRect = CGRectMake(favBtnRect.size.width+favBtnRect.size.width*0.18, favBtnRect.origin.y, MS.width*0.43, btnHeight);
    CGRect lastBtnRect = favBtnRect; //these buttons overlap with new button (one or the other will be hidden based on view)
    CGRect nextBtnRect = shrBtnRect;
    lastBtnRect.origin.y = newBtnRect.origin.y;
    nextBtnRect.origin.y = newBtnRect.origin.y;
    
    controlBox = [[UIView alloc] initWithFrame:controlRect];
    
    newButton = [[UIButton alloc] initWithFrame:newBtnRect];
    [newButton setBackgroundImage:[UIImage imageNamed:@"button_back_large.png"] forState:UIControlStateNormal];
    [newButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [newButton setTitle:@"Random Verse" forState:UIControlStateNormal];
    [newButton setTitleShadowColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [newButton.titleLabel setFont:[UIFont boldSystemFontOfSize:15]];
    [newButton.titleLabel setShadowOffset:CGSizeMake(-0.5, -0.5)];
    [newButton addTarget:self action:@selector(showRandomQuote:) forControlEvents:UIControlEventTouchUpInside];
    [controlBox addSubview:newButton];
    
    
    //Category View buttons share space with the newButton
    lastButton = [[UIButton alloc] initWithFrame:lastBtnRect];
    [lastButton setBackgroundImage:[UIImage imageNamed:@"button_back_small2.png"] forState:UIControlStateNormal];
    [lastButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [lastButton setTitle:@"<   Last Quote" forState:UIControlStateNormal];
    [lastButton setTitleShadowColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [lastButton.titleLabel setFont:[UIFont boldSystemFontOfSize:15]];
    [lastButton.titleLabel setShadowOffset:CGSizeMake(-0.5, -0.5)];
    [lastButton addTarget:self action:@selector(lastCommand:) forControlEvents:UIControlEventTouchUpInside];
    [controlBox addSubview:lastButton];
    nextButton = [[UIButton alloc] initWithFrame:nextBtnRect];
    [nextButton setBackgroundImage:[UIImage imageNamed:@"button_back_small2.png"] forState:UIControlStateNormal];
    [nextButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [nextButton setTitle:@"Next Quote   >" forState:UIControlStateNormal];
    [nextButton setTitleShadowColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [nextButton.titleLabel setFont:[UIFont boldSystemFontOfSize:15]];
    [nextButton.titleLabel setShadowOffset:CGSizeMake(-0.5, -0.5)];
    [nextButton addTarget:self action:@selector(nextCommand:) forControlEvents:UIControlEventTouchUpInside];
    [controlBox addSubview:nextButton];
    
    
    favButton = [[UIButton alloc] initWithFrame:favBtnRect];
    [favButton setBackgroundImage:[UIImage imageNamed:@"button_back_small2.png"] forState:UIControlStateNormal];
    [favButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [favButton setTitle:@"       Favorite" forState:UIControlStateNormal];
    [favButton setTitleShadowColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [favButton.titleLabel setFont:[UIFont boldSystemFontOfSize:15]];
    [favButton.titleLabel setShadowOffset:CGSizeMake(-0.5, -0.5)];
    [favButton addTarget:self action:@selector(addToFavorites:) forControlEvents:UIControlEventTouchUpInside];
    [controlBox addSubview:favButton];
    
    shareButton = [[UIButton alloc] initWithFrame:shrBtnRect];
    [shareButton setBackgroundImage:[UIImage imageNamed:@"button_back_small2.png"] forState:UIControlStateNormal];
    [shareButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [shareButton setTitle:@"      Share" forState:UIControlStateNormal];
    [shareButton setTitleShadowColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [shareButton.titleLabel setFont:[UIFont boldSystemFontOfSize:15]];
    [shareButton.titleLabel setShadowOffset:CGSizeMake(-0.5, -0.5)];
    [shareButton addTarget:self action:@selector(shareAction:) forControlEvents:UIControlEventTouchUpInside];
    [controlBox addSubview:shareButton];
    
    if(isPad())
    {
        //adjust font sizes
        [newButton.titleLabel setFont:[UIFont boldSystemFontOfSize:27]];
        [favButton.titleLabel setFont:[UIFont boldSystemFontOfSize:27]];
        [shareButton.titleLabel setFont:[UIFont boldSystemFontOfSize:27]];
        [lastButton.titleLabel setFont:[UIFont boldSystemFontOfSize:27]];
        [nextButton.titleLabel setFont:[UIFont boldSystemFontOfSize:27]];
        
        quoteView.font = [UIFont fontWithName:@"Papyrus" size:47];
        verseLabel.font = [UIFont fontWithName:@"Arial" size:26];
    }
    
    
    //add images to favorite / share buttons
    CGSize FS = favButton.bounds.size;
    CGRect heartRect = CGRectMake(FS.width*0.10, FS.height*0.33, FS.width*0.30, FS.height*0.33);
    UIImageView * favImage = [[UIImageView alloc] initWithFrame:heartRect];
    [favImage setContentMode:UIViewContentModeScaleAspectFit];
    favImage.image = [UIImage imageNamed:@"29-heart.png"];
    [favButton addSubview:favImage];
    CGRect shareRect = CGRectMake(FS.width*0.14, FS.height*0.33, FS.width*0.30, FS.height*0.33);
    UIImageView * shareImage = [[UIImageView alloc] initWithFrame:shareRect];
    [shareImage setContentMode:UIViewContentModeScaleAspectFit];
    shareImage.image = [UIImage imageNamed:@"share.png"];
    [shareButton addSubview:shareImage];
    
    // main View
    backImageView = [[UIImageView alloc] initWithFrame:MF];
    backImageView.contentMode = UIViewContentModeScaleToFill;
    CGRect backFrame = backImageView.frame;
    backFrame.origin.y += statusBarOffset;
    backFrame.size.height -= statusBarOffset;
    backImageView.frame = backFrame;
    backImageView.image = [UIImage imageNamed:@"background.png"];
    
    self.view = [[UIView alloc] initWithFrame:MF];
    self.view.backgroundColor = [UIColor brownColor]; // color of status bar
    [self.view addSubview:backImageView];
    
    UIView * temp = self.view; // before iOS7, change this to "self.view"
    
    [temp addSubview:header];
    [temp addSubview:quoteView];
    [temp addSubview:verseLabel];
    [temp addSubview:controlBox];
    
}

-(void)viewDidLoad
{
    [super viewDidLoad];
}
-(void)viewDidUnload
{
    [super viewDidUnload];
}

-(void)viewWillAppear:(BOOL)animated
{
    //load all quotes
    [self loadAllQuotes];
    
    // right now, this is a one way change - you can't make this view a
    //  category/favorite view and then switch back to a normal quote view.
    //  For now, we don't recycle view allocations.  Moving  around
    //  is too annoying and the memory footprint is small
    
    if(self.catView)
    {
        self.title = self.catName;
        [[self navigationController] setNavigationBarHidden:NO animated:NO];
        [self loadCategoryQuotes];
        newButton.hidden = true;
        lastButton.hidden = false;
        nextButton.hidden = false;
        
        if(!viewChangesMade)
        {
            header.hidden = true;
            CGRect frame;
            frame = quoteView.frame;
            frame.origin.y = [[UIScreen mainScreen] bounds].size.height*0.02;
            quoteView.frame = frame;
            frame = verseLabel.frame;
            frame.origin.y -= header.frame.size.height;
            verseLabel.frame = frame;
            frame = controlBox.frame;
            frame.origin.y -= header.frame.size.height;
            controlBox.frame = frame;
            viewChangesMade = true;
        }
        
    }
    else if(self.favView)
    {
        self.title = @"Favorites";
        [[self navigationController] setNavigationBarHidden:NO animated:NO];
        newButton.hidden = true;
        lastButton.hidden = true;
        nextButton.hidden = true;
        favButton.hidden = true;
        CGRect frame;
        if(!viewChangesMade)
        {
            //shift things a bit
            int quoteY = quoteView.frame.origin.y;
            frame = quoteView.frame;
            frame.origin.y -= quoteY / 2;
            frame.size.height += quoteY / 3;
            quoteView.frame = frame;
            
            frame = verseLabel.frame;
            //frame.origin.y -= quoteY / 2;
            //frame.origin.y += quoteY / 2;
            verseLabel.frame = frame;
            
            frame = controlBox.frame;
            frame.origin.y -= header.frame.size.height;
            controlBox.frame = frame;
            
            //change header size and image
            frame = header.frame;
            frame.size.height = 27;
            header.frame = frame;
            frame = headBack.frame;
            frame.size.height = 27;
            headBack.frame = frame;
 
            lblHead.hidden = true;
            if (isPad())
                headBack.image = [UIImage imageNamed:@"fav_header_wide.png"];
            else
                headBack.image = [UIImage imageNamed:@"fav_header.png"];
            
            viewChangesMade = true;
        }
    }
    else
    {
        self.title = @"Verse";
        [[self navigationController] setNavigationBarHidden:YES animated:NO];
        lastButton.hidden = true;
        nextButton.hidden = true;
        newButton.hidden = false;
    }
    [super viewWillAppear:animated];
}
-(void)viewDidAppear:(BOOL)animated
{
    if(catView)
    {
        [self displayQuote:[catQuoteList objectAtIndex:0]];
        currCount = 0;
    }
    else if(self.favView)
    {
        [self displayQuote:favQuote];
    }
    else //normal view
    {
        if([quoteView.text isEqualToString:@""])
            [self showRandomQuote:self];
    }
    [super viewDidAppear:animated];
}
-(void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}
-(void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}
-(void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return FALSE;
}


#pragma mark - Internal Functions
-(void)loadAllQuotes
{
    quoteList = [[NSMutableArray alloc] init];
    GabrielAppDelegate *appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    NSMutableArray * selBooks = appDelegate.selectedBooks;
    
    //create BID string
    NSMutableString * bidStr = [[NSMutableString alloc] init];
    int c = 1;
    for(NSNumber * bid in selBooks)
    {
        [bidStr appendFormat:@"%d", [bid intValue]];
        if(c!=[selBooks count])
            [bidStr appendString:@", "];
        c++;
    }
    
    //query fro quotes
    NSString * query = [NSString stringWithFormat:@"SELECT * FROM arc_verses WHERE bid IN (%@);", bidStr];
    sqlite3_stmt * init_statement;
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"SQL ERROR: %s", sqlite3_errmsg(self.database));
    while(sqlite3_step(init_statement)== SQLITE_ROW)
    {
        QuoteObject * quoteObj = [[QuoteObject alloc] initWithRow:init_statement];
        [quoteList addObject:quoteObj];
    }
}

-(void)displayQuote:(QuoteObject *)quoteObj
{
    // textView.backgroundColor = COL_LIGHT_BROWN3;
    //GabrielAppDelegate * appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
   // appDelegate.mainQuote = quoteObj;
    currQuote = quoteObj;
    quoteView.text = quoteObj.quote;
    [verseLabel setText:[quoteObj getProverb]];
}


#pragma mark - Button Actions
-(void)showRandomQuote:(id)sender
{
    if([quoteList count]==0)
    {
        quoteView.text = @"No books selected.";
        verseLabel.text = @"";
        return;
    }
    int r = arc4random() % ([quoteList count]);
    QuoteObject * chosenQuote = [quoteList objectAtIndex:r];
    [self displayQuote:chosenQuote];
}
-(void)addToFavorites:(id)sender
{
    [currQuote saveToFavoritesDatabase:self.database];
    [self displayAlert:nil message:@"This verse had been saved to your favorites!"];
}
-(void)shareAction:(id)sender
{
    //GabrielAppDelegate * appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    //[appDelegate authorizeFacebook];
    
    shareActionSheet = [[UIActionSheet alloc] initWithTitle:@"Share this verse via:" delegate:self cancelButtonTitle:@"Cancel"
                        destructiveButtonTitle:nil otherButtonTitles:@"Twitter", /*@"Post to Facebook",*/ @"Email", @"Text Message", nil];
    [shareActionSheet showFromTabBar:self.tabBarController.tabBar];
}




#pragma mark - Category View Specific Functions
-(void)setCategoryViewCatCode:(NSString *)code catName:(NSString *)name
{
    self.catView = true;
    self.favView = false;
    self.catCode = code;
    self.catName = name;
}
-(void)setFavoriteViewQuote:(QuoteObject *)quote
{
    self.favView = true;
    self.catView = false;
    favQuote = quote;
}
-(void)loadCategoryQuotes
{
    catQuoteList = [[NSMutableArray alloc] init];
    NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT * FROM arc_cats WHERE cat LIKE '%%%@%%';", self.catCode];
    sqlite3_stmt * init_statement;
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"%s", sqlite3_errmsg(self.database));
    while(sqlite3_step(init_statement)== SQLITE_ROW)
    {
        QuoteObject * quoteObj = [[QuoteObject alloc] initWithRow:init_statement];
        [catQuoteList addObject:quoteObj];
    }
}
-(void)nextCommand:(id)sender
{
    currCount++;
    if(currCount>=[catQuoteList count])
        currCount=0;
    currQuote = [catQuoteList objectAtIndex:currCount];
    [self displayQuote:currQuote];
}
-(void)lastCommand:(id)sender
{
    currCount--;
    if(currCount<0)
        currCount=(int)[catQuoteList count]-1;
    currQuote = [catQuoteList objectAtIndex:currCount];
    [self displayQuote:currQuote];
}



#pragma mark - UI Delegates
#pragma mark UIActionSheet 
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    QuoteObject * postQuote = nil;
    if(self.favView)
        postQuote = favQuote;
    else
        postQuote = currQuote;
    
    if(buttonIndex==0) //tweet
    {
        [self postQuoteToTwitter];
    }
   /*else if(buttonIndex==1) //facebook
    {
        
    }*/
    else if(buttonIndex==1) //email
    {
        NSString * msg = [NSString stringWithFormat:@"\"%@\"<br/><br/>&nbsp;&nbsp;-&nbsp;<b>%@</b><br/><br/>", [postQuote quote], [postQuote getProverb]];
        msg = [msg stringByAppendingFormat:@"<br/><br/><br/><br/><br/><i>Find more great Bible verses by downloading the <a href=\"%@\">HolyQuotes iPhone/iPad App<a></i>", APP_ITUNES_URL];
        
        mailController = [[MFMailComposeViewController alloc] init];
        mailController.mailComposeDelegate = self;
        [mailController setSubject:@"Check out this Bible quote I found"];
        [mailController setMessageBody:msg isHTML:YES];
        mailController.delegate =  self;
        [self presentViewController:mailController animated:TRUE completion:nil]; //TODO: Add completion callback?
    }
    else if(buttonIndex==2) //SMS
    {
        if([MFMessageComposeViewController canSendText])
        {
            NSString * msg = [NSString stringWithFormat:@"\"%@\" - %@", [postQuote quote], [postQuote getProverb]];
            msg = [msg stringByAppendingFormat:@"\n\n%@", APP_ITUNES_URL_SHORT];
            
            MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
            picker.messageComposeDelegate = self;
            picker.recipients = nil;
            picker.body = msg;
            [self presentViewController:picker animated:TRUE completion:nil]; //TODO: Add completion callback?
        }
        else
        {
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Oops" message:@"This device is not capable of sending text messages, sorry." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            [alert show];
        }
        
    }
}

#pragma mark UIAlertView
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==55) //twitter unable to connect
    {
        if(buttonIndex==1) //go to settings for twitter
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"prefs:root=TWITTER"]];
    }
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    
    [controller dismissViewControllerAnimated:TRUE completion:nil];
    
}

#pragma mark - Sharing Functions And Delegates

#pragma mark Twitter
-(void)postQuoteToTwitter
{
    //TODO: Update this to work with iOS7+
    /*TWTweetComposeViewController *twitter = [[TWTweetComposeViewController alloc] init];
    if(![TWTweetComposeViewController canSendTweet])
    {
        UIAlertView * twitterAlert = [[UIAlertView alloc] initWithTitle:@"Unable to connect" message:@"Could not connect to twitter. Please check your iOS twitter account settings or try again later." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: @"Go to Settings", nil];
        twitterAlert.tag=55; //twitter
        [twitterAlert show];
        return;
    }
    
    //get quote to share
    QuoteObject * postQuote = nil;
    if(self.favView)
        postQuote = favQuote;
    else
        postQuote = currQuote;
    if(postQuote==nil)
    {
        UIAlertView * noImageAlert = [[UIAlertView alloc] initWithTitle:@"Strange" message:@"There is no quote available to share" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        noImageAlert.tag=99; //no quote
        [noImageAlert show];
        return;
    }
    
    //create tweet
    NSString * tweet = [NSString stringWithFormat:@"%@ -%@", [postQuote quote], [postQuote getProverb]];
    [twitter setInitialText:tweet];
    [twitter addURL:[NSURL URLWithString:APP_ITUNES_URL_SHORT]];
 
    [self presentViewController:twitter animated:YES completion:nil];
    twitter.completionHandler = ^(TWTweetComposeViewControllerResult res)
    {
        if(res == TWTweetComposeViewControllerResultDone)
        {
            UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Your Tweet has been sent" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            [alertView show];
        }
        else if(res == TWTweetComposeViewControllerResultCancelled)
        {
            //UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"Post Cancelled" message:@"Your Tweet was not posted" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            // [alertView show];
        }
        [self dismissModalViewControllerAnimated:YES];
    };*/
}

#pragma mark Email Delegate
-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    [controller dismissViewControllerAnimated:TRUE completion:nil]; //TODO: Add completion callback?
    
    NSString * message = @"";
    if(result==MFMailComposeResultCancelled)
        return;
    else if(result==MFMailComposeResultFailed)
        message = @"Email send failure.  Please check your mail settings and try again";
    else if(result==MFMailComposeResultSaved)
        message = @"An draft of your email has been saved for later review";
    else if(result==MFMailComposeResultSent)
        message = @"Your email has been sent";
    if(error.code==MFMailComposeErrorCodeSendFailed)
        message = @"Email send failure.  Please check your mail settings and try again.";

    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alert show];
}


#pragma mark - Admin Functions for Dev Only
-(void)categorizeQuote:(id)sender
{
    CategoryAddView * catAddView = [[CategoryAddView alloc] init];
    [self.navigationController pushViewController:catAddView animated:TRUE];
}


@end
