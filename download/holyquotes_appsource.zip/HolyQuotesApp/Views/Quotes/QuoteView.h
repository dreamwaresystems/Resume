//
//  QuoteView.h
//  HolyQuotes
//
//  Created by Mike Jones on 7/28/13.
//
//  This view doubles as the main random-quote view and the
//    categorized quote view.  Depending on whether "catView" is
//    set to true/false, different options will be displayed
//

#import "BaseViewController.h"
#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "QuoteObject.h"
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

@interface QuoteView : BaseViewController <UIActionSheetDelegate, UIAlertViewDelegate, MFMailComposeViewControllerDelegate,
                                           MFMailComposeViewControllerDelegate, UINavigationControllerDelegate,
                                           MFMessageComposeViewControllerDelegate>
{
    UIImageView * backImageView;
    UIView * header;
    UIImageView * headBack;
    UILabel * lblHead;
    
    UITextView * quoteView;
    UILabel * verseLabel;
    
    
    //user controls
    UIView * controlBox;
    UIButton * newButton;
    UIButton * favButton;
    UIButton * shareButton;
    UIActionSheet * shareActionSheet;
    
    //storage objects
    QuoteObject * currQuote;
    QuoteObject * favQuote; //only used in favorite quote view to set title on load
    NSMutableArray * quoteList; //random quote list
    
    //category view objects
    UIButton * nextButton; //extra buttons replace nav/fav buttons
    UIButton * lastButton;
    NSMutableArray * catQuoteList; //categorized quote list
    int currCount;
    
    BOOL viewChangesMade; // flags that we already shifted the view for a cat/fav view
                          //  (so it doesn't shift twice when changing tabs)
    
    //email composer
    MFMailComposeViewController *mailController;
    
}
@property (nonatomic, assign) BOOL favView; //favorite view flag
@property (nonatomic, assign) BOOL catView; //category view flag
@property (nonatomic, retain) NSString * catCode; //category view properties
@property (nonatomic, retain) NSString * catName;

-(void)setCategoryViewCatCode:(NSString *)code catName:(NSString *)name;
-(void)setFavoriteViewQuote:(QuoteObject *)quote;
-(void)loadAllQuotes;
-(void)displayQuote:(QuoteObject *)quoteObj;

-(void)showRandomQuote:(id)sender;
-(void)addToFavorites:(id)sender;
-(void)shareAction:(id)sender;
-(void)categorizeQuote:(id)sender; //old admin function (not used anymore)

//Category View Functions
-(void)loadCategoryQuotes;
-(void)nextCommand:(id)sender;
-(void)lastCommand:(id)sender;

//Sharing Delegates and Functions
-(void)postQuoteToTwitter;


@end


