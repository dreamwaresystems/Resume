//
//  SettingsViewController.m
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "SettingsViewController.h"
#import "BookObject.h"
#import "settings.h"
#import "GabrielAppDelegate.h"
#import <QuartzCore/QuartzCore.h>
#import "functions.h"

@implementation SettingsViewController

-(id)init
{
    self.title = @"Settings";
    self.tabBarItem.image = [UIImage imageNamed:@"20-gear2.png"];
    return [super init];
}
-(void)loadView
{
    //Get all the books
    books = [[NSMutableArray alloc] init];
    chapterCounts = [[NSMutableArray alloc] init];
    [self loadBooks];
    
    //add edit button
    allButton = [[UIBarButtonItem alloc] initWithTitle:@"Check All" style:UIBarButtonItemStylePlain target:self action:@selector(selAllNone)];
    self.navigationItem.rightBarButtonItem = allButton;

    CGRect MF = [[UIScreen mainScreen] bounds];
    CGSize MS = MF.size;
    float headerHeight = 51;
    if(isPad())
        headerHeight = 80;
    
    int tableHeight = MS.height;
    tableHeight -= self.tabBarController.tabBar.frame.size.height;
    tableHeight -= self.navigationController.navigationBar.frame.size.height;
    
    //VIEWS
    self.view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, MS.width, MS.height)];
    localTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, MS.width, tableHeight) style:UITableViewStyleGrouped];
    localTableView.dataSource = self;
    localTableView.delegate = self;
    localTableView.backgroundColor = [UIColor clearColor];
    localTableView.backgroundView = nil;
    
    UIView * header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, MS.width, headerHeight)];
    UILabel * lblHead = [[UILabel alloc] initWithFrame:CGRectMake(0, 17, MS.width, 30)];
    lblHead.textAlignment = NSTextAlignmentCenter;
    lblHead.font = [UIFont fontWithName:@"Papyrus" size:20];
    lblHead.text = @"Books to select from";
    
    lblHead.layer.shadowColor = [[UIColor whiteColor] CGColor];
    lblHead.layer.shadowOffset = CGSizeMake(1.3, 1.3);
    lblHead.layer.shadowRadius = 0.5;
    lblHead.layer.shadowOpacity = 1;
    lblHead.layer.masksToBounds = NO;
    lblHead.backgroundColor = [UIColor clearColor];
    lblHead.textColor = COL_DARK_BROWN;
    
    UIImageView * headBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, MS.width, 51)];
    headBack.contentMode = UIViewContentModeScaleToFill;
    if(isPad())
        headBack.image = [UIImage imageNamed:@"header_blank_wide.png"];
    else
        headBack.image = [UIImage imageNamed:@"header_blank.png"];
    
    [header addSubview:headBack];
    [header addSubview:lblHead];
    
    //to add space to top of table
    UIView * space = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, headerHeight)];
    localTableView.tableHeaderView = space;

    //localTableView.backgroundView
    [self.view addSubview: localTableView];
    [self.view addSubview:header];
}


-(void)loadBooks
{
    oldTestamentCount = 0;
    NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT * FROM arc_books WHERE arc_books.bid IN (SELECT bid FROM arc_verses) ORDER BY bid;"];
    //NSMutableString * query = [NSMutableString stringWithFormat:@"SELECT * FROM arc_books;"];
    
    //NSLog(@"%@", query);
    sqlite3_stmt * init_statement;//[self select_query:query];
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"%s", sqlite3_errmsg(self.database));
    while(sqlite3_step(init_statement)== SQLITE_ROW)
    {
        BookObject * book = [[BookObject alloc] initWithRow:init_statement];
        [books addObject:book];
        
        NSNumber * chapterNum = [[NSNumber alloc] initWithInt:0];
        NSMutableString * query2 = [NSMutableString stringWithFormat:@"SELECT COUNT(*) FROM arc_verses WHERE "];
        [query2 appendFormat:@"bid = %d", book.bid];
        sqlite3_stmt * init_statement2;
        if(sqlite3_prepare_v2(self.database, [query2 UTF8String], -1, &init_statement2, NULL) != SQLITE_OK)
            NSLog(@"%s", sqlite3_errmsg(self.database));
        if(sqlite3_step(init_statement2)== SQLITE_ROW)
        {
            //NSLog(@"%@",init_statement);
            chapterNum = [NSNumber numberWithInt:sqlite3_column_int(init_statement2, 0)];
        }
        [chapterCounts addObject:chapterNum];
        
        if(book.testament==1)
            oldTestamentCount++;
        else
            newTestamentCount++;
    }
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}
#pragma mark - View lifecycle
- (void)viewDidUnload{
    [super viewDidUnload];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



//TABLE VIEW
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section==0)
        return oldTestamentCount;
    else if(section==1)
        return newTestamentCount+1;
    return 0;
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if(section==0)
        return @"Old Testament";
    if(section==1)
        return @"New Testament";
    return @"";
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    return 40;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
        cell = [self getCellContentView:CellIdentifier];
    
    
    BookObject * book = nil;
    NSNumber * chapterCount = nil;
    if(indexPath.section==0)
        book = [books objectAtIndex:(indexPath.row)];
    else
        book = [books objectAtIndex:(indexPath.row + oldTestamentCount-1)];
    
    if(indexPath.section==0)
        chapterCount = [chapterCounts objectAtIndex:indexPath.row];
    else
        chapterCount = [chapterCounts objectAtIndex:(indexPath.row + oldTestamentCount-1)];
    
    UILabel *lblText = (UILabel *)[cell viewWithTag:1];
    UILabel *lblChap = (UILabel *)[cell viewWithTag:2];
    
    //Figure out book
    NSString * bookTxt = @"";
    if(book.book > 0)
        bookTxt = [NSString stringWithFormat:@"%d", book.book];
    
    NSString * title = [NSString stringWithFormat:@"%@ %@", book.author, bookTxt];
    lblText.text = title;
    lblChap.text = [chapterCount stringValue];//[NSString stringWithFormat:@"%d",[chapterCount intValue]];
    
    
    //figure out to check it or not
    cell.accessoryType = UITableViewCellAccessoryNone;
    GabrielAppDelegate *appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    NSMutableArray * selBooks = appDelegate.selectedBooks;
    for(NSNumber * bid in selBooks)
    {
        if([bid intValue]==book.bid)
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    
    return cell;
}
- (UITableViewCell *) getCellContentView:(NSString *)cellIdentifier 
{    
    CGRect CellFrame = CGRectMake(0, 0, 320, 40);
    UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CellFrame];
    
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    UILabel *lblTemp;
    
    //main text
    CGRect frame = CGRectMake(10, 0, 320, 40);
    lblTemp = [[UILabel alloc] initWithFrame:frame];
    lblTemp.tag = 1;
    lblTemp.font = [UIFont fontWithName:@"Arial" size:16];
    lblTemp.backgroundColor = [UIColor clearColor];
    [cell.contentView addSubview:lblTemp];
    
    //chapter text
    CGRect cframe = CGRectMake(190, 0, 70, 40);
    lblTemp = [[UILabel alloc] initWithFrame:cframe];
    lblTemp.tag = 2;
    lblTemp.font = [UIFont fontWithName:@"Arial" size:16];
    lblTemp.backgroundColor = [UIColor clearColor];
    lblTemp.textAlignment = NSTextAlignmentRight;
    [cell.contentView addSubview:lblTemp];
    
    return cell;
}

//checkbox functionality
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0 || indexPath.section==1)
    {
        BookObject * book = nil;
        if(indexPath.section==0)
            book = [books objectAtIndex:(indexPath.row)];
        else
            book = [books objectAtIndex:(indexPath.row + oldTestamentCount-1)];

        //check this one
        UITableViewCell * cell = [localTableView cellForRowAtIndexPath:indexPath];
        if(cell.accessoryType==UITableViewCellAccessoryCheckmark)
            cell.accessoryType = UITableViewCellAccessoryNone;
        else
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        [tableView deselectRowAtIndexPath:indexPath animated:TRUE];
        
        //now save the change to the preferences
        GabrielAppDelegate *appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
        NSMutableArray * selBooks = appDelegate.selectedBooks;
        NSMutableArray * selCopy = [[NSMutableArray alloc] initWithArray:selBooks];
        BOOL found = false;
        for(int c=0;c<[selBooks count];c++)
        {
            NSNumber * bid = [selBooks objectAtIndex:c];
            if(book.bid == [bid intValue])
            {
                [selCopy removeObjectAtIndex:c];
                found = TRUE;
            }
        }
        if(!found) //special case
            [selCopy addObject:[NSNumber numberWithInt:book.bid]];
        appDelegate.selectedBooks = selCopy;
        [appDelegate saveBookList];
    }
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:COL_LIGHT_BROWN2];
}
- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section 
{
    NSString * title = @"";
    if(section==0)
        title = @"Old Testament";
    if(section==1)
        title = @"New Testament";
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    [headerView setBackgroundColor:[UIColor clearColor]];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20, 5, 320, 30)];
    label.text = title;
    label.font = [UIFont boldSystemFontOfSize:18];
    //label.font = [UIFont fontWithName:@"Papyrus" size:20];
    label.textColor = COL_DARK_BROWN;
    //label.shadowColor = [UIColor blackColor];
    //label.shadowOffset = CGSizeMake(0, 0);
    label.layer.shadowColor = [COL_LIGHT_BROWN CGColor];
    label.layer.shadowOffset = CGSizeMake(1.3, 1.3);
    label.layer.shadowRadius = 0.5;
    label.layer.shadowOpacity = 1;
    label.layer.masksToBounds = NO;
    label.backgroundColor = [UIColor clearColor];
    [headerView addSubview:label];
    return headerView;
}


- (void) selAllNone
{
    GabrielAppDelegate *appDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    NSMutableArray * selBooks = [[NSMutableArray alloc] init];
    if([allButton.title isEqualToString:@"Check All"])
    {
        for(BookObject * book in books)
            [selBooks addObject:[NSNumber numberWithInt:book.bid]];
        allButton.title = @"Uncheck All";
    }
    else
    {
        allButton.title = @"Check All";
    }
    appDelegate.selectedBooks = selBooks;
    [appDelegate saveBookList];
    [localTableView reloadData];
}


@end
