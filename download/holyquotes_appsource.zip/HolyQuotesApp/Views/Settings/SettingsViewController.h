//
//  SettingsViewController.h
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface SettingsViewController : BaseViewController <UITableViewDelegate, UITableViewDataSource>
{
    UITableView * localTableView;
    NSMutableArray * books;
    NSMutableArray * chapterCounts;
    int oldTestamentCount;
    int newTestamentCount;
    UIBarButtonItem * allButton;
}

- (UITableViewCell *) getCellContentView:(NSString *)cellIdentifier;
-(void)loadBooks;
- (void) selAllNone;
@end
