//
//  BaseViewController.h
//
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <sqlite3.h>


@interface BaseViewController : UIViewController {

}

@property (nonatomic, assign) sqlite3 * database;

//- (MainAppDataObject*) theAppDataObject;
- (void)displayAlert:(NSString *)title message:(NSString *)message;

//database functions
-(sqlite3_stmt *)select_query:(NSString *)query;
-(void)ddl_query:(NSString *)query;

@end
