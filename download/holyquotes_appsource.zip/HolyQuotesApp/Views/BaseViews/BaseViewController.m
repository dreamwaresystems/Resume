//
//  BaseViewController.m
//
//  Created by Mike Jones 
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BaseViewController.h"
#import "GabrielAppDelegate.h"

@implementation BaseViewController

@synthesize database;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {
        GabrielAppDelegate *theDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
        self.database = theDelegate.database;
        
        // Custom initialization
    }
    return self;
}

-(id)init
{
    GabrielAppDelegate *theDelegate = (GabrielAppDelegate *) [UIApplication sharedApplication].delegate;
    self.database = theDelegate.database;
    
    return self;
}
- (void)dealloc
{
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle1


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidUnload
{    
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


//==========  General Functions ===========
-(void)displayAlert:(NSString *)title message:(NSString *)message
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
	[alert show];
}


//=========== Database Functions =====//
-(void)ddl_query:(NSString *)query
{
    sqlite3_stmt *init_statement = nil;
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"SQL DDL Error: %s", sqlite3_errmsg(self.database));
    if(sqlite3_step(init_statement)!= SQLITE_DONE)
        NSLog(@"SQL DDL Error: %s", sqlite3_errmsg(self.database));
}
-(sqlite3_stmt *)select_query:(NSString *)query
{
    //NSLog(@"%@", self.database);
    sqlite3_stmt *init_statement = nil;
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &init_statement, NULL) != SQLITE_OK)
        NSLog(@"SQL Seelct Error: %s", sqlite3_errmsg(self.database));
    return init_statement;
}

@end
