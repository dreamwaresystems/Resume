//
//  functions.h
//  HolyQuotes
//
//  Created by Mike Jones on 12/2/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef HolyQuotes_functions_h
#define HolyQuotes_functions_h


//Is an iPad
static BOOL isPad() {
#ifdef UI_USER_INTERFACE_IDIOM
    return (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad);
#else
    return NO;
#endif
}
#endif
