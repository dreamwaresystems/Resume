//
//  settings.h
//  BibleQuotes
//
//  Created by Mike Jones on 11/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef BibleQuotes_settings_h
#define BibleQuotes_settings_h

#define APP_VERSION             1.6

//used in twitter and facebook posts
#define APP_ITUNES_URL_SHORT     @"http://bit.ly/HolyQuotes"
#define APP_ITUNES_URL           @"https://itunes.apple.com/ua/app/holyquotes/id479143644"
#define APP_DREAMWARE_URL_SHORT  @"http://bit.ly/HolyQApp"
#define APP_DREAMWARE_URL        @"http://www.dreamwaresys.com/apps/holyquotes"  

//category purchase variables
#define MAX_CAT_VIEWS           4
#define INAPP_PURCHASE_ENABLED  0   //enable or disable the purchase of categories

#define FLUSH_DATABASE          0

#define COL_DARK_BROWN          [UIColor colorWithRed:.25490   green:.15686   blue:.01176   alpha:1]
#define COL_DARK_BROWN2         [UIColor colorWithRed:.25490   green:.15686   blue:.01176   alpha:.45]

#define COL_LIGHT_BROWN         [UIColor colorWithRed:.92156   green:.87450   blue:.80784   alpha:1]
#define COL_LIGHT_BROWN2        [UIColor colorWithRed:.9529    green:.9215    blue:.8745    alpha:1]
#define COL_LIGHT_BROWN3        [UIColor colorWithRed:.9529    green:.9215    blue:.8745    alpha:.35]  

#define COL_DARK_GREEN          [UIColor colorWithRed:49/255.0    green:108/255.0    blue:49/255.0    alpha:1]  
#define COL_DARK_RED            [UIColor colorWithRed:188/255.0    green:18/255.0    blue:18/255.0    alpha:1]  

#define STD_HEIGHT_OFFSET       60  //height offset with toolbars and stuff
#define TBL_HEIGHT_OFFSET       100  //height offset with toolbars and stuff

#define fequal(a,b) (fabs((a) - (b)) < FLT_EPSILON)
#define fequalzero(a) (fabs(a) < FLT_EPSILON)

#define INAPP_CAT_PURCHASE_ID       @"com.holyquotes.categories"
#define INAPP_CAT_PURCHASE_SUCCESS  @"inAppCatSuccess"
#define INAPP_CAT_PURCHASE_FAILURE  @"inAppCatFailure"

#endif
